package main

import (
	"testing"
)

func TestBatchExecute(t *testing.T) {
	//timeUnix := time.Now().UnixMilli()
	//fmt.Println(timeUnix)
	//BatchExecute(125)
	BatchExecute(123, "2B80900001000800", "hjddev")
}

func Test_popoPeopleAlert(t *testing.T) {
	type args struct {
		message string
		rd      string
	}
	tests := []struct {
		name string
		args args
	}{
		{"send popo to hjd", args{message: "hello hjd", rd: "hejd"}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			popoPeopleAlert(tt.args.message, tt.args.rd)
		})
	}
}
