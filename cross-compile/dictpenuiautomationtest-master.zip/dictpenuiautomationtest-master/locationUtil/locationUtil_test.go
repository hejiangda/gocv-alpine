package locationUtil

import (
	"fmt"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"testing"
)

func init() {
	adbUtil.SetAdbExecutable()
}
func TestInitDevice(t *testing.T) {
	devices, err := adbUtil.GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	devs, err := InitDevice(sn)
	if err != nil {
		t.Fatalf("Init error: %v", err)
	}
	fmt.Println(devs)
}

func TestDevice_LocateAllElementsByOcr(t *testing.T) {
	devices, err := adbUtil.GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	dev, err := InitDevice(sn)
	if err != nil {
		t.Fatalf("Init error: %v", err)
	}

	res, err := dev.LocateAllElementsByOcr()
	if err != nil {
		t.Fatalf("Locate elements error: %v", err)
	}
	fmt.Println(res.Elms)

}

func TestPage_Click(t *testing.T) {

	devices, err := adbUtil.GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	dev, err := InitDevice(sn)
	if err != nil {
		t.Fatalf("Init error: %v", err)
	}

	page, err := dev.LocateAllElementsByOcr()
	if err != nil {
		t.Fatalf("Locate elements error: %v", err)
	}
	//fmt.Println(page)
	pt, rt, err := page.Click("查词")
	fmt.Println(pt, rt)
	if err != nil {
		t.Fatalf("Click error: %v", err)
	}
}

////CheckContain
//
//func TestPage_CheckContain(t *testing.T) {
//
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//
//	page, err := dev.LocateAllElementsByOcr()
//	if err != nil {
//		t.Fatalf("Locate elements error: %v", err)
//	}
//	//fmt.Println(page)
//	err = page.CheckContain([]string{"查词", "语音"})
//	if err != nil {
//		t.Fatalf("CheckContain error: %v", err)
//	}
//}
//func TestPage_Slip_HalfShownScreenLeft(t *testing.T) {
//
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//
//	page, err := dev.LocateAllElementsByOcr()
//	if err != nil {
//		t.Fatalf("Locate elements error: %v", err)
//	}
//	err = page.Slip_HalfShownScreen("left")
//	if err != nil {
//		t.Fatalf("Slip left half screen failed! error: %v", err)
//	}
//}
//func TestPage_Slip_HalfShownScreenRight(t *testing.T) {
//
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//
//	page, err := dev.LocateAllElementsByOcr()
//	if err != nil {
//		t.Fatalf("Locate elements error: %v", err)
//	}
//	err = page.Slip_HalfShownScreen("right")
//	if err != nil {
//		t.Fatalf("Slip right half screen failed! error: %v", err)
//	}
//
//}
//func TestPage_Slip_HalfShownScreenUp(t *testing.T) {
//
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//
//	page, err := dev.LocateAllElementsByOcr()
//	if err != nil {
//		t.Fatalf("Locate elements error: %v", err)
//	}
//	err = page.Slip_HalfShownScreen("up")
//	if err != nil {
//		t.Fatalf("Slip up half screen failed! error: %v", err)
//	}
//
//}
//func TestPage_Slip_HalfShownScreenDown(t *testing.T) {
//
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//
//	page, err := dev.LocateAllElementsByOcr()
//	if err != nil {
//		t.Fatalf("Locate elements error: %v", err)
//	}
//
//	err = page.Slip_HalfShownScreen("down")
//	if err != nil {
//		t.Fatalf("Slip down half screen failed! error: %v", err)
//	}
//}
//func TestPage_Click_ShownScreen(t *testing.T) {
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//	page, err := dev.FetchScreenShot()
//	if err != nil {
//		t.Fatalf("Get page failed! %v", err)
//	}
//	err = page.Click_ShownScreen(380, 263)
//
//	//tempImg := page.ScreenShot.Clone()
//	//gocv.Circle(&tempImg, image.Point{380, 263}, 5, color.RGBA{255, 0, 0, 128}, 2)
//	//gocv.IMWrite("hjd-test.png", tempImg)
//
//}
//func TestDrawRectangle(t *testing.T) {
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//	page, err := dev.FetchScreenShot()
//	if err != nil {
//		t.Fatalf("Get page failed! %v", err)
//	}
//	img, err := page.DrawRectangle(image.Rectangle{
//		Min: image.Point{0, 0},
//		Max: image.Point{100, 100},
//	}, color.RGBA{
//		R: 255,
//		G: 0,
//		B: 0,
//		A: 128,
//	})
//	gocv.IMWrite("hjd-test.png", img)
//}
//func TestDrawText(t *testing.T) {
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	dev, err := InitDevice(sn)
//	if err != nil {
//		t.Fatalf("Init error: %v", err)
//	}
//	page, err := dev.FetchScreenShot()
//	if err != nil {
//		t.Fatalf("Get page failed! %v", err)
//	}
//	img, err := page.DrawText("hello", image.Point{20, 200}, color.RGBA{255, 0, 0, 255})
//	gocv.IMWrite("hjd-test.png", img)
//}

//func TestBase64ToPng(t *testing.T) {
//	adbUtil.SetAdbExecutable()
//	devices, err := adbUtil.GetDevices()
//	if err != nil || len(devices) < 1 {
//		t.Fatalf(`Can not found devices!`)
//	}
//	sn := devices[0][0]
//	str, err := adbUtil.ScreenShotFfmpeg(sn)
//	//fmt.Println(str)
//	Base64ToPng(str)
//	if err != nil {
//		t.Fatal(`Can not get screenshot!`, err)
//	}
//}
