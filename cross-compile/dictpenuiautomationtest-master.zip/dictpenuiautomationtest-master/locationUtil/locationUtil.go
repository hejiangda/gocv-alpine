package locationUtil

import (
	"encoding/base64"
	"errors"
	"fmt"
	"github.com/hejiangda/go-raytracer-challenge/raytracer"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/inDevice"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/ydocr"
	"gocv.io/x/gocv"
	"image"
	"image/color"
	_ "image/png"
	"io"
	"io/ioutil"
	"log"
	"math"
	"math/rand"
	"net/http"
	"os"
	"path"
	"runtime"
	"sort"
	"strconv"
	"strings"
)

type Rect struct {
	TopLeft image.Point
	Width   int
	Height  int
	Center  image.Point
	Text    string
}

type Device struct {
	SN              globalVariable.SN
	Sku             string
	Firmware        string
	TransFormMatrix *raytracer.Matrix
}

type Page struct {
	Elms         []Element
	IconElms     []Element
	Dev          *Device
	ScreenWidth  int
	ScreenHeight int
	ScreenShot   gocv.Mat
}

// 有道ocr识别的key
var (
	appKey    = "6b516f476e33fc38"
	appSecret = "ER95s6xLbCLt8IfPpb9zC5iHsxC6l53l"
)

// InitDevice 初始化设备，获取设备信息
func InitDevice(sn string) (d Device, err error) {
	if globalVariable.IsInDevice {
		d.SN = globalVariable.SN{sn}

		var sku string
		sku, err = inDevice.GetPenSKU()
		if err != nil {
			return d, errors.New("Device get sku failed! SN:" + sn + " err:" + err.Error() + " " + sku)
		}
		//fmt.Println(sku)
		var firmware string
		firmware, err = inDevice.GetPenFirmware()
		if err != nil {
			return d, errors.New("Device get firmware failed! SN:" + sn + " err:" + err.Error() + " " + firmware)
		}
		//fmt.Println(firmware)
		var msg string
		msg, err = inDevice.CopyInitialData()
		if err != nil {
			return d, errors.New("Copy initial data failed! SN:" + sn + " err:" + err.Error() + " " + msg)
		}
		//fmt.Println(msg)
		d = Device{SN: globalVariable.SN{sn}, Sku: sku, Firmware: firmware}

	} else {
		// 先检查有没有设备
		var devices [][]string
		devices, err = adbUtil.GetDevices()
		if err != nil || len(devices) < 1 {
			return
		}

		d.SN = globalVariable.SN{sn}

		var prodStr string
		prodStr, err = d.GetProductSerial()
		if err != nil {
			return Device{}, err
		}

		// 获取root权限
		var ok bool
		switch prodStr {
		case "dictpen":
			ok = adbUtil.Auth(sn)
		case "coco":
			ok = adbUtil.AuthCoco(sn)
		case "apollo":
			ok = adbUtil.Auth(sn)
		}
		if !ok {
			return d, errors.New("Device auth failed! SN:" + sn)
		}

		var sku string
		sku, err = adbUtil.GetPenSKU(sn)
		if err != nil {
			return d, errors.New("Device get sku failed! SN:" + sn)
		}
		var firmware string
		firmware, err = adbUtil.GetPenFirmware(sn)
		if err != nil {
			return d, errors.New("Device get firmware failed! SN:" + sn)
		}
		var version adbUtil.TestFilePackageVersion
		version, err = adbUtil.GetTestScriptsVersion()
		if err != nil {
			return d, errors.New("Test scripts damaged!Please download the latest version and try again!")
		}
		_, err = adbUtil.CheckScriptsVersion(sn, version.Version)
		if err != nil {
			_, err = adbUtil.PushScripts(sn)
			if err != nil {
				return d, err
			}
		}
		_, err = adbUtil.CopyInitialData(sn)

		d = Device{SN: globalVariable.SN{sn}, Sku: sku, Firmware: firmware}

	}
	var prod string
	prod, err = d.GetProductSerial()
	var transFormMatrix *raytracer.Matrix
	// 暂时只作词典笔和听力宝的屏幕适配
	switch prod {
	case "dictpen":
		// 注意因为屏幕坐标系是 --->x
		//                  |
		//                  V
		//                  y
		// 而我的光追引擎的坐标系是
		//                  y
		//                  ^
		//                  |
		//                  ---->x
		// 所以在这里要把x和y互换才能得到正确结果。。。
		translationMatrix := raytracer.Translation(800, 0, 0)
		rotationMatrix := raytracer.RotationZ(math.Pi / 2)           // rotationMatrix.Multiply(translationMatrix)
		transFormMatrix = translationMatrix.Multiply(rotationMatrix) //raytracer.Inverse(translationMatrix.Multiply(rotationMatrix))
	case "apollo":
		transFormMatrix = raytracer.EyeMatrix(4)
	case "coco":
		translationMatrix := raytracer.Translation(800, 113, 0)
		rotationMatrix := raytracer.RotationZ(math.Pi / 2)
		transFormMatrix = translationMatrix.Multiply(rotationMatrix)
	}
	d.TransFormMatrix = transFormMatrix

	return
}

// GetProductSerial 根据sn获取设备型号
func (d *Device) GetProductSerial() (string, error) {
	return d.SN.GetProductSerial()
}

func (d *Device) FetchScreenShot() (page Page, err error) {
	// 截图
	// 获取产品型号
	prod, err := d.GetProductSerial()
	if err != nil {
		return Page{}, err
	}
	var imgBase64 string
	if globalVariable.IsInDevice {
		switch prod {
		case "coco":
			imgBase64, err = inDevice.ScreenShotFfmpegFbdev()
		case "dictpen":
			_, _ = inDevice.FixClickFailedBugForCardMode()
			imgBase64, err = inDevice.ScreenShotFfmpeg()
		case "apollo":
			imgBase64, err = inDevice.ScreenShotFfmpeg()
		}
	} else {
		switch prod {
		case "coco":
			imgBase64, err = adbUtil.ScreenShotFfmpegFbdev(d.SN.Data)
		case "dictpen":
			_, _ = adbUtil.FixClickFailedBugForCardMode(d.SN.Data)
			imgBase64, err = adbUtil.ScreenShotFfmpeg(d.SN.Data)
		case "apollo":
			imgBase64, err = adbUtil.ScreenShotFfmpeg(d.SN.Data)
		}

	}

	if err != nil {
		panic("获取截图失败，请检查联系何江达" + err.Error())
	}
	img, err := Base64ToMat(imgBase64)
	if err != nil {
		panic("转换截图失败，请检查联系何江达" + err.Error())
	}
	// 顺时针转90度
	switch prod {
	case "dictpen":
		Rotate90ClockWise(&img)
	case "coco":
		Rotate90ClockWise(&img)
	case "apollo":
	}
	page.ScreenWidth = img.Cols()
	page.ScreenHeight = img.Rows()
	page.ScreenShot = img
	page.Dev = d
	return
}

// PathExists 判断路径是否存在
func PathExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}

// 查找元素思路：
// 1、获取截图得到page
// 2、识别图片和文字，把识别到的内容放到 Elms 和 IconElms
// 3、返回包含识别内容的page

// 执行截图记录思路：
// 1、先获取page
// 2、复制一份page中的图片
// 3、依据不同的操作进行记录：
// 	1、点击坐标：在被点击处画一个圈指出
//  2、点击文字：圈出整个字词所在的框
//  3、点击图片：圈出图片所在区域的框
//  4、滑动：圈出滑动的起点和终点

// LocateElementByTemplateMatch 模板匹配找元素
func (d *Device) LocateElementByTemplateMatch(tepl string, order int, threshold float32) (page Page, err error) {
	// 获取截图
	page, err = d.FetchScreenShot()
	img := page.ScreenShot
	// 匹配函数
	teplMatchFunc := func(teplFilePath string) (elms []Element, ok bool) {
		ok, err := PathExists(teplFilePath)
		var teplImg gocv.Mat
		type tmpElm struct {
			point image.Point
			score float32
		}
		var tmpElms []tmpElm
		if err != nil || !ok {
			filenameall := path.Base(tepl)
			filenameall = strings.TrimLeft(filenameall, "\\.")
			teplDownloadUrl := `https://hwp-static.inner.youdao.com/hwp/uiautomatic_template_img/` + filenameall

			// Get the Data
			resp, err := http.Get(teplDownloadUrl)
			if err != nil {
				panic(err)
			}
			defer resp.Body.Close()

			// 创建一个文件用于保存
			out, err := os.Create(teplFilePath)
			if err != nil {
				panic(err)
			}
			defer out.Close()

			// 然后将响应流和文件流对接起来
			_, err = io.Copy(out, resp.Body)
			if err != nil {
				panic(err)
			}
			teplImg = gocv.IMRead(teplFilePath, gocv.IMReadColor)
		} else {
			teplImg = gocv.IMRead(teplFilePath, gocv.IMReadColor)
		}
		if teplImg.Empty() {
			log.Println("获取模板图片失败")
			return nil, false
		}
		tmpPoints, tmpScores := TemplateMatch(img, teplImg, gocv.TmCcoeffNormed, threshold)
		for i := 0; i < len(tmpPoints); i++ {
			tmpElms = append(tmpElms, tmpElm{tmpPoints[i], tmpScores[i]})
		}
		sort.Slice(tmpElms, func(i, j int) bool {
			if tmpElms[i].point.Y != tmpElms[j].point.Y {
				return tmpElms[i].point.Y < tmpElms[j].point.Y
			}
			return tmpElms[i].point.X < tmpElms[j].point.X
		})

		for i, elm := range elms {
			fmt.Println("hjd test", elm.Box.Center, " index:", i)
		}
		for i, e := range tmpElms {
			elm := Element{
				Center: image.Point{e.point.X + teplImg.Cols()/2, e.point.Y + teplImg.Rows()/2},
				Box:    Rect{e.point, teplImg.Cols(), teplImg.Rows(), image.Point{e.point.X + teplImg.Cols()/2, e.point.Y + teplImg.Rows()/2}, "teplMatch_img" + strconv.Itoa(i+1)},
				Text:   "teplMatch_img" + strconv.Itoa(i),
				Type:   "img",
			}
			elms = append(elms, elm)
			ok = true
		}

		if order < len(tmpElms) {
			log.Println("    识别得分：", tmpElms[order].score, "坐标：", tmpElms[order].point.X+teplImg.Cols()/2, tmpElms[order].point.Y+teplImg.Rows()/2)
		} else {
			ok = false
			log.Println("    没有识别到第 " + strconv.Itoa(order+1) + " 张图片，识别到了 " + strconv.Itoa(len(tmpElms)) + " 张图片")
		}
		return
	}

	var iconElms []Element
	// 匹配得到所有找到的图片的位置
	elms, ok := teplMatchFunc(tepl)

	if ok {
		iconElms = elms
	}
	page.Elms = iconElms
	//fmt.Println(page.Elms)
	return
}

// LocateAllElementsByOcr ocr找元素
// 已支持在设备上运行
func (d *Device) LocateAllElementsByOcr() (page Page, err error) {
	// 获取截图
	page, err = d.FetchScreenShot()
	img := page.ScreenShot

	// 初始化有道ocr
	ocr := ydocr.NewOcr(appKey, appSecret)

	// 先不管返回按钮
	if globalVariable.IsInDevice {
		var elms []Element
		// 创建临时文件夹，用于存放给ocr识别的图片
		var dir string
		dir, err = ioutil.TempDir("", "dictpenUiAutomationTest")
		defer func(path string) {
			err = os.RemoveAll(path)
			if err != nil {

			}
		}(dir)
		if err != nil {
			log.Printf("can not create temporary directory err: %v", err)
			return
		}

		outputImgName := "screenshot.png"
		outputImgName = string(os.PathSeparator) + outputImgName
		// 图片写到一个临时文件夹
		gocv.IMWrite(dir+outputImgName, img)

		// 请求OCR识别结果
		// 读取图片然后识别
		var rsp []byte
		rsp, err = ocr.FileOcr(dir + outputImgName)
		if err != nil {
			log.Printf("base post err: %s", err)
			return
		}
		// 解析结果
		var l *ydocr.Line
		l, err = ydocr.Response2Line(rsp)
		if err != nil {
			log.Printf("response to line err: %s", err)
			return
		}
		// 遍历所得到的每个字的位置
		// 1. 遍历每个区域
		for _, region := range l.Result.Regions {
			// 2. 遍历每行
			for _, line := range region.Lines {
				var elm Element
				var c image.Point
				var box Rect
				coords := strings.Split(line.BoundingBox, ",")
				box.TopLeft.X, _ = strconv.Atoi(coords[0])
				box.TopLeft.Y, _ = strconv.Atoi(coords[1])

				bottomRight_X, _ := strconv.Atoi(coords[4])
				bottonRight_Y, _ := strconv.Atoi(coords[5])

				c.X = (box.TopLeft.X + bottomRight_X) / 2
				c.Y = (box.TopLeft.Y + bottonRight_Y) / 2

				box.Width = bottomRight_X - box.TopLeft.X
				box.Height = bottonRight_Y - box.TopLeft.Y
				box.Center = c
				elm.Box = box
				elm.Center = c
				elm.Text = line.Text
				// 遍历每个词（对于中文来说是单个字，对于英文来说是单词）
				for _, word := range line.Words {
					var box Rect
					var c image.Point
					coords := strings.Split(word.BoundingBox, ",")
					box.TopLeft.X, _ = strconv.Atoi(coords[0])
					box.TopLeft.Y, _ = strconv.Atoi(coords[1])

					bottomRight_X, _ := strconv.Atoi(coords[4])
					bottonRight_Y, _ := strconv.Atoi(coords[5])

					c.X = (box.TopLeft.X + bottomRight_X) / 2
					c.Y = (box.TopLeft.Y + bottonRight_Y) / 2
					box.Center = c
					box.Text = word.Word
					box.Width = bottomRight_X - box.TopLeft.X
					box.Height = bottonRight_Y - box.TopLeft.Y
					elm.WordArr = append(elm.WordArr, box)
				}
				//println(elm.Text)
				elm.Type = "text"
				elms = append(elms, elm)
			}
		}
		// 保存识别到的文字的位置
		page.Elms = elms

	} else {
		// 获取用户目录,用于获取返回按钮的模板图片
		var home string
		home, err = os.UserHomeDir()

		// 遗留代码，用于识别返回按钮
		teplMatchIcon := func(teplFilePath string) (elm Element, ok bool) {
			teplImg := gocv.IMRead(teplFilePath, gocv.IMReadColor)
			points, _ := TemplateMatch(img, teplImg, gocv.TmCcoeffNormed, 0.95)
			for _, point := range points {
				elm = Element{Center: image.Point{
					point.X + teplImg.Cols()/2, point.Y + teplImg.Rows()/2},
					Box:  Rect{point, teplImg.Cols(), teplImg.Rows(), image.Point{point.X + teplImg.Cols()/2, point.Y + teplImg.Rows()/2}, "back_btn"},
					Text: "back_btn",
					Type: "icon"}
				ok = true
			}
			return
		}

		var elms []Element
		var iconElms []Element

		// 返回按钮模板位置
		tepl_back_path := home + `/dictpenUiAutomaticTest/template/` + `back_btn.png`
		elm, ok := teplMatchIcon(tepl_back_path)

		// 先识别返回按钮
		if ok {
			elms = append(elms, elm)
			iconElms = append(iconElms, elm)
		}
		var tepl_path []string
		tepl_path = append(tepl_path, home+`/dictpenUiAutomaticTest/template/`+`back_btn.png`)
		var dir string
		dir, err = ioutil.TempDir("", "dictpenUiAutomationTest")
		defer func(path string) {
			err := os.RemoveAll(path)
			if err != nil {

			}
		}(dir)
		if err != nil {
			log.Printf("can not create temporary directory err: %v", err)
			return
		}
		sysType := runtime.GOOS
		outputImgName := "screenshot.png"
		switch sysType {
		case "darwin":
			outputImgName = "/" + outputImgName
		case "linux":
			outputImgName = "/" + outputImgName
		case "windows":
			outputImgName = "\\" + outputImgName
		}
		// 图片写到一个临时文件夹
		gocv.IMWrite(dir+outputImgName, img)

		// 请求OCR识别结果
		// 读取图片然后识别
		var rsp []byte
		rsp, err = ocr.FileOcr(dir + outputImgName)
		if err != nil {
			log.Printf("base post err: %s", err)
			return
		}
		// 解析结果
		var l *ydocr.Line
		l, err = ydocr.Response2Line(rsp)
		if err != nil {
			log.Printf("response to line err: %s", err)
			return
		}
		// 遍历所得到的每个字的位置
		// 1. 遍历每个区域
		for _, region := range l.Result.Regions {
			// 2. 遍历每行
			for _, line := range region.Lines {
				var elm Element
				var c image.Point
				var box Rect
				coords := strings.Split(line.BoundingBox, ",")
				box.TopLeft.X, _ = strconv.Atoi(coords[0])
				box.TopLeft.Y, _ = strconv.Atoi(coords[1])

				bottomRight_X, _ := strconv.Atoi(coords[4])
				bottonRight_Y, _ := strconv.Atoi(coords[5])

				c.X = (box.TopLeft.X + bottomRight_X) / 2
				c.Y = (box.TopLeft.Y + bottonRight_Y) / 2

				box.Width = bottomRight_X - box.TopLeft.X
				box.Height = bottonRight_Y - box.TopLeft.Y
				box.Center = c
				elm.Box = box
				elm.Center = c
				elm.Text = line.Text
				// 遍历每个词（对于中文来说是单个字，对于英文来说是单词）
				for _, word := range line.Words {
					var box Rect
					var c image.Point
					coords := strings.Split(word.BoundingBox, ",")
					box.TopLeft.X, _ = strconv.Atoi(coords[0])
					box.TopLeft.Y, _ = strconv.Atoi(coords[1])

					bottomRight_X, _ := strconv.Atoi(coords[4])
					bottonRight_Y, _ := strconv.Atoi(coords[5])

					c.X = (box.TopLeft.X + bottomRight_X) / 2
					c.Y = (box.TopLeft.Y + bottonRight_Y) / 2
					box.Center = c
					box.Text = word.Word
					box.Width = bottomRight_X - box.TopLeft.X
					box.Height = bottonRight_Y - box.TopLeft.Y
					elm.WordArr = append(elm.WordArr, box)
				}
				//println(elm.Text)
				elm.Type = "text"
				elms = append(elms, elm)
			}
		}
		// 保存识别到的文字的位置
		page.Elms = elms
	}

	return
}

// Transform 图片坐标与屏幕坐标转换
// 注意因为屏幕坐标系是 --->x
//                  |
//                  V
//                  y
// 而我的光追引擎的坐标系是
//                  y
//                  ^
//                  |
//                  ---->x
// 所以在这里要把x和y互换才能得到正确结果。。。
func (d *Device) Transform(origin image.Point) (screenPoint image.Point) {
	p := raytracer.MultiplyTuple(d.TransFormMatrix, raytracer.Point(float64(origin.Y), float64(origin.X), 0))
	screenPoint.X = int(p.Y)
	screenPoint.Y = int(p.X)
	return
}

// ShowInfo 打印设备信息
func (d *Device) ShowInfo() {
	log.Println(d)
}

// unicodeIndex 获取带中文的字符串中子字符串的实际位置，非字节位置
func unicodeIndex(str, substr string) int {
	// 子串在字符串的字节位置
	result := strings.Index(str, substr)
	if result > 0 {
		prefix := []byte(str)[0:result]
		rs := []rune(string(prefix))
		result = len(rs)
	}
	return result
}

// unicodeLen 获取带中文的字符串实际长度，非字节长度
func unicodeLen(str string) int {
	var r = []rune(str)
	return len(r)
}

// Click 按ocr得到的文字点击，返回点及矩形用于记录数据
func (p *Page) Click(text string) (point image.Point, rect Rect, err error) {
	var flag bool
	for _, elm := range p.Elms {
		// 对返回按钮特别处理
		if elm.Text == "back_btn" && text == "back_btn" {
			point = elm.Center
			rect = elm.Box

			screenPoint := p.Dev.Transform(elm.Center)
			if globalVariable.IsInDevice {
				_, err = inDevice.Click(screenPoint.X, screenPoint.Y)
			} else {

				_, err = adbUtil.Click(p.Dev.SN.Data, screenPoint.X, screenPoint.Y)
			}
			flag = true
			break
		} else if elm.Type == "text" && strings.Contains(elm.Text, text) {
			// 对ocr得到的文字点击
			loc := unicodeIndex(elm.Text, text)

			startIdx := 0
			wordStartIdx := 0
			wordEndIdx := 0
			for i, word := range elm.WordArr {
				if startIdx+unicodeLen(word.Text) >= loc {
					wordStartIdx = i
					break
				}
				startIdx += unicodeLen(word.Text)
			}
			for i, word := range elm.WordArr {
				if startIdx+unicodeLen(word.Text) >= loc+unicodeLen(text)-1 {
					wordEndIdx = i
					break
				}
				startIdx += unicodeLen(word.Text)
			}
			// 找到要点击的文本的开头和结尾(注意如果文字中存在英文，这个方案会出bug。。。)
			rect1 := elm.WordArr[wordStartIdx]
			rect2 := elm.WordArr[wordEndIdx]

			var finalCoord image.Point
			// 最终要点击的点在它们的中间
			finalCoord.X = (rect1.Center.X + rect2.Center.X) / 2
			finalCoord.Y = (rect1.Center.Y + rect2.Center.Y) / 2
			// 转换成设备屏幕上的点
			point = finalCoord
			rect = elm.Box
			screenPoint := p.Dev.Transform(finalCoord)
			//fmt.Println("screenPoint:", screenPoint)
			// 最终点击设备屏幕上的点
			if globalVariable.IsInDevice {
				_, err = inDevice.Click(screenPoint.X, screenPoint.Y)
			} else {

				_, err = adbUtil.Click(p.Dev.SN.Data, screenPoint.X, screenPoint.Y)
			}
			flag = true
			break
		} else if elm.Type == "img" && strings.Contains(elm.Text, text) {
			// 点击识别到的图片
			// 转换成设备屏幕上的点
			point = elm.Center
			rect = elm.Box
			screenPoint := p.Dev.Transform(elm.Center)
			// 最终点击设备屏幕上的点
			if globalVariable.IsInDevice {
				_, err = inDevice.Click(screenPoint.X, screenPoint.Y)
			} else {

				_, err = adbUtil.Click(p.Dev.SN.Data, screenPoint.X, screenPoint.Y)
			}
			flag = true
			break
		}
	}
	if err != nil {
		return
	}
	if !flag {
		return image.Point{}, Rect{}, errors.New("can not click text:" + text)
	}
	return
}

// Click_ShownScreen 点击图片上的坐标位置
func (p *Page) Click_ShownScreen(x int, y int) (err error) {
	screenPoint := p.Dev.Transform(image.Point{x, y})
	if globalVariable.IsInDevice {
		_, err = inDevice.Click(screenPoint.X, screenPoint.Y)
	} else {
		_, err = adbUtil.Click(p.Dev.SN.Data, screenPoint.X, screenPoint.Y)
	}

	return
}

// Slip_ShownScreen 按屏幕图片上的坐标滑动
func (p *Page) Slip_ShownScreen(p1, p2 image.Point, interval int) (err error) {
	p1 = p.Dev.Transform(p1)
	p2 = p.Dev.Transform(p2)
	prod, err := p.Dev.GetProductSerial()
	if err != nil {
		return
	}
	if globalVariable.IsInDevice {
		switch prod {
		case "dictpen":
			_, err = inDevice.Slip(p1.X, p1.Y, p2.X, p2.Y, interval)
		case "apollo":
			_, err = inDevice.Slip(p1.X, p1.Y, p2.X, p2.Y, interval)
		case "coco":
			_, err = inDevice.SlipCoco(p1.X, p1.Y, p2.X, p2.Y, interval)
		}
	} else {
		switch prod {
		case "dictpen":
			_, err = adbUtil.Slip(p.Dev.SN.Data, p1.X, p1.Y, p2.X, p2.Y, interval)
		case "apollo":
			_, err = adbUtil.Slip(p.Dev.SN.Data, p1.X, p1.Y, p2.X, p2.Y, interval)
		case "coco":
			_, err = adbUtil.SlipCoco(p.Dev.SN.Data, p1.X, p1.Y, p2.X, p2.Y, interval)
		}
	}
	return
}

// Slip_HalfShownScreen 滑动半个屏幕
func (p *Page) Slip_HalfShownScreen(mode string, interval int) (err error) {
	p1 := image.Point{p.ScreenWidth / 2, p.ScreenHeight / 2}
	var p2 image.Point
	prodName, err := p.Dev.GetProductSerial()
	if err != nil {
		return err
	}
	switch mode {
	case "left":
		p2 = image.Point{1, p.ScreenHeight / 2}
	case "right":
		p2 = image.Point{p.ScreenWidth - 1, p.ScreenHeight / 2}
	case "up":
		switch prodName {
		case "dictpen":
			p2 = image.Point{p.ScreenWidth / 2, 112}
		case "apollo":
			p2 = image.Point{p.ScreenWidth / 2, 1}
		case "coco":
			p2 = image.Point{p.ScreenWidth / 2, 1}
		}
	case "down":
		switch prodName {
		case "dictpen":
			p2 = image.Point{p.ScreenWidth / 2, 366}
		case "apollo":
			p2 = image.Point{p.ScreenWidth / 2, p.ScreenHeight - 1}
		case "coco":
			p2 = image.Point{p.ScreenWidth / 2, p.ScreenHeight - 1}
		}
	}
	//log.Println(p1, p2)
	return p.Slip_ShownScreen(p1, p2, interval)
}

// CheckContain 检查是否包含某个文字
func (p *Page) CheckContain(texts []string) (rects []Rect, err error) {
	var cnt int
	for _, text := range texts {
		for _, elm := range p.Elms {
			if strings.Contains(elm.Text, text) {
				rects = append(rects, elm.Box)
				cnt++
				break
			}
		}
	}
	if cnt != len(texts) {
		var txt string
		for _, text := range texts {
			txt += text + " "
		}
		return nil, errors.New("doesn't contain all texts:" + txt)
	}
	return
}
func (p *Page) CheckContainImg(text string) (rect Rect, err error) {
	for _, elm := range p.Elms {
		if elm.Type == "img" && strings.Contains(elm.Text, text) {
			rect = elm.Box
			return rect, nil
		}
	}
	return rect, errors.New("没有找到图片" + text)
}

// DrawCircle 画一个圈并返回这个Mat
func (p *Page) DrawCircle(src gocv.Mat, point image.Point, rgba color.RGBA) (err error) {
	if src.Empty() {
		return errors.New("cannot get screenshot mat")
	}
	gocv.Circle(&src, point, 5, rgba, 2)
	return nil
}

// DrawRectangle 画一个矩形
func (p *Page) DrawRectangle(src gocv.Mat, rectangle image.Rectangle, rgba color.RGBA) (err error) {
	if src.Empty() {
		return errors.New("cannot get screenshot")
	}
	gocv.Rectangle(&src, rectangle, rgba, 2)
	return nil
}

// DrawText 画一段文字
func (p *Page) DrawText(src gocv.Mat, text string, point image.Point, rgba color.RGBA) (err error) {
	if src.Empty() {
		return errors.New("cannot get screenshot")
	}
	gocv.PutText(&src, text, point, gocv.FontHersheySimplex, 1, rgba, 2)
	return nil
}

// Rotate90ClockWise 顺时针转90度
func Rotate90ClockWise(img *gocv.Mat) {
	gocv.Transpose(*img, img)
	gocv.Flip(*img, img, 1)
}

// TemplateMatch 模板匹配
func TemplateMatch(img0 gocv.Mat, tepl gocv.Mat, method gocv.TemplateMatchMode, threshold float32) (point []image.Point, score []float32) {
	img := gocv.NewMat()
	img0.CopyTo(&img)
	resultCols := img.Cols() - tepl.Cols() + 1
	resultRows := img.Rows() - tepl.Rows() + 1

	randImg := gocv.NewMatWithSize(tepl.Rows(), tepl.Cols(), gocv.MatTypeCV8UC3)
	randImgData, _ := randImg.DataPtrUint8()
	for i := 0; i < len(randImgData); i++ {
		randImgData[i] = uint8(rand.Intn(256))
	}
	matchResult := func(result gocv.Mat) bool {
		minVal, maxVal, minLoc, maxLoc := gocv.MinMaxLoc(result)
		//log.Println(minVal, minLoc, maxVal, maxLoc)
		switch method {
		case gocv.TmSqdiff:
			fallthrough
		case gocv.TmSqdiffNormed:
			// 目前不用这个比较方法
			if (1 - minVal) >= threshold {
				point = append(point, minLoc)
				score = append(score, 1-minVal)
				var kk = 0
				for i := minLoc.Y; i < minLoc.Y+tepl.Rows(); i++ {
					for j := minLoc.X; j < minLoc.X+tepl.Cols(); j++ {
						arr, err := img.DataPtrUint8()
						if err != nil {
							return false
						}

						for k := 0; k < 3; k++ {
							arr[i*img.Cols()*3+j*3+k] = randImgData[kk]
							kk++
						}
					}
				}
				return true
			}
		default:
			if maxVal >= threshold {
				// 1、获取位置和分数
				point = append(point, maxLoc)
				score = append(score, maxVal)
				var kk = 0
				for i := maxLoc.Y; i < maxLoc.Y+tepl.Rows(); i++ {
					for j := maxLoc.X; j < maxLoc.X+tepl.Cols(); j++ {
						arr, err := img.DataPtrUint8()
						if err != nil {
							return false
						}

						for k := 0; k < 3; k++ {
							arr[i*img.Cols()*3+j*3+k] = randImgData[kk]
							kk++
						}
					}
				}
				return true
			}
		}
		return false
	}
	// 单次匹配
	matchWithMask := func() bool {
		result := gocv.NewMatWithSize(resultCols, resultRows, gocv.MatTypeCV32FC1)
		gocv.MatchTemplate(img, tepl, &result, method, gocv.NewMat())
		//gocv.Normalize(result, &result, 0, 1, gocv.NormL2)
		return matchResult(result)
	}
	for i := 0; i < 10 && matchWithMask(); i++ {
	}
	return
}

func (r Rect) GetImageRect() (rect image.Rectangle) {
	rect.Min = r.TopLeft
	rect.Max.X = r.TopLeft.X + r.Width
	rect.Max.Y = r.TopLeft.Y + r.Height
	return
}
func Base64ToMat(b string) (img gocv.Mat, err error) {
	reader := base64.NewDecoder(base64.StdEncoding, strings.NewReader(b))
	m, _, err := image.Decode(reader)
	if err != nil {
		return gocv.Mat{}, err
	}
	img, err = gocv.ImageToMatRGB(m)
	if err != nil {
		return gocv.Mat{}, err
	}
	return
}
