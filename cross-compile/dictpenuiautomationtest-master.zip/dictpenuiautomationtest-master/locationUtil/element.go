package locationUtil

import "image"

type Element struct {
	Center  image.Point
	Box     Rect
	Text    string
	Type    string
	WordArr []Rect
}
