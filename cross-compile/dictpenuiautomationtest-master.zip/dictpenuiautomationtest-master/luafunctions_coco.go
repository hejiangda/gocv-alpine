package main

import (
	lua "github.com/yuin/gopher-lua"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/inDevice"
	"image"
	"log"
)

type Coco struct {
}

// ok
func (c *Coco) Click(L *lua.LState) int {
	incTestStep()
	return Click(L)
}

// ok
func (c *Coco) ClickCoordinate(L *lua.LState) int {
	incTestStep()
	return ClickCoordinate(L)
}

func (c *Coco) ClickScreenCoordinate(L *lua.LState) int {
	incTestStep()
	return ClickScreenCoordinate(L)
}
func (c *Coco) ClickImg(L *lua.LState) int {
	incTestStep()
	return ClickImg(L)
}
func (c *Coco) ClickPowerBtn(L *lua.LState) int {
	return c.clickPowerBtn(L)
}
func (c *Coco) ClickSoundHelperBtn(L *lua.LState) int {
	//return c.clickSoundHelperBtn(L)
	return ClickSoundHelperBtnCOCO(L)
}
func (c *Coco) SlipHalfScreen(L *lua.LState) int {
	incTestStep()
	return SlipHalfScreen(L)
}
func (c *Coco) SlipFromToCoordinate(L *lua.LState) int {
	incTestStep()
	return SlipFromToCoordinate(L)
}
func (c *Coco) SlipFromToScreenCoordinate(L *lua.LState) int {
	incTestStep()
	return SlipFromToScreenCoordinate(L)
}
func (c *Coco) SlipDropDownMenu(L *lua.LState) int {
	incTestStep()
	slipDropDownMenu := func(L *lua.LState) int {
		log.Println("滑动{下拉菜单}")
		interval := L.ToInt(1)
		if interval == 0 {
			interval = 5
		}
		page, err := device.FetchScreenShot()
		a := image.Point{
			X: 396,
			Y: 6,
		}
		b := image.Point{
			X: 396,
			Y: 251,
		}
		if err != nil {
			panic("  <font size=5 color=red >获取 page 失败,err:" + err.Error() + "</font>")
			return 1
		}
		saveScreenShot(page.ScreenShot, "下拉菜单前")
		err = page.Slip_ShownScreen(a, b, interval)
		page, err = device.FetchScreenShot()
		saveScreenShot(page.ScreenShot, "下拉菜单后")
		if err != nil {
			panic("  <font size=5 color=red >滑动失败{下拉菜单},err:" + err.Error() + "</font>")
			return 1
		}
		log.Println("  滑动成功{下拉菜单}")
		L.Push(lua.LBool(true))
		return 1
	}
	return slipDropDownMenu(L)
}
func (c *Coco) SleepForSecond(L *lua.LState) int {
	incTestStep()
	return SleepForSecond(L)
}
func (c *Coco) CheckContain(L *lua.LState) int {
	incTestStep()
	return CheckContain(L)
}
func (c *Coco) CheckImg(L *lua.LState) int {
	incTestStep()
	return CheckImg(L)
}
func (c *Coco) GoHome(L *lua.LState) int {
	incTestStep()
	err := L.DoString(`
	print("开始回到首页")
	click_xy(0,0)
	click_soundhelper() --点击【语音助手】物理按键
	wait(1)
	save_base64_img('1663_ndgp9l.png',"iVBORw0KGgoAAAANSUhEUgAAAAYAAADzCAYAAAClk2fiAAABQElEQVRYR+1XMaqDQBB9CwppbMUjaMDKE3iTHMDW3qOITa6RIl3sLGwtgiIoFioiGvez+4n8H23+74TZRvDtzM68mdmZZQA4dhYj4JMVomSTJ0QJUbIyQMlAyUDJACoDKgMqg/+Uga7r/HQ6SfKGYUDTNJjnGcy2ba6qKjjn8kfbtng+n2CO4/yaXpdlQZ7nW+CtciMhgGma9iXEORuJ1+uFLMvATNNczR3HEVVVoa5rME3TuKIo0g9hbt/3EJYd7WbwPI+fz2dJe5qmuF6v3w5mWcYNw5AOFkWB2+0G3/fBuNj6Y4koBkGwBcSeJEn2AXnGpyqh+X6/b4Gu63C5XMDiOOaWZa3mhmGIKIrAXNeV5goVZVni8XhASMl4MCY+kOB7HS1Q9FajtxrlLlUtDV50hR9uyqDmRc2Lmtffm9cXXrCDT9AaPE0AAAAASUVORK5CYII=")
	if check_img("1663_ndgp9l.png",1,0.90) --检查图片 默认检查第一张图片，默认阈值为0.90
	then 
	  slip('down')
	end
	print("已经回到首页")`)
	if err != nil {
		panic(err)
	}
	return 0
}
func (c *Coco) LogInfo(L *lua.LState) int {
	return LogInfo(L)
}
func (c *Coco) Print(L *lua.LState) int {
	return LogInfo(L)
}
func (c *Coco) ClickPhysicalButton(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()

	// click_physical_buttons("按键名","模式","持续时间")
	buttonName := L.ToString(1)

	L.Remove(1)
	switch buttonName {
	case "power":
		return c.clickPowerBtn(L)
	case "sound_helper":
		return ClickSoundHelperBtnCOCO(L)
	case "menu":
		return ClickSoundHelperBtnCOCO(L)
	case "led":
		return OpenCloseLedCOCO(L)
	}
	return unimplemented()
}
func (c *Coco) PlayMp3(L *lua.LState) int {
	return playMp3(L)
}
func (c *Coco) ScreenShot(L *lua.LState) int {
	return ScreenShot(L)
}

func (c *Coco) clickPowerBtn(L *lua.LState) int {
	ldelay := L.ToNumber(1)

	log.Println("点击{电源键}")
	var res string
	var err error
	if globalVariable.IsInDevice {
		res, err = inDevice.ClickPhysicsButtonExec32("power", int(ldelay*1000))
	} else {
		res, err = adbUtil.ClickPhysicsButtonExec32(device.SN.Data, "power", int(ldelay*1000))
	}
	if err != nil {
		panic("  <font size=5 color=red >点击失败{电源键},res: " + res + " err: " + err.Error() + "</font>")
		return 1
	}
	log.Println("  点击成功{电源键}")
	L.Push(lua.LBool(true))
	return 1
}

//// ClickSoundHelperBtn 点击语音助手按钮
//func (c *Coco) clickSoundHelperBtn(L *lua.LState) int {
//	lMode := L.ToString(1) // press release click
//	ldelay := L.ToNumber(2)
//	log.Println("点击{语音助手键}")
//	var res string
//	var err error
//	if globalVariable.IsInDevice {
//		switch lMode {
//		case "click":
//			res, err = inDevice.ClickPhysicsButtonExec32("menu", int(ldelay*1000))
//		case "press":
//			res, err = inDevice.SendEvent32([]string{"-obj", "menu", "-action", "press"})
//		case "release":
//			res, err = inDevice.SendEvent32([]string{"-obj", "menu", "-action", "release"})
//		default:
//			res, err = inDevice.ClickPhysicsButtonExec32("menu", int(ldelay*1000))
//		}
//	} else {
//		switch lMode {
//		case "click":
//			res, err = adbUtil.ClickPhysicsButtonExec32(device.SN.Data, "menu", int(ldelay*1000))
//		case "press":
//			res, err = adbUtil.SendEvent32(device.SN.Data, []string{"-obj", "menu", "-action", "press"})
//		case "release":
//			res, err = adbUtil.SendEvent32(device.SN.Data, []string{"-obj", "menu", "-action", "release"})
//		default:
//			res, err = adbUtil.ClickPhysicsButtonExec32(device.SN.Data, "menu", int(ldelay*1000))
//		}
//	}
//	if err != nil {
//		panic("  <font size=5 color=red >点击失败{语音助手键},res: " + res + " err: " + err.Error())
//		return 1
//	}
//	log.Println("  点击成功{语音助手键}")
//	L.Push(lua.LBool(true))
//	return 1
//}
