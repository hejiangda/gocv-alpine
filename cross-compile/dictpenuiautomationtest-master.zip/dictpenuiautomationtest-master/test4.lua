print("查词翻译 - 拆词 - 中文")
-- 回到首页
-- gohome()
-- wait(60)
-- 向上滑动
-- slip_screen_xy(419,238,417,7)
-- wait(2)

-- 判断
-- assert(check_img("815_33uf0v.png",1,0.95))
-- wait(2)

-- 点击单词本
-- click_img("815_qptzfl.png",1,0.95)
-- wait(2)

function a()
    a1 = 0
    while (a1 < 30)
    do
        if check_img("827_bd076f.png",1,0.95)
        then
            -- 点击《数据》
            click_img("827_bd076f.png",1,0.95)
            break
        else
            slip("up",1,3)
            --滑动半个屏幕，参数1为left,right,up,down，参数2为滑动的次数，参数3为滑动速度

            a1 = a1 + 1
        end
    end
end
a()

-- 点击《血》
click_img("827_1s4uo8.png",1,0.95)
wait(4)

-- 点击收藏
click_img("827_ig4jz2.png",1,0.95)
wait(2)

-- 取消收藏
click_img("827_iz8uxg.png",1,0.95)
wait(2)

-- 划出导航条
slip_screen_xy(794,126,474,128,20)
wait(2)

-- 点击有道汉语词典
click_img("827_hq0k18.png",1,0.95)
wait(2)

-- 收回导航条
slip_screen_xy(510,122,774,122,20)
wait(2)

------------------------------------------

-- 划出导航条
slip_screen_xy(794,126,474,128,20)
wait(2)

-- 点击双例句
click_img("827_u9v07u.png",1,0.95)
wait(2)

-- 收回导航条
slip_screen_xy(510,122,774,122,20)
wait(2)

-- 检查是否在双例句位置
check_img("827_yoka5w.png",1,0.95) --检查图片827_yoka5w.png默认检查第一张图片，默认阈值为0.95

wait(2)

------------------------------------------

-- 划出导航条
slip_screen_xy(794,126,474,128,20)
wait(2)

-- 点击有道汉语词典
click_img("827_tlnxvj.png",1,0.95)
wait(2)

-- 收回导航条
slip_screen_xy(510,122,774,122,20)
wait(2)

-- 点击《xiě》
click_img("827_8pny6b.png",1,0.95)
wait(2)

-- 检查是否在有道汉语释义位置
assert(check_img("827_tt343s.png",1,0.95))
wait(2)

------------------------------------------

-- 划出导航条
slip_screen_xy(794,126,474,128,20)
wait(2)

-- 向上滑动

slip_screen_xy(686,216,681,25,3) --按屏幕坐标滑动，参数分别是起终点坐标及滑动速度

-- wait(2)

-- 点击组词
click_img("827_05dncb.png",1,0.95) --点击图片827_05dncb.png默认检查第一张图片，默认阈值为0.95


wait(2)

-- 收回导航条
slip_screen_xy(510,122,774,122,20)
wait(2)

-- 判断是否在词组位置
assert(check_img("827_bp8vny.png",1,0.95))
wait(2)

-----------------------------------------

-- 划出导航条
slip_screen_xy(794,126,474,128,20)
wait(2)

-- 点击英汉大词典
click_img("827_06l81u.png",1,0.95)
wait(2)

-- 收回导航条
slip_screen_xy(510,122,774,122,20)
wait(2)

-- 检查是否在汉英大词典位置
assert(check_img("827_qzox59.png",1,0.95))
wait(2)

-- 点击《xuè》
click_img("827_my42ke.png",1,0.95)
wait(2)

a1 = 0
while (a1 < 30)
do
    if check_img("827_i8o3pk.png",1,0.95)
    then
        -- 点击《查看更多》
        click_img("827_i8o3pk.png",1,0.95)
        break
    else
        slip("up",1,3)
        wait(2)
        a1 = a1 + 1
    end
end

a2 = 0
while (a2 < 30)
do
    if check_img("827_mscy87.png",1,0.95)
    then
        break
    else
        slip("up",1,3)
        wait(4)
        a2 = a2 + 1
    end
end

-- 点击返回
click_img("827_8y7hm4.png",1,0.95)
wait(2)

-- 点击置顶按钮
click_img("827_d6bu6i.png",1,0.95)
wait(2)
