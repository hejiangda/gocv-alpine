package main

import (
	lua "github.com/yuin/gopher-lua"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/inDevice"
	"image"
	"log"
)

type InDeviceCoco struct {
}

// Click 点击ocr识别到的文字
func (c *InDeviceCoco) Click(L *lua.LState) int {
	incTestStep()
	ret := Click(L)
	return ret
}

// ClickCoordinate 点击屏幕原始坐标，只作调试用，不作截图记录
func (c *InDeviceCoco) ClickCoordinate(L *lua.LState) int {
	incTestStep()
	return ClickCoordinate(L)
}

// ClickScreenCoordinate 点击屏幕截图的坐标
func (c *InDeviceCoco) ClickScreenCoordinate(L *lua.LState) int {
	incTestStep()
	ret := ClickScreenCoordinate(L)
	return ret
}

// ClickImg 点击识别到的模板图片
func (c *InDeviceCoco) ClickImg(L *lua.LState) int {
	incTestStep()
	ret := ClickImg(L)
	return ret
}

// ClickPowerBtn 点击电源按钮
func (c *InDeviceCoco) ClickPowerBtn(L *lua.LState) int {
	return c.clickPowerBtn(L)
}

// ClickSoundHelperBtn 点击语音助手按钮
func (c *InDeviceCoco) ClickSoundHelperBtn(L *lua.LState) int {
	//return c.clickSoundHelperBtn(L)
	return ClickSoundHelperBtnCOCO(L)
}

// SlipHalfScreen 滑动半个屏幕
func (c *InDeviceCoco) SlipHalfScreen(L *lua.LState) int {
	incTestStep()
	return SlipHalfScreen(L)
}

// SlipFromToCoordinate 按设备屏幕原始坐标滑动，只作调试用，不作截图记录
func (c *InDeviceCoco) SlipFromToCoordinate(L *lua.LState) int {
	incTestStep()
	return SlipFromToCoordinate(L)
}

// SlipFromToScreenCoordinate 按屏幕截图上的坐标滑动
func (c *InDeviceCoco) SlipFromToScreenCoordinate(L *lua.LState) int {
	incTestStep()
	return SlipFromToScreenCoordinate(L)
}

// SlipDropDownMenu 下拉菜单
func (c *InDeviceCoco) SlipDropDownMenu(L *lua.LState) int {
	incTestStep()
	slipDropDownMenu := func(L *lua.LState) int {
		log.Println("滑动{下拉菜单}")
		interval := L.ToInt(1)
		if interval == 0 {
			interval = 5
		}
		page, err := device.FetchScreenShot()
		a := image.Point{
			X: 396,
			Y: 6,
		}
		b := image.Point{
			X: 396,
			Y: 251,
		}
		if err != nil {
			panic("  <font size=5 color=red >获取 page 失败,err:" + err.Error() + "</font>")
			return 1
		}
		saveScreenShot(page.ScreenShot, "下拉菜单前")
		err = page.Slip_ShownScreen(a, b, interval)
		page, err = device.FetchScreenShot()
		saveScreenShot(page.ScreenShot, "下拉菜单后")
		if err != nil {
			panic("  <font size=5 color=red >滑动失败{下拉菜单},err:" + err.Error() + "</font>")
			return 1
		}
		log.Println("  滑动成功{下拉菜单}")
		L.Push(lua.LBool(true))
		return 1
	}
	return slipDropDownMenu(L)
}

// SleepForSecond 睡几秒
func (c *InDeviceCoco) SleepForSecond(L *lua.LState) int {
	incTestStep()
	return SleepForSecond(L)
}

// CheckContain 检查文字是否存在
func (c *InDeviceCoco) CheckContain(L *lua.LState) int {
	incTestStep()
	return CheckContain(L)
}

// CheckImg 查找识别到的模板图片
func (c *InDeviceCoco) CheckImg(L *lua.LState) int {
	incTestStep()
	return CheckImg(L)
}

// GoHome 回首页
func (c *InDeviceCoco) GoHome(L *lua.LState) int {
	incTestStep()
	err := L.DoString(`
	print("开始回到首页")
	click_soundhelper() --点击【语音助手】物理按键
	wait(1)
	save_base64_img('1663_ndgp9l.png',"iVBORw0KGgoAAAANSUhEUgAAAAYAAADzCAYAAAClk2fiAAABQElEQVRYR+1XMaqDQBB9CwppbMUjaMDKE3iTHMDW3qOITa6RIl3sLGwtgiIoFioiGvez+4n8H23+74TZRvDtzM68mdmZZQA4dhYj4JMVomSTJ0QJUbIyQMlAyUDJACoDKgMqg/+Uga7r/HQ6SfKGYUDTNJjnGcy2ba6qKjjn8kfbtng+n2CO4/yaXpdlQZ7nW+CtciMhgGma9iXEORuJ1+uFLMvATNNczR3HEVVVoa5rME3TuKIo0g9hbt/3EJYd7WbwPI+fz2dJe5qmuF6v3w5mWcYNw5AOFkWB2+0G3/fBuNj6Y4koBkGwBcSeJEn2AXnGpyqh+X6/b4Gu63C5XMDiOOaWZa3mhmGIKIrAXNeV5goVZVni8XhASMl4MCY+kOB7HS1Q9FajtxrlLlUtDV50hR9uyqDmRc2Lmtffm9cXXrCDT9AaPE0AAAAASUVORK5CYII=")
	if check_img("1663_ndgp9l.png",1,0.90) --检查图片 默认检查第一张图片，默认阈值为0.90
	then 
	  slip('down')
	end
	print("已经回到首页")`)
	if err != nil {
		panic(err)
	}
	return 0
}

// LogInfo 输出带时间戳的文字
func (c *InDeviceCoco) LogInfo(L *lua.LState) int {
	return LogInfo(L)
}

// Print 输出带时间戳的文字
func (c *InDeviceCoco) Print(L *lua.LState) int {
	return LogInfo(L)
}
func (c *InDeviceCoco) ClickPhysicalButton(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()

	// click_physical_buttons("按键名","持续时间")
	buttonName := L.ToString(1)

	L.Remove(1)
	switch buttonName {
	case "power":
		return c.clickPowerBtn(L)
	case "sound_helper":
		return ClickSoundHelperBtnCOCO(L)
	case "menu":
		return ClickSoundHelperBtnCOCO(L)
	case "led":
		return OpenCloseLedCOCO(L)
	}
	return unimplemented()
}
func (c *InDeviceCoco) PlayMp3(L *lua.LState) int {
	return unimplemented()
}
func (c *InDeviceCoco) ScreenShot(L *lua.LState) int {
	return ScreenShot(L)
}

func (c *InDeviceCoco) clickPowerBtn(L *lua.LState) int {
	ldelay := L.ToNumber(1)

	log.Println("点击{电源键}")
	var res string
	var err error
	if globalVariable.IsInDevice {
		res, err = inDevice.ClickPhysicsButtonExec32("power", int(ldelay*1000))
	} else {
		res, err = adbUtil.ClickPhysicsButtonExec32(device.SN.Data, "power", int(ldelay*1000))
	}
	if err != nil {
		panic("  <font size=5 color=red >点击失败{电源键},res: " + res + " err: " + err.Error() + "</font>")
		return 1
	}
	log.Println("  点击成功{电源键}")
	L.Push(lua.LBool(true))
	return 1
}

//
//func (c *InDeviceCoco) clickSoundHelperBtn(L *lua.LState) int {
//	ldelay := L.ToNumber(1)
//	log.Println("点击{语音助手键}")
//	var res string
//	var err error
//	if globalVariable.IsInDevice {
//		res, err = inDevice.ClickPhysicsButtonExec32("menu", int(ldelay*1000))
//	} else {
//		res, err = adbUtil.ClickPhysicsButtonExec32(device.SN.Data, "menu", int(ldelay*1000))
//	}
//	if err != nil {
//		panic("  <font size=5 color=red >点击失败{语音助手键},res: " + res + " err: " + err.Error())
//		return 1
//	}
//	log.Println("  点击成功{语音助手键}")
//	L.Push(lua.LBool(true))
//	return 1
//}
