package ydocr

var Mbase64Encode = mbase64Encode
var MCountMd5 = mCountMd5
var CountSign = countSign
