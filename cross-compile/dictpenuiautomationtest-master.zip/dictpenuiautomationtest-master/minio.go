package main

import (
	"context"
	"github.com/minio/minio-go/v7"
	"time"

	"github.com/minio/minio-go/v7/pkg/credentials"
)

var minioClient *minio.Client

func InitMinioClient() (err error) {
	endpoint := "hwp-static.inner.youdao.com"
	accessKeyID := "H5LDI9RIW0NCWGHIIWP4"
	secretAccessKey := "YrUIdnBsFAbZP9jdwA4iQu+FiY+Qtj5cg2FQtdR8"
	useSSL := true
	minioClient, err = minio.New(endpoint, &minio.Options{
		Creds:  credentials.NewStaticV2(accessKeyID, secretAccessKey, ""),
		Secure: useSSL,
	})
	return err
}
func uploadImgFile(folder, imgName, imgPath string) (url string, err error) {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	// Make a new bucket called mymusic.
	bucketName := "testhjd"

	objectName := folder + "/" + imgName
	filePath := imgPath
	contentType := "image/jpeg"

	// Upload the zip file with FPutObject
	_, err = minioClient.FPutObject(ctx, bucketName, objectName, filePath, minio.PutObjectOptions{ContentType: contentType})
	if err != nil {
		return "", err
	}

	return "https://hwp-static.inner.youdao.com/" + bucketName + "/" + objectName, nil
}
func uploadGifImgFile(folder, imgName, imgPath string) (url string, err error) {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	bucketName := "testhjd"

	objectName := folder + "/" + imgName
	filePath := imgPath
	contentType := "image/gif"

	// Upload the zip file with FPutObject
	_, err = minioClient.FPutObject(ctx, bucketName, objectName, filePath, minio.PutObjectOptions{ContentType: contentType})
	if err != nil {
		return "", err
	}

	return "https://hwp-static.inner.youdao.com/" + bucketName + "/" + objectName, nil
}

func uploadMarkdownFile(folder, markdownName, markdownPath string) (url string, err error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	endpoint := "hwp-static.inner.youdao.com"
	accessKeyID := "H5LDI9RIW0NCWGHIIWP4"
	secretAccessKey := "YrUIdnBsFAbZP9jdwA4iQu+FiY+Qtj5cg2FQtdR8"
	useSSL := true

	// Initialize minio client object.
	minioClient, err := minio.New(endpoint, &minio.Options{
		Creds:  credentials.NewStaticV2(accessKeyID, secretAccessKey, ""),
		Secure: useSSL,
	})
	if err != nil {
		return "", err
	}

	// Make a new bucket called mymusic.
	bucketName := "testhjd"

	objectName := folder + "/" + markdownName
	filePath := markdownPath
	contentType := "text/markdown"

	// Upload the zip file with FPutObject
	_, err = minioClient.FPutObject(ctx, bucketName, objectName, filePath, minio.PutObjectOptions{ContentType: contentType})
	if err != nil {
		return "", err
	}
	return "https://hwp-static.inner.youdao.com/" + bucketName + "/" + objectName, nil
}
