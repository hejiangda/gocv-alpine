package main

import (
	"archive/tar"
	"bufio"
	"bytes"
	"compress/gzip"
	"encoding/json"
	"errors"
	"fmt"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/inDevice"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

func DownloadTestCaseLuaScript(caseManageId int) (ret string, err error) {
	// 下面这一大段用来请求用例信息，从用例管理id得到最终的用例id
	type caseDetail struct {
		Id       int    `json:"id"`
		FullPath string `json:"full_path"`
		Name     string `json:"name"`
		ItemId   int    `json:"item_id"`
		Type     string `json:"type"`
		Author   string `json:"author"`
	}
	caseDetailUrl := `https://hwp.inner.youdao.com/api/uiautomation/case_management/` + strconv.Itoa(caseManageId) + `/`
	getCaseDetailClient := http.Client{Timeout: time.Second * 2}
	caseDetailReq, err := http.NewRequest(http.MethodGet, caseDetailUrl, nil)
	if err != nil {
		return
	}
	caseDetailRes, err := getCaseDetailClient.Do(caseDetailReq)
	if err != nil {
		return "", err
	}
	defer caseDetailRes.Body.Close()
	if err != nil {
		return
	}
	caseDetailBody, err := ioutil.ReadAll(caseDetailRes.Body)
	if err != nil {
		return
	}
	var caseDetailJson caseDetail
	err = json.Unmarshal(caseDetailBody, &caseDetailJson)
	if err != nil {
		return
	}

	// 获取用例信息结束 caseDetailJson.ItemId中的就是实际用例脚本的id
	// 下面获取用例lua脚本
	// 1. 校验type是不是script
	// 2. 把脚本下载下来存放在临时文夹下
	type testCase struct {
		Id                int       `json:"id"`
		Name              string    `json:"name"`
		Author            string    `json:"author"`
		Luacode           string    `json:"luacode"`
		AddedTime         time.Time `json:"added_time"`
		ChineseAutherName string    `json:"chineseAutherName"`
	}
	if caseDetailJson.Type != "script" {
		err = errors.New("caseManageId 所表示的不是用例脚本")
	}
	testCaseUrl := `https://hwp.inner.youdao.com/api/uiautomation/case/` + strconv.Itoa(caseDetailJson.ItemId) + `/`
	getTestCaseClient := http.Client{Timeout: time.Second * 2}
	testCaseReq, err := http.NewRequest(http.MethodGet, testCaseUrl, nil)
	if err != nil {
		return
	}
	testCaseRes, err := getTestCaseClient.Do(testCaseReq)
	if err != nil {
		return "", err
	}
	defer testCaseRes.Body.Close()
	testCaseBody, err := ioutil.ReadAll(testCaseRes.Body)
	if err != nil {
		return
	}
	var testCaseJson testCase
	err = json.Unmarshal(testCaseBody, &testCaseJson)
	if err != nil {
		return
	}
	return testCaseJson.Luacode, err
}

type TestExecutionReport struct {
	Sn              string    `json:"sn"`
	Pcba            string    `json:"pcba"`
	Sku             string    `json:"sku"`
	FirmwareVersion string    `json:"firmwareVersion"`
	Tester          string    `json:"tester"`
	CaseGroupName   string    `json:"caseGroupName"`
	CaseIds         string    `json:"caseIds"`
	FailedCaseIds   string    `json:"failedCaseIds"`
	StartTime       time.Time `json:"startTime"`
	FinishTime      time.Time `json:"finishTime"`
	LogUrl          string    `json:"logUrl"`
}
type TestExecutionReportWithId struct {
	Id int `json:"id"`
	TestExecutionReport
}

func BatchExecute(testGroupId int, sn, tester string) {
	type testCaseGroupStruct struct {
		ID                      int         `json:"id"`
		Name                    string      `json:"name"`
		ExecuteCaseManagementID string      `json:"execute_caseManagementId"`
		ExecuteTime             interface{} `json:"execute_time"`
		ExecuteHistory          string      `json:"execute_history"`
		CurrentExecuteOrder     int         `json:"current_execute_order"`
	}
	testCaseGroupUrl := `https://hwp-backend.inner.youdao.com/api/uiautomation/test_execute_group/` + strconv.Itoa(testGroupId) + `/`
	getTestCaseGroupClient := http.Client{Timeout: time.Second * 2}
	testCaseGroupReq, err := http.NewRequest(http.MethodGet, testCaseGroupUrl, nil)
	if err != nil {
		panic(err)
	}
	testCaseGroupRes, err := getTestCaseGroupClient.Do(testCaseGroupReq)
	if err != nil {
		panic(err)
	}
	defer testCaseGroupRes.Body.Close()
	if err != nil {
		panic(err)
	}
	caseDetailBody, err := ioutil.ReadAll(testCaseGroupRes.Body)
	if err != nil {
		panic(err)
	}
	var testCaseGroupJSON testCaseGroupStruct
	err = json.Unmarshal(caseDetailBody, &testCaseGroupJSON)
	if err != nil {
		panic(err)
	}
	//fmt.Println(testCaseGroupJSON)
	ids := testCaseGroupJSON.ExecuteCaseManagementID

	// 已经获取到了所有的case id
	var cases []int
	err = json.Unmarshal([]byte(ids), &cases)
	if err != nil {
		panic(err)
	}

	startTime := time.Now()
	timeUnix := startTime.UnixMilli()
	mLocation := strconv.Itoa(int(timeUnix))
	var executedCaseIds []string
	var failedCaseIds []string

	var report TestExecutionReport
	report.Sn = sn
	adbUtil.SetAdbExecutable()
	adbUtil.Auth(sn)
	report.Pcba, err = adbUtil.GetPenPCBA(sn)
	if err != nil {
		panic(err)
	}
	report.Sku, err = adbUtil.GetPenSKU(sn)
	if err != nil {
		panic(err)
	}
	report.FirmwareVersion, err = adbUtil.GetPenFirmware(sn)
	if err != nil {
		panic(err)
	}
	// TODO: 先这么写，之后改
	if tester == "" {
		tester = "ci"
	}
	report.Tester = tester
	report.CaseGroupName = testCaseGroupJSON.Name
	report.CaseIds = "[]"
	report.FailedCaseIds = "[]"
	report.StartTime = startTime
	report.FinishTime = time.Now()
	report.LogUrl = "https://hwp-static.inner.youdao.com/testhjd/" + strconv.Itoa(int(report.StartTime.UnixMilli())) + "/"

	// 创建report到 /api/v1/uiautomation/testlog/ 接口
	crearteExecuteReportUrl := "https://hwp.inner.youdao.com/api/v1/uiautomation/testlog/"
	method := "POST"
	client := &http.Client{}
	reportJson, _ := json.Marshal(report)
	payload := bytes.NewBuffer(reportJson)
	req, err := http.NewRequest(method, crearteExecuteReportUrl, payload)

	if err != nil {
		panic(err)
	}
	req.Header.Add("Content-Type", "application/json")

	res, err := client.Do(req)
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		panic(err)
	}
	//fmt.Println(string(body))

	var postedResult TestExecutionReportWithId

	err = json.Unmarshal(body, &postedResult)
	if err != nil {
		panic(err)
	}
	//fmt.Println(postedResult)

	//testExecuteId := postedResult.Id
	for _, c := range cases {
		caseId := strconv.Itoa(c)
		for j := 0; j < 3; j++ {
			currCaseId := caseId

			if j != 0 {
				//caseId += "-" + strconv.Itoa(j)
				currCaseId = caseId + "-" + strconv.Itoa(j)
			}
			log.Println("Executing case ", currCaseId)
			err = ExecOneCase(c, sn, currCaseId, mLocation)
			executedCaseIds = append(executedCaseIds, currCaseId)
			tmpCaseIds, _ := json.Marshal(executedCaseIds)
			postedResult.CaseIds = string(tmpCaseIds)
			postedResult.FinishTime = time.Now()
			if err == nil {
				_ = patchTestExecuteLog(postedResult)
				break
			} else {
				failedCaseIds = append(failedCaseIds, currCaseId)
				tmpfailedCaseIds, _ := json.Marshal(failedCaseIds)
				postedResult.FailedCaseIds = string(tmpfailedCaseIds)
				_ = patchTestExecuteLog(postedResult)
			}
			time.Sleep(5 * time.Second)
		}
		time.Sleep(1 * time.Second)
	}
	report.FinishTime = postedResult.FinishTime
	executedCaseVincent := "["
	lenExecuted := len(executedCaseIds)
	for i, id := range executedCaseIds {
		if i < lenExecuted-1 {
			executedCaseVincent += id + ","
		} else {
			executedCaseVincent += id
		}
	}
	executedCaseVincent += "]"
	failedCaseVincent := "["
	lenFailed := len(failedCaseIds)
	for i, id := range failedCaseIds {
		if i < lenFailed-1 {
			failedCaseVincent += id + ","
		} else {
			failedCaseVincent += id
		}
	}
	failedCaseVincent += "]"
	report.CaseIds = executedCaseVincent
	report.FailedCaseIds = failedCaseVincent

	fmt.Println("执行的用例：", executedCaseIds)
	fmt.Println("失败的用例：", failedCaseIds)
	_, err = postTestExecuteLogToVincent(report)
	if err != nil {
		panic(err)
	}
	err = PostProfitReport(report)
	if err != nil {
		panic(err)
	}

}
func PostProfitReport(report TestExecutionReport) error {
	postUrl := "https://hwp.inner.youdao.com/api/add_data/"
	method := "POST"

	params := url.Values{}
	params.Add("productLine", "1")
	params.Add("toolName", "智能硬件UI自动化测试")
	params.Add("finalProfit", strconv.Itoa(int(report.FinishTime.Unix()-report.StartTime.Unix())/60+1))
	params.Add("userID", report.Tester)
	params.Add("deviceID", report.Sn)
	params.Add("comment", report.CaseGroupName)

	payload := strings.NewReader(params.Encode())
	client := &http.Client{}
	req, err := http.NewRequest(method, postUrl, payload)

	if err != nil {
		//fmt.Println(err)
		return err
	}
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	res, err := client.Do(req)
	if err != nil {
		//fmt.Println(err)
		return err
	}
	defer res.Body.Close()

	_, err = ioutil.ReadAll(res.Body)
	if err != nil {
		//fmt.Println(err)
		return err
	}
	//fmt.Println(string(body))
	return nil

}

type vincentResult struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    struct {
		ReportID    int    `json:"reportID"`
		ProductName string `json:"productName"`
		JobName     string `json:"jobName"`
		Sku         string `json:"sku"`
		Pcba        string `json:"pcba"`
		DeviceID    string `json:"deviceID"`
		VersionInfo string `json:"versionInfo"`
		UserID      string `json:"userID"`
		CaseAmount  int    `json:"caseAmount"`
		CaseID      string `json:"caseID"`
		Modules     struct {
			测试代码 int `json:"测试代码"`
		} `json:"modules"`
		FailedAmount int         `json:"failedAmount"`
		FailedID     string      `json:"failedID"`
		StartTime    string      `json:"startTime"`
		FinishTime   string      `json:"finishTime"`
		TimeConsumed int         `json:"timeConsumed"`
		CaseStep     int         `json:"caseStep"`
		LogURL       string      `json:"logURL"`
		Comment      interface{} `json:"comment"`
	} `json:"data"`
}

func postTestExecuteLogToVincent(report TestExecutionReport) (*vincentResult, error) {
	postUrl := "https://hwp.inner.youdao.com/api/ui_test_report/upload/"
	method := "POST"

	params := url.Values{}
	params.Add("sku", report.Sku)
	params.Add("deviceID", report.Sn)
	params.Add("versionInfo", report.FirmwareVersion)
	params.Add("pcba", report.Pcba)
	params.Add("userID", report.Tester)
	params.Add("caseID", report.CaseIds)
	params.Add("failedID", report.FailedCaseIds)
	// 这里时间的格式需要好好调一下

	//startTimeStr := strconv.Itoa(report.StartTime.Year()) + "-" + strconv.Itoa(report.StartTime.Month())
	params.Add("startTime", report.StartTime.Format("2006-01-02 15:04:05"))
	params.Add("finishTime", report.FinishTime.Format("2006-01-02 15:04:05"))
	params.Add("logURL", report.LogUrl)
	params.Add("jobName", report.CaseGroupName)

	payload := strings.NewReader(params.Encode())
	client := &http.Client{}
	req, err := http.NewRequest(method, postUrl, payload)

	if err != nil {
		return nil, err
	}
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	res, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return nil, err
	}
	var result vincentResult
	err = json.Unmarshal(body, &result)
	if err != nil {
		return nil, err
	}
	return &result, nil
}

func patchTestExecuteLog(report TestExecutionReportWithId) error {
	patchUrl := "https://hwp.inner.youdao.com/api/v1/uiautomation/testlog/" + strconv.Itoa(report.Id) + "/"
	method := "PATCH"
	client := &http.Client{}
	patchReport := TestExecutionReport{
		Sn:              report.Sn,
		Pcba:            report.Pcba,
		Sku:             report.Sku,
		FirmwareVersion: report.FirmwareVersion,
		Tester:          report.Tester,
		CaseGroupName:   report.CaseGroupName,
		CaseIds:         report.CaseIds,
		FailedCaseIds:   report.FailedCaseIds,
		StartTime:       report.StartTime,
		FinishTime:      report.FinishTime,
		LogUrl:          report.LogUrl,
	}
	reportJson, _ := json.Marshal(patchReport)
	payload := bytes.NewBuffer(reportJson)
	req, err := http.NewRequest(method, patchUrl, payload)

	if err != nil {
		//fmt.Println(err)
		return err
	}
	req.Header.Add("Content-Type", "application/json")

	res, err := client.Do(req)
	if err != nil {
		//fmt.Println(err)
		return err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		//fmt.Println(err)
		return err
	}
	//fmt.Println(string(body))

	var postedResult TestExecutionReportWithId

	err = json.Unmarshal(body, &postedResult)
	if err != nil {
		return err
	}
	//fmt.Println(postedResult)
	return nil
}
func ExecOneCaseLocal(caseid int, sn, logname, mLocation, testCaseGroupDir string, noNetwork bool) error {
	var args []string
	if noNetwork {
		args = []string{"-cmd", "start", "-case", strconv.Itoa(int(caseid)) + ".lua", "-sn", sn, "-logFileName", logname + `.md`, "-logImgOpenFlag", "false"}
	} else {
		args = []string{"-cmd", "start", "-case", strconv.Itoa(int(caseid)) + ".lua", "-sn", sn, "-logFileName", logname + `.md`, "-minioLocation", mLocation, "-logImgOpenFlag", "true"}
	}
	exePath, err := func() (string, error) {
		file, err := exec.LookPath(os.Args[0])
		if err != nil {
			return "", err
		}
		path, err := filepath.Abs(file)
		if err != nil {
			return "", err
		}
		return path, err
	}()
	fmt.Println(exePath, args)
	cmd := exec.Command(exePath, args...)

	cmd.Dir = testCaseGroupDir
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	scannerStdout := bufio.NewScanner(stdout)
	scannerStdout.Split(bufio.ScanLines)
	err = cmd.Start()
	for scannerStdout.Scan() {
		m := scannerStdout.Text() + "\n"
		log.Printf("%s", m)
	}
	err = cmd.Wait()
	return err
}
func ExecOneCase(caseid int, sn, logname, mLocation string) error {
	args := []string{"-cmd", "start", "-caseManageId", strconv.Itoa(int(caseid)), "-sn", sn, "-logFileName", logname + `.md`, "-minioLocation", mLocation, "-logImgOpenFlag", "true"}
	exePath, err := func() (string, error) {
		file, err := exec.LookPath(os.Args[0])
		if err != nil {
			return "", err
		}
		path, err := filepath.Abs(file)
		if err != nil {
			return "", err
		}
		return path, err
	}()
	fmt.Println(exePath, args)
	cmd := exec.Command(exePath, args...)
	tempDir, err := ioutil.TempDir("", "dictpenCase")
	if err != nil {
		return err
	}
	cmd.Dir = tempDir
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	scannerStdout := bufio.NewScanner(stdout)
	scannerStdout.Split(bufio.ScanLines)
	err = cmd.Start()
	for scannerStdout.Scan() {
		m := scannerStdout.Text() + "\n"
		log.Printf("%s", m)
	}
	err = cmd.Wait()
	return err
}

// 执行打包后的测试执行集
func LocalBatchExecute(testGroupFileName, sn, tester, cmd1 string) {
	var noNetwork bool
	if cmd1 == "local" {
		noNetwork = true
	}
	// 创建临时文件夹
	executeFolder, err := os.MkdirTemp("", "executeCase")
	if err != nil {
		panic(err)
	}
	// 解压
	err = UnTar(executeFolder, testGroupFileName)
	if err != nil {
		panic(err)
	}
	// 获取执行集的执行顺序
	caseRank, err := os.ReadFile(executeFolder + string(os.PathSeparator) + "caseRank.json")
	if err != nil {
		panic(err)
	}
	// 已经获取到了所有的case id
	var cases []int
	err = json.Unmarshal(caseRank, &cases)
	if err != nil {
		panic(err)
	}
	fmt.Println(cases)

	// 开始测试的时间
	startTime := time.Now()
	timeUnix := startTime.UnixMilli()
	// 测试图片保存的位置
	mLocation := strconv.Itoa(int(timeUnix))
	if noNetwork {
		mLocation = ""
	}
	// 执行的用例
	var executedCaseIds []string
	// 失败的用例
	var failedCaseIds []string

	// 测试结果上报
	var report TestExecutionReport
	report.Sn = sn

	// 获取设备信息
	if globalVariable.IsInDevice {
		report.Pcba, err = inDevice.GetPenPCBA()
		if err != nil {
			panic(err)
		}
		report.Sku, err = inDevice.GetPenSKU()
		if err != nil {
			panic(err)
		}
		report.FirmwareVersion, err = inDevice.GetPenFirmware()
		if err != nil {
			panic(err)
		}
	} else {
		adbUtil.SetAdbExecutable()
		adbUtil.Auth(sn)
		report.Pcba, err = adbUtil.GetPenPCBA(sn)
		if err != nil {
			panic(err)
		}
		report.Sku, err = adbUtil.GetPenSKU(sn)
		if err != nil {
			panic(err)
		}
		report.FirmwareVersion, err = adbUtil.GetPenFirmware(sn)
		if err != nil {
			panic(err)
		}
	}

	// TODO: 先这么写，之后改
	if tester == "" {
		tester = "ci"
	}
	report.Tester = tester
	report.CaseGroupName = testGroupFileName
	report.CaseIds = "[]"
	report.FailedCaseIds = "[]"
	report.StartTime = startTime
	report.FinishTime = time.Now()
	report.LogUrl = "https://hwp-static.inner.youdao.com/testhjd/" + strconv.Itoa(int(report.StartTime.UnixMilli())) + "/"

	body, err := report2UiautomationTestlog(report)

	var postedResult TestExecutionReportWithId
	reportReady := false
	if err == nil {
		reportReady = true
		err = json.Unmarshal(body, &postedResult)
		if err != nil {
			panic(err)
		}
	}

	// 这里正式开始执行测试用例了
	var trueFailedCasesCnt int
	for _, c := range cases {
		caseId := strconv.Itoa(c)
		// 每个用例跑三次，成功则不用管，失败了要重试
		for j := 0; j < 3; j++ {
			currCaseId := caseId
			if j != 0 {
				currCaseId = caseId + "-" + strconv.Itoa(j)
			}
			log.Println("Executing case ", currCaseId)
			// 执行用例包中的用例
			err = ExecOneCaseLocal(c, sn, currCaseId, mLocation, executeFolder, noNetwork)

			executedCaseIds = append(executedCaseIds, currCaseId)
			tmpCaseIds, _ := json.Marshal(executedCaseIds)
			postedResult.CaseIds = string(tmpCaseIds)
			postedResult.FinishTime = time.Now()
			if err == nil {
				if reportReady {
					_ = patchTestExecuteLog(postedResult)
				}
				break
			} else {
				failedCaseIds = append(failedCaseIds, currCaseId)
				tmpfailedCaseIds, _ := json.Marshal(failedCaseIds)
				postedResult.FailedCaseIds = string(tmpfailedCaseIds)
				if reportReady {
					_ = patchTestExecuteLog(postedResult)
				}
				// popo发消息
				if tester != "ci" {
					logurl := url.QueryEscape(`https://hwp-static.inner.youdao.com/testhjd/` + mLocation + `/` + caseId + `-2.md`)
					message := `UI自动化测试，执行集：` + path.Base(testGroupFileName) + " 中的用例「" + caseId + "」测试失败\r\n" +
						"设备SN：" + sn + " sku：" + report.Sku + "\r\n固件：" +
						report.FirmwareVersion + " 电路板：" + report.Pcba + "\r\n" +
						"详细测试日志请看：\r\n" +
						`https://hwp.inner.youdao.com/ui-test-report/testlog?` + logurl
					popoPeopleAlert(message, tester)
				}
				trueFailedCasesCnt++
			}
			time.Sleep(5 * time.Second)
		}
		time.Sleep(1 * time.Second)
	}
	report.FinishTime = postedResult.FinishTime
	executedCaseVincent := "["
	lenExecuted := len(executedCaseIds)
	for i, id := range executedCaseIds {
		if i < lenExecuted-1 {
			executedCaseVincent += id + ","
		} else {
			executedCaseVincent += id
		}
	}
	executedCaseVincent += "]"
	failedCaseVincent := "["
	lenFailed := len(failedCaseIds)
	for i, id := range failedCaseIds {
		if i < lenFailed-1 {
			failedCaseVincent += id + ","
		} else {
			failedCaseVincent += id
		}
	}
	failedCaseVincent += "]"
	report.CaseIds = executedCaseVincent
	report.FailedCaseIds = failedCaseVincent

	fmt.Println("执行的用例：", executedCaseIds)
	fmt.Println("失败的用例：", failedCaseIds)
	if reportReady {
		testlogVincentResult, err := postTestExecuteLogToVincent(report)
		//
		//	UI自动化测试，执行集：apollo工具研发 测试完成
		//	设备SN：5B80600002502296 sku：REPEATER_RA1_SKU_CHN_STD
		//	固件：1.2.0 电路板：Apollo_V0
		//	总共测试了 15 条用例，成功 13 条，失败 2 条
		//	详细测试报告请看：
		//https://hwp.inner.youdao.com/ui-test-report/reportdetail/1203
		if tester != "ci" {
			message := `UI自动化测试，执行集：` + path.Base(testGroupFileName) + " 测试完成\r\n" +
				"设备SN：" + sn + " sku：" + report.Sku + "\r\n固件：" +
				report.FirmwareVersion + " 电路板：" + report.Pcba + "\r\n" +
				"总共测试了 " + strconv.Itoa(len(cases)) + " 条用例，成功 " + strconv.Itoa(len(cases)-trueFailedCasesCnt) + " 条，失败 " + strconv.Itoa(trueFailedCasesCnt) + " 条" +
				"详细测试报告请看：\r\n" +
				"https://hwp.inner.youdao.com/ui-test-report/reportdetail/" + strconv.Itoa(testlogVincentResult.Data.ReportID)
			popoPeopleAlert(message, tester)
		}

		if err != nil {
			fmt.Println(err)
			//panic(err)
		}
		err = PostProfitReport(report)
		if err != nil {
			fmt.Println(err)
			//panic(err)
		}
	}
}

func report2UiautomationTestlog(report TestExecutionReport) ([]byte, error) {
	// 创建report到 /api/v1/uiautomation/testlog/ 接口
	crearteExecuteReportUrl := "https://hwp.inner.youdao.com/api/v1/uiautomation/testlog/"
	method := "POST"
	client := &http.Client{Timeout: 1 * time.Second}
	reportJson, _ := json.Marshal(report)
	payload := bytes.NewBuffer(reportJson)
	req, err := http.NewRequest(method, crearteExecuteReportUrl, payload)

	// 因为这个有大概率在离线场景下用，上报失败就失败吧
	if err != nil {
		return nil, err
	}
	req.Header.Add("Content-Type", "application/json")

	res, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return nil, err
	}
	return body, err
}

func popoPeopleAlert(message, rd string) {

	baseUrl := "http://ci.corp.youdao.com/jenkins/job/NotifyPOPO/buildWithParameters"
	method := "POST"

	params := url.Values{}
	params.Add("message", message)
	params.Add("email", rd+"@rd.netease.com")
	payload := strings.NewReader(params.Encode())

	client := &http.Client{}
	req, err := http.NewRequest(method, baseUrl, payload)

	if err != nil {
		fmt.Println(err)
		return
	}
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	_, err = client.Do(req)
	if err != nil {
		fmt.Println(err)
		return
	}
}
func UnTar(dst, src string) (err error) {
	// 打开准备解压的 tar 包
	fr, err := os.Open(src)
	if err != nil {
		return
	}
	defer fr.Close()

	// 将打开的文件先解压
	gr, err := gzip.NewReader(fr)
	if err != nil {
		return
	}
	defer gr.Close()

	// 通过 gr 创建 tar.Reader
	tr := tar.NewReader(gr)

	// 现在已经获得了 tar.Reader 结构了，只需要循环里面的数据写入文件就可以了
	for {
		hdr, err := tr.Next()

		switch {
		case err == io.EOF:
			return nil
		case err != nil:
			return err
		case hdr == nil:
			continue
		}

		// 处理下保存路径，将要保存的目录加上 header 中的 Name
		// 这个变量保存的有可能是目录，有可能是文件，所以就叫 FileDir 了……
		dstFileDir := filepath.Join(dst, hdr.Name)

		// 根据 header 的 Typeflag 字段，判断文件的类型
		switch hdr.Typeflag {
		case tar.TypeDir: // 如果是目录时候，创建目录
			// 判断下目录是否存在，不存在就创建
			// 判断目录是否存在
			ExistDir := func(dirname string) bool {
				fi, err := os.Stat(dirname)
				return (err == nil || os.IsExist(err)) && fi.IsDir()
			}
			if b := ExistDir(dstFileDir); !b {
				// 使用 MkdirAll 不使用 Mkdir ，就类似 Linux 终端下的 mkdir -p，
				// 可以递归创建每一级目录
				if err := os.MkdirAll(dstFileDir, 0775); err != nil {
					return err
				}
			}
		case tar.TypeReg: // 如果是文件就写入到磁盘
			// 创建一个可以读写的文件，权限就使用 header 中记录的权限
			// 因为操作系统的 FileMode 是 int32 类型的，hdr 中的是 int64，所以转换下
			file, err := os.OpenFile(dstFileDir, os.O_CREATE|os.O_RDWR, os.FileMode(hdr.Mode))
			if err != nil {
				return err
			}
			_, err = io.Copy(file, tr)
			if err != nil {
				return err
			}
			// 将解压结果输出显示
			//fmt.Printf("成功解压： %s , 共处理了 %d 个字符\n", dstFileDir, n)

			// 不要忘记关闭打开的文件，因为它是在 for 循环中，不能使用 defer
			// 如果想使用 defer 就放在一个单独的函数中
			file.Close()
		}
	}

	return nil
}
