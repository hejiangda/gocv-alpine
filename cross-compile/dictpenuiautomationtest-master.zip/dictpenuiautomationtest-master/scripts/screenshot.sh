#!/bin/sh
# auth: 何江达
# 截图并返回图片文件名，可能有问题
# 图片放在/tmp下

cd /userdisk/dictpenUiAutomaticTest/scripts/ || exit
sh ./touch.sh wake
cd /tmp || exit

if weston-screenshooter > /dev/null 2>&1
then
  ls -t wayland-screenshot* |head -n 1 | tr -d '\r\n'
else
  echo "error cannot get screenshot!"
fi
# 返回到之前的工作目录
cd - >/dev/null || exit
