#!/bin/sh
# auth: 何江达
# 复制数据库到词典笔

cp /userdisk/dictpenUiAutomaticTest/scripts/databases/wordbook.db /userdisk/database/wordbook.db
cp /userdisk/dictpenUiAutomaticTest/scripts/databases/history.db /userdisk/database/history.db
cp /userdisk/dictpenUiAutomaticTest/scripts/databases/calculateFavorite.db  /userdisk/math/calculateFav/calculateFavorite.db

# 复制写作指导的历史数据
cp -r /userdisk/dictpenUiAutomaticTest/scripts/articles /userdisk/articles
