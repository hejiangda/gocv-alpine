#!/bin/bash
export CGO_LDFLAGS=
export CGO_CPPFLAGS=
export CGO_CXXFLAGS=
cp ../gocv_static/arm64/cgo_static.go ../../vendor/gocv.io/x/gocv/cgo_static.go

cd ../../
# build clickPhysicsButtonExecutable_arm64
echo "-- build clickPhysicsButtonExecutable_arm64 --"
cd clickPhysicsButtonExecutable || exit
go build -o clickPhysicsButtonExecutableArm64 -ldflags '-s -w --extldflags "-static -fpic"'
mv clickPhysicsButtonExecutableArm64 ../

cd ../
# build slipExecutable
echo "-- build slipExecutableArm64 --"
cd slipExecutable||exit
go build -o slipExecutableArm64 -ldflags '-s -w --extldflags "-static -fpic"'
mv slipExecutableArm64 ../

cd ../
# build sendEventArm64
echo "-- build sendEventArm64 --"
cd sendEvent ||exit
go build -o sendEventArm64 -ldflags '-s -w --extldflags "-static -fpic"'
mv sendEventArm64 ../
