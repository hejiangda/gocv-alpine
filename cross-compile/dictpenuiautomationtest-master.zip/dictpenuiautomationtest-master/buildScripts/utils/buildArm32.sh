#!/bin/bash
export CGO_LDFLAGS=
export CGO_CPPFLAGS=
export CGO_CXXFLAGS=
cp ../gocv_static/arm32/cgo_static.go ../../vendor/gocv.io/x/gocv/cgo_static.go

cd ../../
# build clickPhysicsButtonExecutable_arm32
echo "-- build clickPhysicsButtonExecutable_arm32 --"
cd clickPhysicsButtonExecutable || exit
go build -o clickPhysicsButtonExecutableArm32 -ldflags '-s -w --extldflags "-static -fpic"'
mv clickPhysicsButtonExecutableArm32 ../

cd ../
# build slipExecutable
echo "-- build slipExecutableArm32 --"
cd slipExecutable||exit
go build -o slipExecutableArm32 -ldflags '-s -w --extldflags "-static -fpic"'
mv slipExecutableArm32 ../

cd ../
# build sendEventArm32
echo "-- build sendEventArm32 --"
cd sendEvent ||exit
go build -o sendEventArm32 -ldflags '-s -w --extldflags "-static -fpic"'
mv sendEventArm32 ../
