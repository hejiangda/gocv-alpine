#!/bin/bash
export CGO_LDFLAGS=
export CGO_CPPFLAGS=
export CGO_CXXFLAGS=
cp gocv_static/arm32/cgo_static.go ../vendor/gocv.io/x/gocv/cgo_static.go

cd ../
echo "-- build dictpenUiAutomationTest_arm32 --"
go build -tags "static embed" -o dictpenUiAutomationTest_arm32
