click("查词翻译")
