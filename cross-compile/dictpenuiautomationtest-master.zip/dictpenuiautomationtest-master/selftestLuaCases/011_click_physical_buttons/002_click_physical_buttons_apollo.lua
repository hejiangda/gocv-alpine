click_physical_buttons("volume_up")
