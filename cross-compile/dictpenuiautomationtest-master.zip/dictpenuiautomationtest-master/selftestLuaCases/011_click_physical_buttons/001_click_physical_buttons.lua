click_physical_buttons("power",1)
