check("查词")
