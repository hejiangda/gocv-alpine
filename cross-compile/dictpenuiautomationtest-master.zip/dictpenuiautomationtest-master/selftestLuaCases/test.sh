#!/bin/bash

../dictpenUiAutomationTest_mac  -case 001_click/001_click.lua
