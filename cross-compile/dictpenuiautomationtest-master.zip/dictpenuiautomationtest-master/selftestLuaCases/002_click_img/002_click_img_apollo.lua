click_img("1183_s8qs8u.png",1,0.80)
click_img("1183_q7plem.png",1,0.80)
