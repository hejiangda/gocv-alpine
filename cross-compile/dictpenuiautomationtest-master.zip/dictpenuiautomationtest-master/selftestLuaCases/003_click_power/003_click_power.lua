print("click_power")
-- 有问题
click_power(1)
