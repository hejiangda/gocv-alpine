check_img("1183_s8qs8u.png",1,0.80)
