check_img("1181_uknjjo.png",1,0.80)
