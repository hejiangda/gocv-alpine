click_soundhelper(1)
