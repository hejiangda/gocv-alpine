package inDevice

import (
	"errors"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"io"
	"os"
	"os/exec"
	"strconv"
	"time"
)

// FixClickFailedBugForCardMode 修复在一些页面上因研发确保笔不熄屏死循环发送事件导致笔无法控制的问题
func FixClickFailedBugForCardMode() (string, error) {
	//cmd := exec.Command("ps|grep", "input-event", "|grep", "-v", "grep", "|head", "-n", "1", "|awk", "'{printf $1}'", "|xargs", "-t", "kill", "-USR2")
	cmd := exec.Command("sh", "/userdisk/dictpenUiAutomaticTest/scripts/inDeviceScripts/fixClickFailedBug.sh")
	msg, err := cmd.CombinedOutput()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// WakeScreen 唤醒屏幕
func WakeScreen() (string, error) {
	var tmpSn globalVariable.SN
	tmpSn.Data = globalVariable.Sn
	arch := "arm64"
	if prod, err := tmpSn.GetProductSerial(); err == nil && prod == "coco" {
		arch = "arm32"
	}
	var msg []byte
	var err error
	if arch == "arm64" {
		cmd := exec.Command(`sh`, `/userdisk/dictpenUiAutomaticTest/scripts/touch.sh`, arch, `wake`)
		msg, err = cmd.Output()
		defer func() { cmd.Process.Kill() }()
	} else {
		cmd := exec.Command(`hal-screen`, `on`)
		msg, err = cmd.Output()
		defer func() { cmd.Process.Kill() }()
	}
	return string(msg), err

}

// ScreenShotFfmpeg 词典笔3566、3326、apollo截图 64bit ffmpeg kmsgrab
func ScreenShotFfmpeg() (base64 string, err error) {
	_, err = WakeScreen()
	if err != nil {
		return "", err
	}
	//cmd := exec.Command(`/bin/sh`, "ffmpeg", "-loglevel", "quiet", "-f", "kmsgrab", "-i", "-", "-vf", "'hwdownload,format=bgr0'", "-framerate", "60", "-frames:v", "1", "-c:v", "png", "-f", "image2pipe", "-", "|base64")
	cmd := exec.Command(`sh`, "/userdisk/dictpenUiAutomaticTest/scripts/inDeviceScripts/screenShotFfmpeg.sh")
	msg, err := cmd.CombinedOutput()
	defer func() { cmd.Process.Kill() }()
	base64 = string(msg)
	if base64 == "" {
		return "", errors.New("screenshot failed")
	}
	return
}

// Click 点击原始坐标
// coco可用
func Click(x int, y int) (string, error) {
	//clickCmd := "\"sh /userdisk/dictpenUiAutomaticTest/scripts/touch.sh click " + strconv.Itoa(x) + " " + strconv.Itoa(y) + " \""
	var tmpSn globalVariable.SN
	tmpSn.Data = globalVariable.Sn
	arch := "arm64"
	if prod, err := tmpSn.GetProductSerial(); err == nil && prod == "coco" {
		arch = "arm32"
	}
	//cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `sh`, `/userdisk/dictpenUiAutomaticTest/scripts/touch.sh`, arch, `click`, strconv.Itoa(x), strconv.Itoa(y))

	cmd := exec.Command(`sh`, `/userdisk/dictpenUiAutomaticTest/scripts/touch.sh`, arch, `click`, strconv.Itoa(x), strconv.Itoa(y))
	msg, err := cmd.Output()
	time.Sleep(time.Second)
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// GetPenSKU 获取SKU
// 不支持coco
func GetPenSKU() (string, error) {
	var tmpSn globalVariable.SN
	tmpSn.Data = globalVariable.Sn
	product, _ := tmpSn.GetProductSerial()
	if product == "coco" {
		return GetCocoSKU()
	}
	temp, err := CreateTempScript(`/usr/bin/vendor_storage -r VENDOR_CUSTOM_ID_0E -t string | tr -s ' ' | cut -d ' ' -f 2 | tr -d '\r\n'`)
	if err != nil {
		return "", err
	}
	defer func() { temp.Close(); os.RemoveAll(temp.Name()) }()
	cmd := exec.Command("sh", temp.Name())
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill(); temp.Close(); os.RemoveAll(temp.Name()) }()
	return string(msg), err
}
func GetCocoSKU() (string, error) {
	script, err := CreateTempScript(`yd_misc_info_tool -r YD_LINUX_SKU_ID -t string | tr -d '\r\n'`)
	if err != nil {
		return "", err
	}
	defer func() { script.Close(); os.RemoveAll(script.Name()) }()
	cmd := exec.Command(`sh`, script.Name())
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill(); script.Close(); os.RemoveAll(script.Name()) }()
	return string(msg)[17:], err
}
func CreateTempScript(cmd string) (*os.File, error) {
	// 创建临时文件，用来存放脚本
	temp, err := os.CreateTemp("", "uiAutomation.*.sh")
	if err != nil {
		return nil, err
	}
	// 写入脚本文件
	_, err = io.WriteString(temp, cmd)
	if err != nil {
		return nil, err
	}
	return temp, err
}

// GetPenFirmware 获取笔的固件型号
func GetPenFirmware() (string, error) {
	var tmpSn globalVariable.SN
	tmpSn.Data = globalVariable.Sn
	prod, _ := tmpSn.GetProductSerial()
	if prod == "coco" {
		return GetCocoFirmware()
	}

	script, err := CreateTempScript(`cat /Version | tail -n 1  |tr -s ' ' |cut -d ' ' -f 2 | tr -d '\\r\\n'`)
	if err != nil {
		return "", err
	}
	cmd := exec.Command(`sh`, script.Name())
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill(); script.Close(); os.RemoveAll(script.Name()) }()
	return string(msg), err
}
func GetCocoFirmware() (string, error) {
	script, err := CreateTempScript(`head -n 1 Version |tr -d '\r\n'`)
	if err != nil {
		return "", err
	}
	cmd := exec.Command(`sh`, script.Name())
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill(); script.Close(); os.RemoveAll(script.Name()) }()
	return string(msg)[9:], err
}

// CopyInitialData 针对测试用数据拷到词典笔中对应数据库的位置
func CopyInitialData() (string, error) {
	cmd := exec.Command(`sh`, `/userdisk/dictpenUiAutomaticTest/scripts/copyDbs.sh`)
	cmd1 := exec.Command(`sh`, `/userdisk/dictpenUiAutomaticTest/scripts/copyMusic.sh`)
	msg, err := cmd.CombinedOutput()
	defer func() { cmd.Process.Kill(); cmd1.Process.Kill() }()
	if err != nil {
		return string(msg), err
	}
	msg1, err := cmd1.CombinedOutput()

	return string(msg) + string(msg1), err
}

// Slip 原始坐标滑动
func Slip(x1 int, y1 int, x2 int, y2 int, interval int) (string, error) {
	cmd := exec.Command(`/userdisk/dictpenUiAutomaticTest/scripts/slipExecutableArm64`, `-arch`, "arm64", `-x1`, strconv.Itoa(x1), "-y1", strconv.Itoa(y1), "-x2", strconv.Itoa(x2), "-y2", strconv.Itoa(y2), "-interval", strconv.Itoa(interval))
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// SlipCoco Coco原始坐标滑动
func SlipCoco(x1 int, y1 int, x2 int, y2 int, interval int) (string, error) {
	cmd := exec.Command(`/userdisk/dictpenUiAutomaticTest/scripts/32bit/slipExecutableArm32`, `-arch`, "arm32", `-x1`, strconv.Itoa(x1), "-y1", strconv.Itoa(y1), "-x2", strconv.Itoa(x2), "-y2", strconv.Itoa(y2), "-interval", strconv.Itoa(interval))
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// ClickPhysicsButtonExec 点击物理按钮
func ClickPhysicsButtonExec(command string, elapse int) (string, error) {
	args := []string{`-cmd`, command, `-elapse`, strconv.Itoa(elapse)}
	cmd := exec.Command(`/userdisk/dictpenUiAutomaticTest/scripts/clickPhysicsButtonExecutableArm64`, args...)
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// ClickPhysicsButtonExec32 32位版点击物理按钮
func ClickPhysicsButtonExec32(command string, elapse int) (string, error) {
	args := []string{`-cmd`, command, `-elapse`, strconv.Itoa(elapse)}
	cmd := exec.Command(`/userdisk/dictpenUiAutomaticTest/scripts/32bit/clickPhysicsButtonExecutableArm32`, args...)
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func SendEvent32(command []string) (string, error) {
	cmd := exec.Command(`/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32`, command...)
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// ClickPower 点击电源按键
func ClickPower(t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec("power", int(t*1000))
	return ret, err
}

// ClickSoundHelper 点击语音助手按键
func ClickSoundHelper(t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec("menu", int(t*1000))
	return ret, err
}

// ClickLed 闪一下扫描灯
func ClickLed(t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec("led", int(t*1000))
	return ret, err
}

// ClickLedCOCO 闪一下扫描灯
func ClickLedCOCO(t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec32("led", int(t*1000))
	return ret, err
}
func SendEvent64(command []string) (string, error) {
	cmd := exec.Command(`/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64`, command...)
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// KillDictPenUi 词典笔回到首页
func KillDictPenUi() (string, error) {
	cmd := exec.Command(`sh`, `/userdisk/dictpenUiAutomaticTest/scripts/inDeviceScripts/killDictPenUi.sh`)
	msg, err := cmd.CombinedOutput()
	defer func() { cmd.Process.Kill() }()
	time.Sleep(time.Second * 15)
	return string(msg), err
}

func GetPenPCBA() (string, error) {
	script, err := CreateTempScript(`get_pcba_version | tr -d '\r\n'`)
	if err != nil {
		return "", err
	}
	cmd := exec.Command("sh", script.Name())
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill(); script.Close(); os.RemoveAll(script.Name()) }()
	return string(msg), err
}
