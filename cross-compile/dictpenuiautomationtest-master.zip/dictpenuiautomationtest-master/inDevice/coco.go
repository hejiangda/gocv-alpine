package inDevice

import (
	"errors"
	"io"
	"os"
	"os/exec"
)

// ScreenShotFfmpegFbdev coco截图 32位ffmpeg fbdev
func ScreenShotFfmpegFbdev() (base64 string, err error) {
	_, err = WakeScreen()
	if err != nil {
		return "", err
	}
	// adb shell "ffmpeg -loglevel quiet  -f kmsgrab -i - -vf 'hwdownload,format=bgr0' -framerate  60 -frames:v 1 -c:v png -f image2pipe - |base64"|base64 -d  >abc.png
	// ./ffmpeg  -f fbdev -framerate 60 -i /dev/fb0  -frames:v 1 screenshot7.png

	// 创建临时文件，用来存放截图脚本
	temp, err := os.CreateTemp("", "screenshot.*.sh")
	if err != nil {
		return
	}
	defer os.Remove(temp.Name())
	// 写入截图脚本
	_, err = io.WriteString(temp, "/userdisk/dictpenUiAutomaticTest/scripts/32bit/ffmpeg -loglevel quiet -f fbdev -framerate 60 -i /dev/fb0 -frames:v 1 -c:v png -f image2pipe - |base64")
	if err != nil {
		return
	}
	// 运行截图命令
	cmd := exec.Command("/bin/sh", temp.Name())
	msg, err := cmd.CombinedOutput()

	defer func() { cmd.Process.Kill() }()
	base64 = string(msg)
	if base64 == "" {
		return "", errors.New("screenshot failed")
	}
	return
}
