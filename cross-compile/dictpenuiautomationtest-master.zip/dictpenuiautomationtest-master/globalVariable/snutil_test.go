package globalVariable

import (
	"fmt"
	"testing"
)

func TestSn_FormatValidation(t *testing.T) {

	sn := SN{Data: "2B72700001914797"}
	ok, err := sn.FormatValidation()
	fmt.Println(ok, err)
}

func TestSn_ExtractFactoryCode(t *testing.T) {
	sn := SN{Data: "2B72700001914797"}
	code, err := sn.ExtractFactoryCode()
	fmt.Println(code, err)
}

func TestSn_ExtractSpecialCode(t *testing.T) {
	sn := SN{Data: "2B72700001914797"}
	code, err := sn.ExtractSpecialCode()
	fmt.Println(code, err)
}
