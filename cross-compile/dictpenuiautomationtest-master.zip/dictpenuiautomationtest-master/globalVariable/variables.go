package globalVariable

const VERSION = "v1.11.2"

var (
	CurrentOS   string
	CurrentArch string
	IsInDevice  bool
	Sn          string
)
