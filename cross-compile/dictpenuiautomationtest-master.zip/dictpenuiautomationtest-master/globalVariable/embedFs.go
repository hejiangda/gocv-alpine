//go:build windows || darwin || embed

package globalVariable

import (
	"embed"
)

//go:embed dictpenUiAutomaticTest/sendEventArm32
//go:embed dictpenUiAutomaticTest/clickPhysicsButtonExecutableArm32
//go:embed dictpenUiAutomaticTest/slipExecutableArm32
var EmFS embed.FS
