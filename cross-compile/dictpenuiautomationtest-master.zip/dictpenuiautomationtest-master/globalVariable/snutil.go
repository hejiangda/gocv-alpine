package globalVariable

import (
	"errors"
	"regexp"
)

/**
 * 和SN相关的工具方法
 *
 * SN 构成规则：
 *      编码规则:
 *      工厂代码（1位）+生产日期（4位）+特殊代码（6位）+流水号（5位）
 *
 *      工厂代码：1-9、A、B、C..依次类推（英文字母O和I跳过、不采用）
 *      生产日期：
 *          年份1位，2011-2019年用数字1到9表示，2020年用A，之后以B/C/D顺延，字母O和I跳过、不采用；
 *          月份1位，1-9,10月用A表示、11月用B表示、12月用C表示
 *          日期2位
 *      特殊代码：对应有道产品型号的6位编码，有道统一分配
 *      流水号：00001开始，数字表示
 */

type SN struct {
	Data string
}

func (s *SN) CheckEmpty() bool {
	if s.Data == "" {
		return true
	}
	return false
}
func (s *SN) FormatValidation() (bool, error) {
	if s.CheckEmpty() {
		return false, errors.New("sn为空")
	}
	want := regexp.MustCompile("^[A-Z1-9][A-Z][A-C1-9]((0+[1-9])|((1|2)[0-9])|30|31)[0-9]{6}[0-9]{5}")
	return want.MatchString(s.Data), nil
}
func (s *SN) ExtractFactoryCode() (string, error) {
	if ok, err := s.FormatValidation(); ok == false || err != nil {
		return "", err
	}
	return s.Data[0:1], nil
}

func (s *SN) ExtractSpecialCode() (string, error) {
	if ok, err := s.FormatValidation(); ok == false || err != nil {
		return "", err
	}
	return s.Data[5:11], nil
}

func (s *SN) GetProductSerial() (string, error) {
	if s.Data == "0123456789" {
		return "coco", nil
	}
	if s.Data == "0123456789ABCDEF" {
		return "coco", nil
	}
	spcode, err := s.ExtractSpecialCode()
	if err != nil {
		return "", err
	}
	switch spcode {
	case "000025":
		return "apollo", nil
	case "000007":
		return "dictpen2", nil
	case "000008":
		return "dictpen2", nil
	case "000009":
		return "dictpen2", nil
	case "000017":
		return "dictpen2", nil
	case "000030":
		return "dictpen", nil
	case "000032":
		return "dictpen2", nil
	case "000034":
		return "dictpen2", nil
	case "000035":
		return "dictpen2", nil
	case "000003":
		return "dictpen", nil
	case "000006":
		return "dictpen", nil
	case "000018":
		return "dictpen", nil
	case "000010":
		return "dictpen", nil
	case "000011":
		return "dictpen", nil
	case "000019":
		return "dictpen", nil
	case "000020":
		return "dictpen", nil
	case "000021":
		return "dictpen", nil
	case "000036":
		return "coco", nil
	case "000037":
		return "coco", nil
	}

	return "dictpen", nil
}

//
///**
// * 提取日期
// *
// * @param sn sn
// * @return {@link LocalDate}
// */
//public static LocalDate extractDate(String sn){
//if(formatValidation(sn)) {
//int i = sn.toCharArray()[1] - '1';
//int intYear;
//if (i > 10) {
//intYear = 2020 + sn.toCharArray()[1] - 'A';
//} else {
//intYear = 2011 + i;
//}
//int month = sn.toCharArray()[2] - '1' + 1;
//
//int day = Integer.parseInt(sn.substring(3, 5));
//return LocalDate.of(intYear, month, day);
//}
//return null;
//}
//
