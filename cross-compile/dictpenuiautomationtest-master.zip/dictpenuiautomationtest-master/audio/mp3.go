package audio

import (
	"github.com/faiface/beep"
	"github.com/faiface/beep/mp3"
	"github.com/faiface/beep/speaker"
	"os"
	"time"
)

func PlayMp3(filePath string, done chan bool, dura chan time.Duration) {
	f, err := os.Open(filePath)
	if err != nil {
		panic(err)
	}

	streamer, format, err := mp3.Decode(f)
	if err != nil {
		panic(err)
	}
	dura <- format.SampleRate.D(streamer.Len())
	//fmt.Println("mp3 duration:", format.SampleRate.D(streamer.Len()))

	defer streamer.Close()

	speaker.Init(format.SampleRate, format.SampleRate.N(time.Second/20))

	speaker.Play(beep.Seq(streamer, beep.Callback(func() {
		done <- true
	})))

	<-done
}
