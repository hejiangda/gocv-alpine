package aladdin
