-- 未登录
-- 进入个人中心
print("点击头像")
wait(1)
click_img("53_lj1ejv.png")
wait(3)

-- 点击“？”
print("点击[?]")
wait(1)
click_img("53_pe77jx.png")
wait(2)

-- 上滑动
print("向上滑动")
slip("up")
slip("up")
slip("up")

-- 返回扫描登录页面
print("返回扫描登录页面")
click("back_btn")
wait(3)

-- 返回词典笔首页面
print("返回词典笔首页面")
click("back_btn")
wait(3)
