package adbUtil

import (
	"errors"
	"fmt"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"
)

var adbExecutable string
var shellName string
var shellArgForStringInput string
var sysType string

// SetAdbExecutable 设置具体的adb命令
func SetAdbExecutable() {
	sysType = runtime.GOOS
	home, _ := os.UserHomeDir()
	switch sysType {
	case "darwin":
		adbExecutable = home + "/dictpenUiAutomaticTest/bin/mac/adb"
		shellName = "bash"
		shellArgForStringInput = "-c"
	case "linux":
		adbExecutable = home + "/dictpenUiAutomaticTest/bin/linux/adb"
		shellName = "bash"
		shellArgForStringInput = "-c"
	case "windows":
		adbExecutable = home + "\\dictpenUiAutomaticTest\\bin\\win\\adb.exe"
		shellName = "powershell"
		shellArgForStringInput = "-Command"
	}
	if CheckGlobalAdb() {
		adbExecutable = "adb"
	}
}

// CheckGlobalAdb 判断path中是否存在adb
func CheckGlobalAdb() (ok bool) {
	want := regexp.MustCompile("Android Debug Bridge version")
	cmd := exec.Command("adb", "--version")
	res, err := cmd.Output()
	if !want.MatchString(string(res)) || err != nil {
		return false
	}
	return true
}

// ExecAdb 运行adb执行命令
func ExecAdb(arg string) (string, error) {
	cmd := exec.Command(adbExecutable, arg)
	stdout, err := cmd.Output()
	if err != nil {
		fmt.Println(err.Error())
		return "", err
	}
	return string(stdout), nil
}

// GetDevices 获取设备的sn
func GetDevices() ([][]string, error) {
	adbResultOrigin, err := ExecAdb("devices")
	var SNs [][]string
	if err != nil {
		return SNs, err
	}
	getDevices := regexp.MustCompile("[a-zA-Z0-9]{16}")
	SNs = getDevices.FindAllStringSubmatch(adbResultOrigin, -1)
	if len(SNs) <= 0 {
		// 针对coco的临时sn单独处理
		getCocoTemp := regexp.MustCompile("0123456789")
		SNs = getCocoTemp.FindAllStringSubmatch(adbResultOrigin, -1)
		if len(SNs) <= 0 {
			return SNs, errors.New("device not found")
		}
	}
	return SNs, err
}

// Auth 词典笔 3566 3326 听力宝的密码
func Auth(sn string) bool {
	var tmpSn globalVariable.SN
	tmpSn.Data = sn
	product, _ := tmpSn.GetProductSerial()
	if product == "coco" {
		return AuthCoco(sn)
	}
	cmd := exec.Command(shellName, shellArgForStringInput, `echo CherryYoudao| `+adbExecutable+` -s `+sn+` shell auth`)
	if sysType == "windows" {
		fmt.Println(shellName, shellArgForStringInput)
		cmd = exec.Command(shellName, shellArgForStringInput, `&{ echo CherryYoudao | `+adbExecutable+` -s `+sn+` shell auth }`)
	}
	stdout, err := cmd.Output()
	adbResultOrigin := string(stdout)
	if err != nil {
		return false
	}
	checkAuthSuccess := regexp.MustCompile("success.")
	ok := checkAuthSuccess.MatchString(adbResultOrigin)
	//fmt.Println(adbResultOrigin, ok)
	return ok
}

// AuthCoco coco的root密码
func AuthCoco(sn string) bool {
	cmd := exec.Command(shellName, shellArgForStringInput, `echo coCo20220307| `+adbExecutable+` -s `+sn+` shell auth`)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, `&{ echo coCo20220307 | `+adbExecutable+` -s `+sn+` shell auth }`)
	}
	stdout, err := cmd.Output()
	adbResultOrigin := string(stdout)
	if err != nil {
		return false
	}
	checkAuthSuccess := regexp.MustCompile("success.")
	ok := checkAuthSuccess.MatchString(adbResultOrigin)
	return ok
}

// PushScripts 向设备中推测试脚本
func PushScripts(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, `-s`, sn, `push`, `scripts/.`, `/userdisk/dictpenUiAutomaticTest/scripts`)
	home, _ := os.UserHomeDir()
	cmd.Dir = home + "/dictpenUiAutomaticTest/"
	msg, err := cmd.CombinedOutput()

	if err != nil {
		return string(msg), err
	}

	msg1, err := CopyInitialData(sn)
	if err != nil {
		return msg1, err
	}
	return AddExecutableForSlipExecutable(sn)
}

// CopyInitialData 针对测试用数据拷到词典笔中对应数据库的位置
func CopyInitialData(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `sh`, `/userdisk/dictpenUiAutomaticTest/scripts/copyDbs.sh`, `&&`, `sh`, `/userdisk/dictpenUiAutomaticTest/scripts/copyMusic.sh`)
	msg, err := cmd.CombinedOutput()
	if err != nil {
		return string(msg), err
	}
	return string(msg), err
}

// AddExecutableForSlipExecutable 给滑动程序加
func AddExecutableForSlipExecutable(sn string) (string, error) {
	//AddExecutableCmd := "\"chmod +x /userdisk/dictpenUiAutomaticTest/scripts/slipExecutable  \""
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `chmod`, `+x`, `/userdisk/dictpenUiAutomaticTest/scripts/slipExecutable`, ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/weston-screenshooter", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/slipExecutable", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/S99adb-start-cherry", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/clickPhysicsButtonExecutableArm64", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/copyDbs.sh", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/copyMusic.sh", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/enableWestonDebug.sh", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/screenshot.sh", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/slipExecutable", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/touch.sh", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/32bit/ffmpeg", ";",
		"chmod", "+x", "/userdisk/dictpenUiAutomaticTest/scripts/32bit/slipExecutable_32", ";",
	)
	msg, err := cmd.Output()
	if strings.Contains(string(msg), "error") {
		return string(msg), errors.New("cannot add executable permission")
	}
	return string(msg), err
}

// DeleteScripts 删除测试脚本
func DeleteScripts(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `rm`, `-rf`, `/userdisk/dictpenUiAutomaticTest`)
	msg, err := cmd.Output()
	return string(msg), err
}

// GetPenSKU 获取SKU
// 不支持coco
func GetPenSKU(sn string) (string, error) {
	//skuCmd := "\"vendor_storage -r VENDOR_CUSTOM_ID_0E -t string | tr -s ' ' | cut -d ' ' -f 2 | tr -d '\\r\\n'  \""
	var tmpSn globalVariable.SN
	tmpSn.Data = sn
	product, _ := tmpSn.GetProductSerial()
	if product == "coco" {
		return GetCocoSKU(sn)
	}
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `vendor_storage`, `-r`, `VENDOR_CUSTOM_ID_0E`, `-t`, `string`, `|`, `tr`, `-s`, `' '`, `|`, `cut`, `-d`, `' '`, `-f`, `2`, `|`, `tr`, `-d`, `'\r\n'`)
	msg, err := cmd.Output()
	return string(msg), err
}

// GetPenPCBA 获取pcba
func GetPenPCBA(sn string) (string, error) {
	//pcbaCmd := "\"get_pcba_version | tr -d '\\r\\n' \""
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `get_pcba_version`, `|`, `tr`, `-d`, `'\r\n'`)
	msg, err := cmd.Output()
	return string(msg), err
}

// GetPenFirmware 获取笔的固件型号
func GetPenFirmware(sn string) (string, error) {
	//firmwareCmd := "\"cat /Version | tail -n 1  |tr -s ' ' |cut -d ' ' -f 2 | tr -d '\\r\\n' \""
	var tmpSn globalVariable.SN
	tmpSn.Data = sn
	prod, _ := tmpSn.GetProductSerial()
	if prod == "coco" {
		return GetCocoFirmware(sn)
	}
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `cat`, `/Version`, `|`, `tail`, `-n`, `1`, `|tr`, `-s`, `' '`, `|cut`, `-d`, `' '`, `-f`, `2`, `|`, `tr`, `-d`, `'\r\n'`)
	msg, err := cmd.Output()
	return string(msg), err
}
func GetCocoFirmware(sn string) (string, error) {
	//head -n 1 Version |tr -d '\r\n'
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `head`, `-n`, `1`, `Version`, `|tr`, `-d`, `'\r\n'`)
	msg, err := cmd.Output()
	return string(msg)[9:], err
}

// WakeScreen 唤醒屏幕
func WakeScreen(sn string) (string, error) {
	//wakeScreenCmd := "\"sh /userdisk/dictpenUiAutomaticTest/scripts/touch.sh wake \""
	var tmpSn globalVariable.SN
	tmpSn.Data = sn
	arch := "arm64"
	if prod, err := tmpSn.GetProductSerial(); err == nil && prod == "coco" {
		arch = "arm32"
	}
	var msg []byte
	var err error
	if arch == "arm64" {
		cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `sh`, `/userdisk/dictpenUiAutomaticTest/scripts/touch.sh`, arch, `wake`)
		msg, err = cmd.Output()
	} else {
		cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `hal-screen`, `on`)
		msg, err = cmd.Output()
	}
	return string(msg), err
}

// Click 点击原始坐标
// coco可用
func Click(sn string, x int, y int) (string, error) {
	//clickCmd := "\"sh /userdisk/dictpenUiAutomaticTest/scripts/touch.sh click " + strconv.Itoa(x) + " " + strconv.Itoa(y) + " \""
	var tmpSn globalVariable.SN
	tmpSn.Data = sn
	arch := "arm64"
	if prod, err := tmpSn.GetProductSerial(); err == nil && prod == "coco" {
		arch = "arm32"
	}
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `sh`, `/userdisk/dictpenUiAutomaticTest/scripts/touch.sh`, arch, `click`, strconv.Itoa(x), strconv.Itoa(y))
	msg, err := cmd.Output()
	time.Sleep(time.Second)
	return string(msg), err
}

// Slip 原始坐标滑动
func Slip(sn string, x1 int, y1 int, x2 int, y2 int, interval int) (string, error) {
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/slipExecutableArm64`, `-arch`, `arm64`, `-x1`, strconv.Itoa(x1), "-y1", strconv.Itoa(y1), "-x2", strconv.Itoa(x2), "-y2", strconv.Itoa(y2), "-interval", strconv.Itoa(interval))
	msg, err := cmd.Output()
	return string(msg), err
}

// SlipCoco Coco原始坐标滑动
func SlipCoco(sn string, x1 int, y1 int, x2 int, y2 int, interval int) (string, error) {
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/slipExecutableArm32`, `-arch`, `arm32`, `-x1`, strconv.Itoa(x1), "-y1", strconv.Itoa(y1), "-x2", strconv.Itoa(x2), "-y2", strconv.Itoa(y2), "-interval", strconv.Itoa(interval))
	msg, err := cmd.Output()
	return string(msg), err
}

// ClickPhysicsButtonExec 点击物理按钮
func ClickPhysicsButtonExec(sn, command string, elapse int) (string, error) {
	args := []string{`-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/clickPhysicsButtonExecutableArm64`, `-cmd`, command, `-elapse`, strconv.Itoa(elapse)}
	cmd := exec.Command(adbExecutable, args...)
	msg, err := cmd.Output()
	return string(msg), err
}

// ClickPhysicsButtonExec 点击物理按钮
func ClickPhysicsButtonExec32(sn, command string, elapse int) (string, error) {
	args := []string{`-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/clickPhysicsButtonExecutableArm32`, `-cmd`, command, `-elapse`, strconv.Itoa(elapse)}
	cmd := exec.Command(adbExecutable, args...)
	msg, err := cmd.Output()
	return string(msg), err
}

func SendEvent32(sn string, command []string) (string, error) {
	command = append([]string{`-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32`}, command...)
	cmd := exec.Command(adbExecutable, command...)
	msg, err := cmd.Output()
	return string(msg), err
}
func SendEvent64(sn string, command []string) (string, error) {
	command = append([]string{`-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64`}, command...)
	cmd := exec.Command(adbExecutable, command...)
	msg, err := cmd.Output()
	return string(msg), err
}

// ClickPhysicsButtonCocoExec coco 点击物理按钮
// coco中的send_event 目前不支持物理按钮
func ClickPhysicsButtonCocoExec(sn, command string, elapse int) (string, error) {
	args := []string{`-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/clickPhysicsButtonExecutableArm32`, `-cmd`, command, `-elapse`, strconv.Itoa(elapse)}
	cmd := exec.Command(adbExecutable, args...)
	msg, err := cmd.Output()
	return string(msg), err
}

// ClickPower 点击电源按键
func ClickPower(sn string, t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec(sn, "power", int(t*1000))
	return ret, err
}

// ClickSoundHelper 点击语音助手按键
func ClickSoundHelper(sn string, t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec(sn, "menu", int(t*1000))
	return ret, err
}

// ClickLed 闪一下扫描灯
func ClickLed(sn string, t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec(sn, "led", int(t*1000))
	return ret, err
}

// ClickLedCOCO 闪一下扫描灯
func ClickLedCOCO(sn string, t float64) (string, error) {
	ret, err := ClickPhysicsButtonExec32(sn, "led", int(t*1000))
	return ret, err
}

// ScreenShot 截图
func ScreenShot(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "sh", "/userdisk/dictpenUiAutomaticTest/scripts/screenshot.sh")
	msg, err := cmd.CombinedOutput()
	if strings.Contains(string(msg), "error") {
		return string(msg), errors.New("cannot get screenshot")
	}
	time.Sleep(time.Millisecond * 500)
	return string(msg), err
}

// ScreenShotFfmpeg 词典笔3566、3326、apollo截图 64bit ffmpeg kmsgrab
func ScreenShotFfmpeg(sn string) (base64 string, err error) {
	_, err = WakeScreen(sn)
	if err != nil {
		return "", err
	}
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "ffmpeg", "-loglevel", "quiet", "-f", "kmsgrab", "-i", "-", "-vf", "'hwdownload,format=bgr0'", "-framerate", "60", "-frames:v", "1", "-c:v", "png", "-f", "image2pipe", "-", "|base64")
	msg, err := cmd.CombinedOutput()
	base64 = string(msg)
	if base64 == "" {
		return "", errors.New("screenshot failed")
	}
	return
}

// ScreenShotFfmpegFbdev coco截图 32位ffmpeg fbdev
func ScreenShotFfmpegFbdev(sn string) (base64 string, err error) {
	_, err = WakeScreen(sn)
	if err != nil {
		return "", err
	}
	// adb shell "ffmpeg -loglevel quiet  -f kmsgrab -i - -vf 'hwdownload,format=bgr0' -framerate  60 -frames:v 1 -c:v png -f image2pipe - |base64"|base64 -d  >abc.png
	// ./ffmpeg  -f fbdev -framerate 60 -i /dev/fb0  -frames:v 1 screenshot7.png
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "/userdisk/dictpenUiAutomaticTest/scripts/32bit/ffmpeg", "-loglevel", "quiet", "-f", "fbdev", "-framerate", "60", "-i", "/dev/fb0", "-frames:v", "1", "-c:v", "png", "-f", "image2pipe", "-", "|base64")
	msg, err := cmd.CombinedOutput()
	base64 = string(msg)
	if base64 == "" {
		return "", errors.New("screenshot failed")
	}
	return
}

//// DeleteScreenShot 删除笔上的截图
//func DeleteScreenShot(sn string, imgName string) (string, error) {
//	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `rm`, `-f`, `/tmp/`+imgName)
//	msg, err := cmd.Output()
//	defer func() { cmd.Process.Kill() }()
//	return string(msg), err
//}

// EnableWestonDebug 开启weston的debug模式
// 1、推入重启后自动开adb的脚本
// 2、改weston为debug模式（用ffmpeg截图不需要开这个）
//
func EnableWestonDebug(sn string) (string, error) {
	//enableWestonDebugCmd := "\"sh /userdisk/dictpenUiAutomaticTest/scripts/enableWestonDebug.sh  \""
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `sh`, `/userdisk/dictpenUiAutomaticTest/scripts/enableWestonDebug.sh`)
	msg, err := cmd.Output()
	return string(msg), err
}

// PullScreenshot 接截图
func PullScreenshot(sn string, fileName string) (string, error) {
	tempDir, err := ioutil.TempDir("", "dictpenScreenshot")
	if err != nil {
		log.Println(err)
		panic(err)
	}
	//pullScreenshotCmd := "/tmp/" + fileName + " " + tempDir
	cmd := exec.Command(adbExecutable, `-s`, sn, `pull`, "/tmp/"+fileName, tempDir)
	_, err = cmd.CombinedOutput()
	return tempDir + "/" + fileName, err
}

// CheckScriptsVersion 检查笔中脚本的版本
func CheckScriptsVersion(sn string, version string) (string, error) {
	//getVersionCmd := "\" if [ -f /userdisk/dictpenUiAutomaticTest/scripts/version.yml ]; then grep version /userdisk/dictpenUiAutomaticTest/scripts/version.yml; else echo error; fi  \""
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `if`, `[`, `-f`, `/userdisk/dictpenUiAutomaticTest/scripts/version.yml`, `];`, `then`, `grep`, `version`, `/userdisk/dictpenUiAutomaticTest/scripts/version.yml;`, `else`, `echo`, `error;`, `fi`)
	msg, err := cmd.Output()
	res := strings.Replace(string(msg), "\n", "", -1)
	res = strings.Replace(res, "\r", "", -1)

	if res == `version: "`+version+`"` {
		return res, err
	}
	return res, errors.New("scripts version not match")
}

// AttachAndConnect root授权，并对首次使用的笔开启截图
func AttachAndConnect(sn string) (string, error) {
	res, err := CheckScriptsVersion(sn, scriptsVersion)
	if err != nil {
		res, err = PushScripts(sn)
		if err != nil {
			return res, err
		}
		res, err = EnableWestonDebug(sn)
		if err != nil {
			return res, err
		}
	}
	return res, err
}

// FixClickFailedBugForCardMode 修复在一些页面上因研发确保笔不熄屏死循环发送事件导致笔无法控制的问题
func FixClickFailedBugForCardMode(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "ps|grep", "input-event", "|grep", "-v", "grep", "|head", "-n", "1", "|awk", "'{printf $1}'", "|xargs", "-t", "kill", "-USR2")
	msg, err := cmd.CombinedOutput()
	return string(msg), err
}

// KillDictPenUi 词典笔回到首页
func KillDictPenUi(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "ps|grep", "'YoudaoDictPen -platform wayland'", "|grep", "-v", "grep", "|head", "-n", "1", "|awk", "'{printf $1}'", "|xargs", "-t", "kill", "-9")
	msg, err := cmd.CombinedOutput()
	time.Sleep(time.Second * 15)
	return string(msg), err
}

// KillApolloUi 听力宝回到首页，还有一些问题
func KillApolloUi(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "ps|grep", "'YoudaoApollo -platform wayland'", "|grep", "-v", "grep", "|head", "-n", "1", "|awk", "'{printf $1}'", "|xargs", "-t", "kill", "-9")
	msg, err := cmd.CombinedOutput()
	time.Sleep(time.Second * 15)
	return string(msg), err
}

//// KillCocoUi Coco回到首页
//func KillCocoUi(sn string) (string, error) {
//	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "ps|grep", "'miniapp'", "|grep", "-v", "grep", "|head", "-n", "1", "|awk", "'{printf $1}'", "|xargs", "-t", "kill", "-9")
//	msg, err := cmd.CombinedOutput()
//	defer func() { cmd.Process.Kill() }()
//	time.Sleep(time.Second * 5)
//	return string(msg), err
//}

func Reboot(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "reboot")
	msg, err := cmd.CombinedOutput()
	time.Sleep(time.Second * 30)
	for i := 0; i < 10 && !Auth(sn); i++ {
		time.Sleep(time.Second * 3)
	}
	time.Sleep(time.Second * 3)
	return string(msg), err
}

func GetCocoSKU(sn string) (string, error) {
	//yd_misc_info_tool -r YD_LINUX_SKU_ID -t string
	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`, `yd_misc_info_tool`, `-r`, `YD_LINUX_SKU_ID`, `-t`, `string`, `|`, `tr`, `-d`, `'\r\n'`)
	msg, err := cmd.Output()
	//fmt.Println(string(msg), err)
	return string(msg)[17:], err
}
func UpdateInDeviceTools(sn string) (string, error) {
	if globalVariable.IsInDevice {
		return "", errors.New("not support in device update")
	}

	updateSendEventArm32 := func() (string, error) {
		sendEventArm32, _ := globalVariable.EmFS.ReadFile("dictpenUiAutomaticTest/sendEventArm32")
		var fileName string
		if globalVariable.CurrentOS == "windows" {
			fileName = os.TempDir() + string(os.PathSeparator) + "sendEventArm32"
		} else {
			fileName = os.TempDir() + "sendEventArm32"
		}
		err := os.WriteFile(fileName, sendEventArm32, 0777)
		if err != nil {
			return "", err
		}
		defer os.RemoveAll(fileName)
		cmd := exec.Command(adbExecutable, `-s`, sn, `push`, fileName, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/`)
		msg, err := cmd.Output()
		fmt.Println(string(msg))
		if globalVariable.CurrentOS == "windows" {
			cmd1 := exec.Command(adbExecutable, `-s`, sn, `shell`, `chmod`, `+x`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32`)
			_ = cmd1.Run()
		}
		return string(msg), err
	}
	updateClickPhysicsButtonExecutableArm32 := func() (string, error) {
		clickPhysicsButtonExecutableArm32, _ := globalVariable.EmFS.ReadFile("dictpenUiAutomaticTest/clickPhysicsButtonExecutableArm32")
		var fileName string
		if globalVariable.CurrentOS == "windows" {
			fileName = os.TempDir() + string(os.PathSeparator) + "clickPhysicsButtonExecutableArm32"
		} else {
			fileName = os.TempDir() + "clickPhysicsButtonExecutableArm32"
		}

		err := os.WriteFile(fileName, clickPhysicsButtonExecutableArm32, 0777)
		if err != nil {
			return "", err
		}
		defer os.RemoveAll(fileName)
		cmd := exec.Command(adbExecutable, `-s`, sn, `push`, fileName, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/`)
		msg, err := cmd.Output()
		fmt.Println(string(msg))
		if globalVariable.CurrentOS == "windows" {
			cmd1 := exec.Command(adbExecutable, `-s`, sn, `shell`, `chmod`, `+x`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/clickPhysicsButtonExecutableArm32`)
			_ = cmd1.Run()
		}
		return string(msg), err
	}
	updateSlipExecutableArm32 := func() (string, error) {
		slipExecutableArm32, _ := globalVariable.EmFS.ReadFile("dictpenUiAutomaticTest/slipExecutableArm32")
		var fileName string
		if globalVariable.CurrentOS == "windows" {
			fileName = os.TempDir() + string(os.PathSeparator) + "slipExecutableArm32"
		} else {
			fileName = os.TempDir() + "slipExecutableArm32"
		}

		err := os.WriteFile(fileName, slipExecutableArm32, 0777)
		if err != nil {
			return "", err
		}
		defer os.RemoveAll(fileName)
		cmd := exec.Command(adbExecutable, `-s`, sn, `push`, fileName, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/`)
		msg, err := cmd.Output()
		fmt.Println(string(msg))
		if globalVariable.CurrentOS == "windows" {
			cmd1 := exec.Command(adbExecutable, `-s`, sn, `shell`, `chmod`, `+x`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/slipExecutableArm32`)
			_ = cmd1.Run()
		}
		return string(msg), err
	}
	checkVersion := func() (string, error) {
		tmpSn := globalVariable.SN{Data: globalVariable.Sn}
		prod, _ := tmpSn.GetProductSerial()
		if prod == "coco" {
			func() (string, error) {
				c1 := exec.Command(adbExecutable, `-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32`, `version`)
				msg, err := c1.Output()
				if err != nil || strings.Trim(string(msg), "\r\n") != "v1.0.0" {
					return updateSendEventArm32()
				}
				return "", nil
			}()
			func() (string, error) {
				c1 := exec.Command(adbExecutable, `-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/clickPhysicsButtonExecutableArm32`, `version`)
				msg, err := c1.Output()
				if err != nil || strings.Trim(string(msg), "\r\n") != "v1.0.0" {
					return updateClickPhysicsButtonExecutableArm32()
				}
				return "", nil
			}()
			func() (string, error) {
				c1 := exec.Command(adbExecutable, `-s`, sn, `shell`, `/userdisk/dictpenUiAutomaticTest/scripts/32bit/slipExecutableArm32`, `version`)
				msg, err := c1.Output()
				if err != nil || strings.Trim(string(msg), "\r\n") != "v1.0.0" {
					return updateSlipExecutableArm32()
				}
				return "", nil
			}()
		}
		return "", nil
	}
	return checkVersion()
}
