package adbUtil

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"
)

func GetAPKVersion(sn string) (string, error) {
	//apkVersionCmd := "\" dumpsys package com.youdao.hardware.aladdin | grep versionName \""
	apkVersionCmd := "\" getprop ro.build.display.id \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+apkVersionCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+apkVersionCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func GetMCUVersion(sn string) (string, error) {
	apkVersionCmd := "\" settings get global firmware_version \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+apkVersionCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+apkVersionCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func GetWifiStatus(sn string) (string, error) {
	//wifiStatusCmd := "\" dumpsys connectivity |grep -Eo 'nc{[^}]+}' \""
	//cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+wifiStatusCmd)
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "dumpsys", "connectivity", "|grep", "-Eo", "'nc{[^}]+}'")
	if sysType == "windows" {
		//cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+wifiStatusCmd+" }")
		cmd = exec.Command(adbExecutable, "-s", sn, "shell", "dumpsys", "connectivity", "|grep", "-Eo", "'nc{[^}]+}'")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func GetWifiInfo(sn string) (connected bool, ssid string, signalStrength float64) {
	msg, err := GetWifiStatus(sn)
	if err != nil {
		return false, "", 0
	}
	wantSSID := regexp.MustCompile("SSID: \"[^\"]+\"")

	fmt.Sscanf(wantSSID.FindString(msg), "SSID: %s", &ssid)
	wantSignalStrength := regexp.MustCompile("SignalStrength: -[0-9]*")
	fmt.Sscanf(wantSignalStrength.FindString(msg), "SignalStrength: %v", &signalStrength)
	connected = true
	return
}

func InstallSoloPi(sn, dir string) (string, error) {
	soloPiPath := "\"SoloPi_0.11.2.apk\""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` install `+soloPiPath)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` install `+soloPiPath+" }")
	}
	//var stderr bytes.Buffer
	cmd.Dir = dir
	//cmd.Stderr = &stderr
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	//log.Println("stderr:", stderr.String())
	return string(msg), err
}

func UninstallSoloPi(sn string) (string, error) {
	uninstallCmd := "\"com.alipay.hulu\""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` uninstall `+uninstallCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` uninstall `+uninstallCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

func StartSoloPi(sn string) (string, error) {
	startSoloPiCmd := "\" am start com.alipay.hulu/com.alipay.hulu.activity.SplashActivity \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+startSoloPiCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+startSoloPiCmd+" }")
	}
	msg, err := cmd.Output()

	startTcpip := " tcpip 5555"
	cmd1 := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+startTcpip)
	if sysType == "windows" {
		cmd1 = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+startTcpip+" }")
	}
	defer func() { cmd.Process.Kill(); cmd1.Process.Kill() }()
	var msg1 []byte
	if err == nil {
		//log.Println(string(msg), "stage1 ok")
		msg1, err = cmd1.Output()
		//var stderr bytes.Buffer
		//cmd1.Stderr = &stderr
		//log.Println(stderr.String())
		return string(msg1), err
	}
	return string(msg), err
}
func CloseVoiceAssistant(sn string) (string, error) {
	closeVoiceAssistantCmd := "\" setprop persist.maidu.voice.language.wakeup 0 \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+closeVoiceAssistantCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+closeVoiceAssistantCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func OpenVoiceAssistant(sn string) (string, error) {
	closeVoiceAssistantCmd := "\" setprop persist.maidu.voice.language.wakeup 1 \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+closeVoiceAssistantCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+closeVoiceAssistantCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func GetVoiceAssistantStatus(sn string) (string, error) {
	GetVoiceAssistantStatusCmd := "\" getprop persist.maidu.voice.language.wakeup  \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+GetVoiceAssistantStatusCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+GetVoiceAssistantStatusCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func ExportLogCat5Min(sn string) (string, error) {
	currentTime := time.Now().Add(-time.Minute * 5)
	MM := currentTime.Month()
	DD := currentTime.Day()
	hh := currentTime.Hour()
	mm := currentTime.Minute()
	ss := currentTime.Second()
	exportLogCat5MinCmd := "\" logcat -t '" + fmt.Sprint(int(MM)) + "-" + fmt.Sprint(DD) + " " + fmt.Sprint(hh) + ":" + fmt.Sprint(mm) + ":" + fmt.Sprint(ss) + ".000' \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+exportLogCat5MinCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+exportLogCat5MinCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

type VoiceAssistant struct {
	WakeUpTime int
	Status     bool
	StartFlag  bool
	Sn         string
}

func (va *VoiceAssistant) FilterVoiceAssistantWakeUpTime(sn string) (string, error) {
	if va.Sn != sn {
		va.StartFlag = false
		va.Sn = sn
		va.WakeUpTime = 0
	}
	if va.StartFlag {
		return "", errors.New("already start")
	}
	va.StartFlag = true
	defer func() { va.StartFlag = false }()

	filterVocieAssistantWakeUpTimeCmd := "logcat |grep 'Sending non-protected broadcast com.maidu.language.wakeup.action' \n"

	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell }`)
	}
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return "", err
	}
	_, err = io.WriteString(stdin, filterVocieAssistantWakeUpTimeCmd)

	stdout, _ := cmd.StdoutPipe()
	err = cmd.Start()
	if err != nil {
		return "", err
	}
	scanner := bufio.NewScanner(stdout)
	scanner.Split(bufio.ScanLines)
	for scanner.Scan() {
		va.WakeUpTime++
		//m := scanner.Text()
		//fmt.Println(m)
	}
	err = cmd.Wait()
	if err != nil {
		return "", err
	}

	defer func() { cmd.Process.Kill(); stdin.Close(); stdout.Close() }()
	return string("voice assistant count finished"), err
}
func (va *VoiceAssistant) Reset() {
	va.WakeUpTime = 0

}
func (va *VoiceAssistant) GetWakeUpTime() int {
	return va.WakeUpTime / 2
}

type OTAStatus struct {
	OtaStatus int
	Progress  float64
	Success   bool
	StartFlag bool
}

func (ota *OTAStatus) FilterOTAStatus(sn string) (string, error) {
	if ota.StartFlag {
		return "", errors.New("already start")
	}
	ota.StartFlag = true
	defer func() { ota.StartFlag = false }()

	FilterOTAStatusCmd := "\"  logcat | grep -iE \"rsotaua|AOTA\" \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+FilterOTAStatusCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+FilterOTAStatusCmd+" }")
	}
	stdout, _ := cmd.StdoutPipe()
	err := cmd.Start()
	if err != nil {
		return "", err
	}
	scanner := bufio.NewScanner(stdout)
	scanner.Split(bufio.ScanLines)
	wantProgressString := regexp.MustCompile("update progress: \\d+(\\.\\d+)?")
	wantProgressVal := regexp.MustCompile("\\d+(\\.\\d+)?")
	wantStatusString := regexp.MustCompile("RsInstallManger: status \\d+")
	wantStatusVal := regexp.MustCompile("\\d+")
	wantSuccess := regexp.MustCompile("RsInstallManger: UPDATE SUCCESS!")
	for scanner.Scan() {
		m := scanner.Text()
		s := wantProgressString.FindString(m)
		progressValStr := wantProgressVal.FindString(s)
		if progressValStr != "" {
			val, err := strconv.ParseFloat(progressValStr, 64)
			if err != nil {
				return "", err
			}
			ota.Progress = val
		}
		s1 := wantStatusString.FindString(m)
		statusValStr := wantStatusVal.FindString(s1)
		if statusValStr != "" {
			statusVal, err := strconv.ParseInt(statusValStr, 10, 32)
			if err != nil {
				return "", err
			}
			ota.OtaStatus = int(statusVal)
		}
		ota.Success = wantSuccess.MatchString(m)
	}
	err = cmd.Wait()
	if err != nil {
		return "", err
	}

	msg, err := cmd.CombinedOutput()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

//点按操作反馈
func OpenClickFeedback(sn string) (string, error) {
	ClickFeedbackCmd := "\" settings put system show_touches 1 \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+ClickFeedbackCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+ClickFeedbackCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}
func CloseClickFeedback(sn string) (string, error) {
	ClickFeedbackCmd := "\" settings put system show_touches 0 \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+ClickFeedbackCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+ClickFeedbackCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// 清理缓存
//adb shell pm clear com.youdao.hardware.aladdin
func ClearCache(sn string) (string, error) {
	ClearCacheCmd := "\" pm clear com.youdao.hardware.aladdin \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+ClearCacheCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+ClearCacheCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

// bug report 导出
//adb bugreport
func ExportBugReport(sn, path string) (string, error) {
	//BugReportCmd := " bugreport " + path
	cmd := exec.Command(adbExecutable, `-s`, sn, "bugreport", path)
	//if sysType == "windows" {
	//	cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+BugReportCmd+" }")
	//}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return string(msg), err
}

//重新进入激活登录流程
//adb root
//adb shell
//cd da
//cd data/da
//cd data/data/co
//cd data/data/com.youdao.hardware.aladdin/shared_prefs/
//rm -rf *
//ls
//
//func ReActivate(sn string) (string, error) {
//	ReActivateCmd1 := " root"
//	ReActivateCmd2 := "\" rm -rf /data/data/com.youdao.hardware.aladdin/shared_prefs/* \""
//	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+ReActivateCmd1)
//	if sysType == "windows" {
//		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+ReActivateCmd1+" }")
//	}
//
//	msg, err := cmd.Output()
//
//	cmd1 := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+ReActivateCmd2)
//	if sysType == "windows" {
//		cmd1 = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+ReActivateCmd2+" }")
//	}
//	if err != nil {
//		return string(msg), err
//	}
//	msg1, err := cmd1.Output()
//
//	defer func() { cmd.Process.Kill() }()
//	return string(msg1), err
//}

// camera绿屏抓取log
//adb root
//adb remount
//adb shell setprop persist.vendor.camera.dump 11
//adb shell setenforce 0
//adb shell mkidr /data/dump/
//adb shell mkdir /data/dump/
//adb shell setprop persist.vender.camera.dumo.path /data/dump/

//func CameraBlueScreenLog(sn string) (string, error) {
//	loginAsRootCmd := "adb root"
//	remountCmd := "adb remount"
//	cmd1 := "adb shell setprop persist.vendor.camera.dump 11"
//	cmd2 := "adb shell setenforce 0"
//	cmd3 := "adb shell mkidr /data/dump/"
//	cmd4 := "adb shell setprop persist.vender.camera.dumo.path /data/dump/"
//
//	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+BugReportCmd)
//	if sysType == "windows" {
//		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+BugReportCmd+" }")
//	}
//	msg, err := cmd.Output()
//	defer func() { cmd.Process.Kill() }()
//	return string(msg), err
//}

// 重新推送资源
//adb root
//adb remount
//adb shell
//cd system/etc
//rm -r youdao_resource
//exit
//adb push 要push的文件地址\ /system/etc/

//启动时长：
//adb shell am start -W [PackageName]/[PackageName.MainActivity]

func GetLightSwitchStatus(sn string) (string, error) {
	GetLightSwitchStatusCmd := "\" settings get global light_switch_status \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+GetLightSwitchStatusCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+GetLightSwitchStatusCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()

	return strings.TrimRight(string(msg), "\r\n"), err
}

// adb shell settings get global light_mode
func GetLightMode(sn string) (string, error) {
	GetLightModeCmd := "\" settings get global light_mode \""
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+GetLightModeCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+GetLightModeCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()

	return strings.TrimRight(string(msg), "\r\n"), err
}

// adb shell settings put global open_close_light 1
func OpenCloseLight(sn string, status int) (string, error) {
	GetLightModeCmd := "settings put global open_close_light " + strconv.Itoa(status)
	cmd := exec.Command(shellName, shellArgForStringInput, adbExecutable+` -s`+sn+` shell `+GetLightModeCmd)
	if sysType == "windows" {
		cmd = exec.Command(shellName, shellArgForStringInput, "&{ "+adbExecutable+` -s`+sn+` shell `+GetLightModeCmd+" }")
	}
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()

	return strings.TrimRight(string(msg), "\r\n"), err
}

// adb shell logcat -G 200M
func SetLogcatCacheSize(sn string) (string, error) {
	cmd := exec.Command(adbExecutable, "-s", sn, "shell", "logcat", "-G", "200M")
	msg, err := cmd.Output()
	defer func() { cmd.Process.Kill() }()
	return strings.TrimRight(string(msg), "\r\n"), err
}
