package adbUtil

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"os/exec"
	"regexp"
	"testing"
)

var teststdin io.WriteCloser
var test001 int

func monitor() {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		return
	}
	sn := devices[0][0]

	cmd := exec.Command(adbExecutable, `-s`, sn, `shell`)
	teststdin, err = cmd.StdinPipe()
	if err != nil {
		return
	}
	//_, err = io.WriteString(teststdin, "ping baidu.com\n")
	if err != nil {
		fmt.Println(err)
	}
	stdout, _ := cmd.StdoutPipe()
	err = cmd.Start()
	if err != nil {
		log.Println(err)
		return
	}
	scanner := bufio.NewScanner(stdout)
	scanner.Split(bufio.ScanLines)
	for scanner.Scan() {

		m := scanner.Text()
		if m == "hjdtest" {
			test001++
			log.Println(test001)
		}
		fmt.Println(m)
	}
	err = cmd.Wait()
}
func TestCmdParse1(t *testing.T) {
	for teststdin == nil {

	}
	io.WriteString(teststdin, "ls && echo hjdtest\n")
	for test001 < 1 {

	}
	io.WriteString(teststdin, "pwd && echo hjdtest\n")
	for test001 < 2 {

	}
	io.WriteString(teststdin, "cd /bin && echo hjdtest\n")
	for test001 < 3 {

	}
	io.WriteString(teststdin, "ls && echo hjdtest\n")
	for test001 < 4 {

	}
	io.WriteString(teststdin, "cd .. && echo hjdtest\n")
	for test001 < 5 {

	}
	io.WriteString(teststdin, "cat Version && echo hjdtest\n")
	//io.WriteString(teststdin, "ls\n")
	//io.WriteString(teststdin, "ls\n")
	for test001 < 5 {

	}
}
func init() {
	SetAdbExecutable()
	//go monitor()
}
func TestCheckGlobalAdb(t *testing.T) {
	ok := CheckGlobalAdb()
	log.Println(ok)
}
func TestExecuteAdb(t *testing.T) {
	want := regexp.MustCompile("Android Debug Bridge version")
	msg, err := ExecAdb("--version")
	log.Println(msg)
	if !want.MatchString(msg) || err != nil {
		t.Fatalf(`Can not execute adb!`)
	}
}
func TestAdbGetDevices(t *testing.T) {
	devices, err := GetDevices()
	fmt.Println(devices)
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
}

// coco不可用
func TestAdbAuth(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	authStatus := Auth(sn)
	if !authStatus {
		t.Fatalf(`Auth device failed! sn:%v`, sn)
	}
}

// coco 可用
func TestPushScripts(t *testing.T) {
	//want := regexp.MustCompile(`scripts`)
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	_, err = PushScripts(sn)
	if err != nil {
		t.Fatalf(`Transfer files failed!,err%v`, err)
	}
}

func TestDeleteScripts(t *testing.T) {
	want := regexp.MustCompile(`dictpenUiAutomaticTest`)
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := DeleteScripts(sn)
	if err != nil {
		t.Fatalf(`Delete test files failed! msg:%v`, msg)
	}
	checkFolderExistsCmd := exec.Command(shellName, shellArgForStringInput, `echo "cd /userdisk/;ls |grep dictpenUiAutomaticTest;exit"| `+adbExecutable+` -s`+sn+` shell`)
	if sysType == "windows" {
		checkFolderExistsCmd = exec.Command(shellName, shellArgForStringInput, `&{ echo "cd /userdisk/;ls |grep dictpenUiAutomaticTest;exit"| `+adbExecutable+` -s`+sn+` shell }`)
	}
	msg1, _ := checkFolderExistsCmd.Output()

	strCnt := len(want.FindAllString(string(msg1), -1))
	if strCnt != 2 {
		t.Fatalf(`Delete test files failed!`)
	}
}

// 不支持coco
func TestGetPenSKU(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	sku, err := GetPenSKU(sn)
	if err != nil {
		t.Fatalf(`获取SKU失败! sku:%v`, sku)
	}
	log.Println("sku:" + sku)
}

// coco 可用
func TestGetPenPCBA(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]

	pcba, err := GetPenPCBA(sn)
	if err != nil {
		t.Fatalf(`获取PCBA失败! PCBA:%v`, pcba)
	}
	log.Println("pcba:" + pcba)
}

// 不支持coco 要改下
func TestGetPenFirmware(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	firmware, err := GetPenFirmware(sn)
	if err != nil {
		t.Fatalf(`获取 Firmware 失败! Firmware:%v`, firmware)
	}
	log.Println("firmware:" + firmware)
}

// coco目前不会熄屏，不知好不好用
func TestWakeScreen(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := WakeScreen(sn)
	log.Println(msg)
	if err != nil {
		t.Fatalf(`Can not wake screen!`)
	}
}

// coco可用
func TestClick(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	_, err = Click(sn, 300, 80)
	if err != nil {
		t.Fatalf(`Click screen (300,80) failed!`)
	}
}

// coco不可用
func TestScreenShot(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	str, err := ScreenShot(sn)
	fmt.Println(str)
	if err != nil {
		t.Fatalf(`Can not get screenshot!`)
	}

	if str == "error cannot get screenshot!\r\n" {
		t.Fatalf(`Can not get screenshot!`)
	}
}

// ScreenShotFfmpeg
// coco不可用
func TestScreenShotFfmpeg(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	str, err := ScreenShotFfmpeg(sn)
	fmt.Println(str)
	if err != nil {
		t.Fatal(`Can not get screenshot!`, err)
	}
}

// coco 不需要开启weston debug模式，但重启自动开adb的功能可用
func TestEnableWestonDebug(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	_, err = EnableWestonDebug(sn)
	if err != nil {
		t.Fatalf(`Can not enable weston debug!`)
	}
}

// cooc 不需要
func TestPullScreenshot(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	fileName, err := ScreenShot(sn)
	if err != nil {
		t.Fatalf(`Can not get screenshot!`)
	}
	if fileName == "error cannot get screenshot!\r\n" {
		t.Fatalf(`Can not get screenshot!`)
	}
	str, err := PullScreenshot(sn, fileName)
	if err != nil {
		t.Fatalf("Can not pull screenshot! err:%v", err)
	}
	fmt.Println(str)
}

// 不支持coco
func TestSlip(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	//_, err = Slip(sn, 300, 700, 300, 100)
	_, err = Slip(sn, 300, 100, 300, 700)
	if err != nil {
		t.Fatalf(`Slip screen (300,80) to (200,80) failed!`)
	}
}

// coco 可用
func TestSlipCoco(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	_, err = SlipCoco(sn, 300, 100, 300, 700)
	if err != nil {
		t.Fatalf(`Slip screen (300,80) to (200,80) failed!`)
	}
}

// coco 可用
func TestCheckScriptsVersion(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	result, err := CheckScriptsVersion(sn, "1.1.7")
	if err != nil {
		t.Fatal(err)
	}
	log.Println(result)
}

func TestAddExecutableForSlipExecutable(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	result, err := AddExecutableForSlipExecutable(sn)
	if err != nil {
		t.Fatal(err)
	}
	log.Println(result)
}
func TestAttachAndConnect(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	result, err := AttachAndConnect(sn)
	if err != nil {
		t.Fatal(err)
	}
	log.Println(result)
}

// coco的物理按钮不好使。。。
func TestClickPower(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	res, err := ClickPower(sn, 0)
	if err != nil {
		t.Fatal(err)
	}
	log.Println(res)
}

// coco 不可用
func TestClickSoundHelper(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	res, err := ClickSoundHelper(sn, 0)
	if err != nil {
		t.Fatal(err)
	}
	log.Println(res)
}

func TestFixClickFailedBugForCardMode(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	res, err := FixClickFailedBugForCardMode(sn)
	log.Println(res)
	if err != nil {
		t.Fatal(err)
	}
}
func TestKillDictPenUi(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	res, err := KillDictPenUi(sn)
	log.Println(res)
	if err != nil {
		t.Fatal(err)
	}
}
func TestCopyInitialData(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := CopyInitialData(sn)
	fmt.Println(msg, err)
}
func TestKillApolloUi(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	ui, err := KillApolloUi(sn)
	fmt.Println(ui, err)
}

func TestClickPhysicsButtonExec(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]

	// apollo
	// 在亮屏情况下 按两下 menu 可以回到首页
	//ret, err := ClickPhysicsButtonExec(sn, "menu", 0)
	//ret, err = ClickPhysicsButtonExec(sn, "menu", 0)

	// 亮不亮屏都好使
	// volume_up 音量升高
	//ret, err := ClickPhysicsButtonExec(sn, "volume_up", 0)
	// volume_down 音量降低
	//ret, err := ClickPhysicsButtonExec(sn, "volume_down", 0)

	// pause 播放情况下 暂停
	//       暂停情况下 播放
	//ret, err := ClickPhysicsButtonExec(sn, "pause", 0)

	// back 返回上一句
	//ret, err := ClickPhysicsButtonExec(sn, "back", 0)
	// forward 前进到下一句
	ret, err := ClickPhysicsButtonExec(sn, "forward", 0)
	log.Println(ret, err)
}

func TestScreenShotFfmpegFbdev(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	str, err := ScreenShotFfmpegFbdev(sn)
	fmt.Println(str)
	if err != nil {
		t.Fatal(`Can not get screenshot!`, err)
	}
}

func TestAuthCoco(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	fmt.Println(sn)
	ok := AuthCoco(sn)

	fmt.Println(ok)
}

func TestClickPhysicsButtonCocoExec(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]

	ret, err := ClickPhysicsButtonCocoExec(sn, "menu", 0)
	fmt.Println(ret, err)
}
