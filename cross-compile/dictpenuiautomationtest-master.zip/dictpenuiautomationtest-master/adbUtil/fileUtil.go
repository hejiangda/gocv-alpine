package adbUtil

import (
	"archive/zip"
	yaml "gopkg.in/yaml.v2"
	"io"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

const scriptsVersion = "1.3.2"

func UnZip(dst, src string) (err error) {
	// 打开压缩文件，这个 zip 包有个方便的 ReadCloser 类型
	// 这个里面有个方便的 OpenReader 函数，可以比 tar 的时候省去一个打开文件的步骤
	zr, err := zip.OpenReader(src)
	if err != nil {
		return
	}
	defer zr.Close()
	// 如果解压后不是放在当前目录就按照保存目录去创建目录
	if dst != "" {
		if err := os.MkdirAll(dst, 0755); err != nil {
			return err
		}
	}

	// 遍历 zr ，将文件写入到磁盘
	for _, file := range zr.File {
		path := filepath.Join(dst, file.Name)

		// 如果是目录，就创建目录
		if file.FileInfo().IsDir() {
			if err := os.MkdirAll(path, file.Mode()); err != nil {
				return err
			}
			// 因为是目录，跳过当前循环，因为后面都是文件的处理
			continue
		}

		// 获取到 Reader
		fr, err := file.Open()
		if err != nil {
			return err
		}

		// 创建要写出的文件对应的 Write
		fw, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR|os.O_TRUNC, file.Mode())
		if err != nil {
			return err
		}

		_, err = io.Copy(fw, fr)
		if err != nil {
			return err
		}

		// 将解压的结果输出
		// fmt.Printf("成功解压 %s ，共写入了 %d 个字符的数据\n", path, n)

		// 因为是在循环中，无法使用 defer ，直接放在最后
		// 不过这样也有问题，当出现 err 的时候就不会执行这个了，
		// 可以把它单独放在一个函数中，这里是个实验，就这样了
		fw.Close()
		fr.Close()
	}
	return nil
}

func UnzipTestFile() error {
	home, _ := os.UserHomeDir()
	filePath := home + "/dictpenUiAutomaticTest.zip"
	err := UnZip(home, filePath)
	return err
}

//获取指定目录下的所有文件和目录
func GetFilesAndDirs(dirPth string) (files []string, dirs []string, err error) {
	dir, err := ioutil.ReadDir(dirPth)
	if err != nil {
		return nil, nil, err
	}

	PthSep := string(os.PathSeparator)
	//suffix = strings.ToUpper(suffix) //忽略后缀匹配的大小写

	for _, fi := range dir {
		if fi.IsDir() { // 目录, 递归遍历
			dirs = append(dirs, dirPth+PthSep+fi.Name())
			GetFilesAndDirs(dirPth + PthSep + fi.Name())
		} else {
			// 过滤指定格式
			ok := strings.HasSuffix(fi.Name(), ".log")
			if ok {
				files = append(files, dirPth+PthSep+fi.Name())
			}
		}
	}
	return files, dirs, nil
}

type TestFilePackageVersion struct {
	Version string `yaml:"version"`
}

func GetTestFilePackageVersion() (filePackageVersion TestFilePackageVersion, err error) {
	home, _ := os.UserHomeDir()
	version := TestFilePackageVersion{}
	versionFilePath := home + `/dictpenUiAutomaticTest/version.yml`
	versionFile, err := ioutil.ReadFile(versionFilePath)
	if err != nil {
		return version, err
	}
	err = yaml.Unmarshal(versionFile, &version)
	if err != nil {
		log.Println("Unmarshal: ", err)
		return version, err
	}
	// log.Println("version:", version)
	return version, err
}
func GetTestScriptsVersion() (filePackageVersion TestFilePackageVersion, err error) {
	home, _ := os.UserHomeDir()
	version := TestFilePackageVersion{}
	versionFilePath := home + `/dictpenUiAutomaticTest/version.yml`
	versionFile, err := ioutil.ReadFile(versionFilePath)
	if err != nil {
		return version, err
	}
	err = yaml.Unmarshal(versionFile, &version)
	if err != nil {
		log.Println("Unmarshal: ", err)
		return version, err
	}
	// log.Println("version:", version)
	return version, err
}

// 判断所给路径文件/文件夹是否存在
func Exists(path string) bool {
	_, err := os.Stat(path) //os.Stat获取文件信息
	if err != nil {
		return os.IsExist(err)
	}
	return true
}
func CheckIfdictpenUiAutomaticTestFolderExists() bool {
	sysType := runtime.GOOS
	home, _ := os.UserHomeDir()
	var dirPath string
	switch sysType {
	case "darwin":
		dirPath = home + "/dictpenUiAutomaticTest"
	case "linux":
		dirPath = home + "/dictpenUiAutomaticTest"
	case "windows":
		dirPath = home + "\\dictpenUiAutomaticTest"
	}
	return Exists(dirPath)
}

// 现在先直接判断吧，以后要改成从服务端获取数据的形式
func CheckTestFilePackageVersion() bool {
	if !CheckIfdictpenUiAutomaticTestFolderExists() {
		return false
	}
	testFilePackageVersion, err := GetTestFilePackageVersion()
	if err != nil {
		return false
	}
	if testFilePackageVersion.Version != scriptsVersion {
		return false
	}
	return true
}
func CheckTestScriptsVersion() bool {
	if !CheckIfdictpenUiAutomaticTestFolderExists() {
		return false
	}
	testFilePackageVersion, err := GetTestFilePackageVersion()
	if err != nil {
		return false
	}
	if testFilePackageVersion.Version != scriptsVersion {
		return false
	}
	return true
}
func RemovedictpenUiAutomaticTestFolder() (err error) {
	sysType := runtime.GOOS
	home, _ := os.UserHomeDir()
	var dirPath string
	switch sysType {
	case "darwin":
		dirPath = home + "/dictpenUiAutomaticTest"
	case "linux":
		dirPath = home + "/dictpenUiAutomaticTest"
	case "windows":
		dirPath = home + "\\dictpenUiAutomaticTest"
	}
	return os.RemoveAll(dirPath)
}
