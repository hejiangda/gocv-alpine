package adbUtil

import (
	"fmt"
	"log"
	"regexp"
	"strconv"
	"strings"
	"testing"
)

func init() {
	SetAdbExecutable()
}
func TestGetAPKVersion(t *testing.T) {
	want := regexp.MustCompile("YDM011_0.1.1_20220128")
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := GetAPKVersion(sn)
	if !want.MatchString(msg) || err != nil {
		t.Fatalf(`Get apk version failed! msg:%v`, msg)
	}
}
func TestGetMCUVersion(t *testing.T) {
	want := regexp.MustCompile("TL016-BASE-20220113")
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := GetMCUVersion(sn)
	if !want.MatchString(msg) || err != nil {
		t.Fatalf(`Get apk version failed! msg:%v`, msg)
	}
}
func TestGetWifiStatus(t *testing.T) {
	want := regexp.MustCompile("SSID: \"[^\"]+\"")
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := GetWifiStatus(sn)
	log.Println(msg)
	SSIDret := want.FindString(msg)
	var wifi string
	fmt.Sscanf(SSIDret, "SSID: %s", &wifi)
	log.Println(wifi)
	//log.Println(SSIDret)

	wangt1 := regexp.MustCompile("SignalStrength: -[0-9]*")
	SignalStrength := wangt1.FindString(msg)
	var SignalStrengthVal float64
	fmt.Sscanf(SignalStrength, "SignalStrength: %v", &SignalStrengthVal)
	log.Println(SignalStrengthVal)
	log.Println(SignalStrength)

	//if !want.MatchString(msg) || err != nil {
	//	t.Fatalf(`Get apk version failed! msg:%v`, msg)
	//}
}
func TestGetWifiInfo(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	connected, ssid, signalStrength := GetWifiInfo(sn)
	log.Println(connected, ssid, signalStrength)

}
func TestInstallSoloPi(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := InstallSoloPi(sn, "/Users/hejiangda/Downloads/")
	log.Println(msg)
	if err != nil {
		t.Fatal(err)
	}
}

func TestStartSoloPi(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := StartSoloPi(sn)
	log.Println(msg)
	if err != nil {
		t.Fatal(err)
	}
}
func TestCloseVoiceAssistant(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := CloseVoiceAssistant(sn)
	log.Println(msg)
	if err != nil {
		t.Fatal(err)
	}
}

//
func TestOpenVoiceAssistant(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := OpenVoiceAssistant(sn)
	log.Println(msg)
	if err != nil {
		t.Fatal(err)
	}
}
func TestGetVoiceAssistantStatus(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := GetVoiceAssistantStatus(sn)
	log.Println(msg)
	if err != nil {
		t.Fatal(err)
	}
}
func TestExportLogCat5Min(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := ExportLogCat5Min(sn)
	log.Println(msg)
	if err != nil {
		t.Fatal(err)
	}
}
func TestFilterVoiceAssistantWakeUpTime(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	va := new(VoiceAssistant)

	msg, err := va.FilterVoiceAssistantWakeUpTime(sn)
	log.Println(msg)
	if err != nil {
		t.Fatal(err)
	}
}

func Test1(t *testing.T) {
	wantProgressString := regexp.MustCompile("update progress: \\d+(\\.\\d+)?")
	wantProgressVal := regexp.MustCompile("\\d+(\\.\\d+)?")
	wantStatusString := regexp.MustCompile("RsInstallManger: status \\d+")
	wantStatusVal := regexp.MustCompile("\\d+")
	wantSuccess := regexp.MustCompile("RsInstallManger: UPDATE SUCCESS!")

	progressStr := "02-05 17:41:21.765  1187  1207 D AOTA    : RsInstallManger: update progress: 0.14427792"
	statusStr := "02-05 17:41:21.765  1187  1207 D AOTA    : RsInstallManger: status 3"
	success := "02-05 17:44:35.454  1187  2959 D AOTA    : RsInstallManger: UPDATE SUCCESS!"

	s := wantProgressString.FindString(progressStr)
	progressValStr := wantProgressVal.FindString(s)
	if progressValStr != "" {
		val, err := strconv.ParseFloat(progressValStr, 64)
		if err != nil {
			t.Fatal(err)
		}
		log.Println(val)
	}
	s1 := wantStatusString.FindString(statusStr)
	statusValStr := wantStatusVal.FindString(s1)
	if statusValStr != "" {
		statusVal, err := strconv.ParseInt(statusValStr, 10, 32)
		if err != nil {
			t.Fatal(err)
		}
		log.Println(statusVal)
	}
	ok := wantSuccess.MatchString(success)
	log.Println(ok)

}
func TestClearCache(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := ClearCache(sn)
	log.Println(msg)
	if strings.TrimRight(msg, "\r\n") != "Success" {
		t.Fatal("msg is not equal to 'Success'")
	}
	if err != nil {
		t.Fatal(err)
	}
}
func TestExportBugReport(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := ExportBugReport(sn, "/Users/hejiangda")
	log.Println(msg)

}

func TestGetLightSwitchStatus(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := GetLightSwitchStatus(sn)
	log.Println(msg)

}
func TestGetLightMode(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := GetLightMode(sn)
	log.Println(msg)

}
func TestOpenCloseLight(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := OpenCloseLight(sn, 1)
	log.Println(msg)
}
func TestOpenCloseLight2(t *testing.T) {
	devices, err := GetDevices()
	if err != nil || len(devices) < 1 {
		t.Fatalf(`Can not found devices!`)
	}
	sn := devices[0][0]
	msg, err := OpenCloseLight(sn, 0)
	log.Println(msg)
}
