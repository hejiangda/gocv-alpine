_audio_file_path=""
_audio_file_name=""
_screenshot_output_folder_path=""

print(_audio_file_name)


-- 点击语音查询图标
click_img("点我开启语音查询的图片")
-- 播放音频文件
play_mp3(_audio_file_path)
-- 点击结束录音图标
click_img("结束录音图标")
-- 认为5秒后查询已经完成
wait(5)
-- 循环50次 一直下滑，如果滑到底就退出
for i=1,50,1 do
    -- 判断屏幕有没有变化
    if is_screen_changed() then
        -- 如果变化了，就把当前的屏幕截图设置为历史截图
        set_last_screen_shot()
        -- 每次滑动前把当前的截图保存到文件夹中
        screen_shot(_screenshot_output_folder_path,_audio_file_name)
        -- 滑动一个屏幕
        slip("up",2,10) --滑动半个屏幕，参数1为left,right,up,down，参数2为滑动的次数，参数3为滑动速度
    else
        -- 屏幕没有变化，则退出滑动
        break
    end
end








---- gohome()
--click_img("1305_s88tyj.png",1,0.95) --点击图片1305_s88tyj.png默认检查第一张图片，默认阈值为0.95
--wait(1)
--for i=1,counts,1 do
--    click_img("1305_mnhx24.png",1,0.95) --点击图片1305_mnhx24.png默认检查第一张图片，默认阈值为0.95
--
--    print(mp3Array[i])
--    play_mp3(mp3Array[i])
--    click_img("1305_c690sb.png",1,0.95) --点击图片1305_c690sb.png默认检查第一张图片，默认阈值为0.95
--    wait(5)
--    screen_shot()
--
--    click_img("1177_3tab4f.png",1,0.95) --点击图片1177_3tab4f.png默认检查第一张图片，默认阈值为0.95
--end
