package main

import (
	"flag"
	"fmt"
	"github.com/faiface/beep"
	"github.com/faiface/beep/mp3"
	"github.com/faiface/beep/speaker"
	"github.com/faiface/beep/wav"
	"os"
	"path"
	"strings"
	"time"
)

var audioFilePath string

func main() {
	flag.StringVar(&audioFilePath, "file", "", "要播放的音频文件，支持mp3、wav")
	flag.Parse()
	// 简单播放mp3
	// 再支持wav文件
	ext := path.Ext(audioFilePath)
	ext = strings.ToLower(ext)

	done := make(chan bool)
	dura := make(chan time.Duration)

	playMp3 := func() {
		go PlayMp3(audioFilePath, done, dura)
		tim := <-dura
		fmt.Printf("%v", int(tim.Seconds())+1)
		<-done
		return
	}
	playWav := func() {
		go PlayWav(audioFilePath, done, dura)
		tim := <-dura
		fmt.Printf("%v", int(tim.Seconds())+1)
		<-done
		return
	}

	switch ext {
	case ".mp3":
		playMp3()
	case ".wav":
		playWav()
	}

}

func PlayWav(filePath string, done chan bool, dura chan time.Duration) {
	f, err := os.Open(filePath)
	if err != nil {
		panic(err)
	}

	streamer, format, err := wav.Decode(f)
	if err != nil {
		panic(err)
	}
	dura <- format.SampleRate.D(streamer.Len())

	defer streamer.Close()
	speaker.Init(format.SampleRate, 2)
	speaker.Play(beep.Seq(streamer, beep.Callback(func() {
		done <- true
	})))

	<-done
}

func PlayMp3(filePath string, done chan bool, dura chan time.Duration) {
	f, err := os.Open(filePath)
	if err != nil {
		panic(err)
	}

	streamer, format, err := mp3.Decode(f)
	if err != nil {
		panic(err)
	}
	dura <- format.SampleRate.D(streamer.Len())
	//fmt.Println("mp3 duration:", format.SampleRate.D(streamer.Len()))

	defer streamer.Close()

	// speaker.Init(format.SampleRate, format.SampleRate.N(time.Second/20))
	speaker.Init(format.SampleRate, 2)
	speaker.Play(beep.Seq(streamer, beep.Callback(func() {
		done <- true
	})))

	<-done
}
