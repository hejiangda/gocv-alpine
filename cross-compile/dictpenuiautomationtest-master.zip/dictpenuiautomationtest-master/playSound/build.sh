#!/bin/bash
tar -xf alsa-lib-1.2.6.1.tar.bz2
cd alsa-lib-1.2.6.1 || exit
./configure --enable-shared=no --enable-static=yes
make
make install
cd ..

