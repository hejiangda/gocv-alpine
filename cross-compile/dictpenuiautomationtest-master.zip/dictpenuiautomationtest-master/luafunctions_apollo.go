package main

import (
	lua "github.com/yuin/gopher-lua"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"image"
	"log"
)

type Apollo struct {
}

// Click 点击文字可以用 但back_btn不能用
func (a *Apollo) Click(L *lua.LState) int {
	incTestStep()
	ret := Click(L)
	return ret
}

// ClickCoordinate 可用
func (a *Apollo) ClickCoordinate(L *lua.LState) int {
	incTestStep()
	return ClickCoordinate(L)
}

// ClickScreenCoordinate 可用
func (a *Apollo) ClickScreenCoordinate(L *lua.LState) int {
	incTestStep()
	ret := ClickScreenCoordinate(L)
	return ret
}

// ClickImg 可用
func (a *Apollo) ClickImg(L *lua.LState) int {
	incTestStep()
	ret := ClickImg(L)
	return ret
}
func (a *Apollo) ClickPowerBtn(L *lua.LState) int {
	return unimplemented()
}
func (a *Apollo) ClickSoundHelperBtn(L *lua.LState) int {
	return unimplemented()
}

// SlipHalfScreen 可用
func (a *Apollo) SlipHalfScreen(L *lua.LState) int {
	incTestStep()
	ret := SlipHalfScreen(L)
	return ret
}
func (a *Apollo) SlipFromToCoordinate(L *lua.LState) int {
	incTestStep()
	ret := SlipFromToCoordinate(L)
	return ret
}

// SlipFromToScreenCoordinate 可用
func (a *Apollo) SlipFromToScreenCoordinate(L *lua.LState) int {
	incTestStep()
	ret := SlipFromToScreenCoordinate(L)
	return ret
}

// SlipDropDownMenu
func (a *Apollo) SlipDropDownMenu(L *lua.LState) int {
	incTestStep()
	apolloSlipDropDownMenu := func(L *lua.LState) int {
		log.Println("滑动{下拉菜单}")
		interval := L.ToInt(1)
		if interval == 0 {
			interval = 5
		}
		a := image.Point{
			X: 221,
			Y: 10,
		}
		b := image.Point{
			X: 221,
			Y: 609,
		}

		page, err := device.FetchScreenShot()

		if err != nil {
			panic("  <font size=5 color=red >获取 page 失败,err:" + err.Error() + "</font>")
			return 1
		}
		saveScreenShot(page.ScreenShot, "下拉菜单前")
		err = page.Slip_ShownScreen(a, b, interval)
		page, err = device.FetchScreenShot()
		saveScreenShot(page.ScreenShot, "下拉菜单后")
		if err != nil {
			panic("  <font size=5 color=red >滑动失败{下拉菜单},err:" + err.Error() + "</font>")
			return 1
		}
		log.Println("  滑动成功{下拉菜单}")
		L.Push(lua.LBool(true))
		return 1
	}

	return apolloSlipDropDownMenu(L)
}

// SleepForSecond 可用
func (a *Apollo) SleepForSecond(L *lua.LState) int {
	incTestStep()
	return SleepForSecond(L)
}

// CheckContain 可用
func (a *Apollo) CheckContain(L *lua.LState) int {
	incTestStep()
	return CheckContain(L)
}

// CheckImg 可用
func (a *Apollo) CheckImg(L *lua.LState) int {
	incTestStep()
	return CheckImg(L)
}

// GoHome 可用
func (a *Apollo) GoHome(L *lua.LState) int {
	incTestStep()

	err := L.DoString(`
	print("开始回到首页")
	click_xy(0,0) --点击屏幕上的坐标点
	click_physical_buttons("menu",0)
	click_physical_buttons("menu",0)
	save_base64_img("1667_dba4s4.png","iVBORw0KGgoAAAANSUhEUgAAAHAAAAAlCAYAAACao20PAAAQjklEQVR4Xu1aCVTPadu+QispinYxbcoSM5Z5v8++jLEVsoeyhRLeIWFmjOEbr91MWRKSNfuuopnXLvtghDbZoiLRQgv1nevOP5V/y8zbHK9zes5xSv/f/3me333d93Vf9/08KhkZGXmoHJ+sBVQqAfxksZONVwL4aeNXCeAnjl/FApiXl4eo6GjU0deHrq4uqlSpUuH24Rq5ubngT87/d6xR0ZvOefMGKSkpMq1qtWqoVatWhS1RoRQaExMD3xUroQIVuLmNgbW1NapVq1bmZjMzM3EsLEyet7K0RNWqVUv8Tnx8PI4EByMhIQG9e/VC8+bNy5z/9u3bSEtLg52dHWrUqFHwfFZWFjIyMsQhyjPU1NSgra0NFRWV8jxe8ExiYhI2b9mCx48fo22bNujbt8+f+n5pD5cKIF8sODgE2dnZSufgi3Tp0lleis8uXrwUO3buhImJMUa6usLc3LxIhJiYmEBPr3YRgDh3UNB27Ny1GxaffYZx48bC1tZWaWQx6m7dvo0lS5YiKioKM2Z4C4iljYiICGzeshX379+Hg4MDevbogZo1teUr0dExOHz4CCIjI8s0KN+1adMmcHEZAS0trQ+e5/vn5OTIvlVVVYt8fu/ePcyePUf2PszZGVOmTCryOd+LduAadJI/M0oF8O3btxjqPBzJyc8BfFhtkA7WrPGDmZkpzl+4gB9/nIfY2Fjo6+vDyMgQqqrvN1OligomenigZcsWRTb55s0bhISESuQmJDxB506dMX78OFhbW33g6QoAFy9egjt3IjFr5gw4OPQu9X3vxsXB338tjhw5AhMTU7i4DIdD796oXr06rly5Ch9fX/z++zXo6emVyBavXr1CcnIy2rdvh0ULF0BHR6fImgTujz/+QFDQDlhYfIZRo0YWecfSAOQ7MTJ/8fFFzZo1MWXypCIsURaYZUag94yZePHiBbKysnHp0iWoq6nB3r6pbJBU98OcH1CtajV8P/sHnD59GsbGJqipXaPA+M9TnuPJkwTJWStW+KB9u3YfeOjLly+xf/8BbAjcKLnC0dFBjFDf3PwDT424dQsEMCoqGjMJYO/SIzDfuDcRsCEQx4+fQP365hg9aiR69OiOiIhb8PVdgScJCejj6IDGjRsrsVcerl79Xb7funUrLF608AMAScVHjx6D13RvtGrZEv7+ftDU1CyYqzQAGbm3b99BP6f+MDI0xO7du6Cvr1cWbgWfl5kDSVXZ2Tk4ceIE1q5bh0Z2jeDp6SHewpA3M6snHr41aBtq6ehi0iRPGBsbsUIRrySlPnjwQCJlwoQJMK9XT2kOoYdv2bJNnn/79g3c3d3h6OAAXd333k4n4JyLlyzD3bt3MXOGN3r16lnmyxLEa9euw3/tWpw5cxa9e/WEp+dEJCU9FQCfp6RgxIjhwg7FB9c8e+Ysli5bjhYtvigRwNCjR/HNN15o3aol1q9f+ycBvA0Hx74wNjbGvr17KhZAvhC9xHvGLASHBMN9wni4urgIBfHvpI01/v4SpWPHjEbPnj1QvXoNJCUlwW+Nv0Rlu7ZtMGBAf1haWgqtUqGqqRXNE1yHAsXPzx/Pnz/HwIED0KpVyyKGoDGvXLkixoyNvYtZs2ZK5JRnMEpI8+fPn5cc26F9e8mBpFBGKPN1rVq6SgCE0Gd0dDTatm3zaQJIinPqP1AMvHnzRjSztxf6pABYtdpP8h6Td/NmzUTQQEUF6WlpuBkRAeaPhg1tYGBgIDnG1NQULiOGo169ekq9nRGfm5uHevXMxEkKDwJ46tRpyRc06HfffYtBAweUBz95hnuhGtXU0kJNbe13OXAFbt26BXPzetDQ0FA6F2k9Lu4e2rT5308PQBrt2LEwiUATYyMEBKwTMPh30sZPP/1LJD3/T1olsPydhuJPKjZFWUDJbtuwIebP/z+R9MwNlPjp6ekFhmOEtmrV6h0NF7Un5zt06LA4TVxcHLy9p2PYMGeoFVN9im9JzZiXJ/soPKqoqIjDUcSQQp8+e4qBAwbA3t7+Q6dCHi5eugS/1WuEYkvKgQoKJWusX+dfRKmWnQP/Rgp9+zYXEz09ceLESVhZWQmNaKirixDp1LkTTp06hbVr1yMtLRVTp34DE2MTpKWnwcdnBagwx44dDWMjYyQkJiIwcCN0dXQEQNLY2bNnERCwAffvP8g3nAqgr6ePadOmlpiPAjduwvr1AeI0VKsUO7VLKIwfPYpHWFiYMIFMr6ICIyMjdOncWYSYAsDEpCQRTnQuZTmQKnXjpk1C6aUDOE0cr0f37qha7X0tm5aahnPnwiXnct2m9k0KlqFzPX+egt2791R8DuTkN27cwAR3JvwkkbeKGkddXR2bN21EjRrVMWy4Cx7Hx4uCovx/9iwZLq6uolxXrfSVAj0mNhZTp05DFZUqBQCSDjdt3oJHjx5JPiUojOIF/5ovjqLMmIuXLMWWLVuFDilGKIy4prJBlblixUqE/fprgYPYNbSFh8cEdOvWraCMoMAhqxRWjoXnS0tNxeMnT9CubVssWrRAcnjhwfyaH4HThG2K14mKOo8OTZou3qjgu5OdKlzEcOIZM2bh0OHDUqR26tgR1bVr4PKlyyL3Dx86KEW7Y5++uHs3DoMHDUJtvdrgC9GjuPHu3b+WGuvly1SEhISgbp06BRRKp3jw8CEyX7/Grdt3sGPHDmRmZpUIIEGbO3ce9uzdJ3MztzLqO3booBRAiqGbNyPwKD5e9kclrampgYke7gUAkkIjo6JgY2MtzlPa0NDQxBdffC6lS2GwaRuus2fPXqVff/UqA9eu3wA7Mo0b28HKUrnD6ejqYPy4cdDWft8tKivBl1hG0EDnzp3DtOkz8DQpSejnp5/moWmTJvju+9mIiozCwYMHYGpqAgfHPqLoKGAU3pWamiprU4go8iJzXUMbmwIAC+eqkydPgdFFNassArkfCpcFCxbh0uXLBX3QqVP/KY6jrGXH77AZQVFE9blq9Wrx9OIAJj9PhvPQoSLff/vt33ibm4uvunYRZcpBw//27+NC+Sxrxrm5oXPnTkVokM5Fh1E24uMfw4eOEhkJp379MHy4s9LnaKe6deuWq/2omKBEABl9M2d9i4MHD8HOzlaKTR+fn6WX5+I6CrciIgRARQTei7uHIUOGwMCgLrKys7FtW5BESe/evVCnTh28SEnBgYOHpNGtEDF/FsDde/ZIzammpi7FdFzcXXTu1Alubm6iWksbdEZf35VIz0j/AMCXqamYONEdpiamUitevHhJaj6CpF1DG8EhoVK+MH2wbGH70MLComA5tun27tsHTU0tsU+jRnZFtlJWK4294EuXLuPkyZOoU7eOOEh5R6kRGLR9O0KCQ2FoZIjQ0KNYvnzpBwAyaZNC6WUbAwOk1kt58QJubuOFdhcvXgQrK0sQ4JmzZknX5q8AmJHxCgsXLcLevfukKdCkSWMcOHAQL1JeCI127drlPwTQQ4pwlhRHjgTj1OnTUFfXEMGWlp6Of3zZGl27dpVuDfu5hZ2PjODl5S25cfKkiejU6X108rmyACQz7dq1Gz//4gMbGxvs3BFUXvxKP05ihyI25i5CQkNkAWUAGhoaCICPHz/BvLk/gg1retScOT8KFbEzY2ZqgqdPn8oGtTS1ygWglbUVHty/LzRGWgkPD8fyn39BTEwsvLymSXT4+vri0KEjGDRoIEaNdIWhoWGJL152BHqgY4f2UrRTMYaHn0d0TAyuX78uvV5XV1cMHjQQFG+FB1nm4sWLmDR5igDoPd3rLwG4c+cuLFi4CI0aNcK+vbsrBkDOQuW0aPESOTFQBiC7F079B+Dhg0ewtrHKL4bzgDvvOvzsPfJvjEYKic8aNCgTQJYHVKYx0TEYO3aMUDjBZ/Q1b94Mkyd5Ss22f/9+6dxwTJ7sKcKkpKOos+8oNCMjHR4e7vi6WzehSh8fX2mldejQTvLq/XsPwMYFTx5atGghUR5+/rw45tdfd0PPHt1FLRaOwP9qACkAFixcWCKA7FuOGj1WCnfSC9WZwispfOhR1atrISc75503m5UKYGJiIkxNTKTBzIiiSHn29Bn8165DUlKiRHR/JycpaVh2LFv+sxx5derYAePGjfsg/9DQZAQyCFt7dCQeCQ0c0F/SApsCFCA6OjVF4HDvlhaWcHJyQp8+DnIMxUb1ocNH8CojA126dMHgwYNEAXP810dgYQBZYFtaWGDJ0mWIjYnBgQP7pUieP3++NLU9J7pDT18fLFxnffudKMAZ3l6oZ24uRyY8RdDU0FQKINUfe5zssFBAUQgMGTxYzu6Ctu+QJE/x4OE+QfIEB58LC/sVK1etEgpnv3WY81CJFsXgHqhw/daswfXrN+TPNtbW8izFy9at26CqWk2cr3HjRtLiM6hbF2ZmZuJABIi0yiZ4cEiIOOh0Ly8Rb58UgFu3BslRjKaGhhiZXh0UtE1Omo8ePSpSntRXu3ZtKeRHuLCQzyoo5CMjo+DlNV0oTpmIYUdmQ2AgEhISpQvj7OwMfT097Ny1C8ePH4epqRkmTvRAh/btiuQh1qObNm0WkKkShw9zhpNTP6k9OUiTVK6kQXZBdHV0ceHiRejVro36DerL2WUjOztxGOZbqlsyR/FTd4oonoBkZ2ehWbNmQrd8RhGBnpOmSAHP9W3tbIvkMOb/oG3b5boJT09IxYVHVmYmwsMvIHDjxorPgdzg0qXLcPRYWJGTeQLJXMIc8vDRI6zw/QVt27YV4xYGcPTokTA0MMDNmzexY+duMdIPs7+XwrlwHlm3bj3YJuOp/IgRw+TeCJsBx8J+leLbbewYOVEv3gXh/phbV6/2k24Iy5ihQ4fIoS3BDQgIREhoqAiRMWNGo0GDBjIv6fPNmxyJNIO6BlKvcu9VqlYBe6UqKvn3bQRIlXyqzK8pc6Uhz5N9OnRhAEnF/Kx4JyYnJ1sck2mGUU0nLzxyc9+CdTNbfxUuYrgQG85Pnz4rcneEL8ImN7srFpYWWL5sqdAPX7gwgKS9O7fviPc+S06Go6Oj1GFsABQGkFFNJ7GztcXnnzeXrkbAhg1IT8/A8OHDMGTwoBJVJvu1V69exWo/P1GQ/fr2hbv7eIlIHhKzZcfuCdUqmw0PHz7EmbPncObMGTnUffbsmYg1ReQV/5m/TzbF83/78svWmDd3rrwDAfz92jXMmTMXr1+/LgJMef/DObKyMqVh8LcAqGwj9EYafPv27ejTxxHdvvqq4PiHRucVBhb0tXR1cPLUabCfyHKgZ8+eaNbMXunRDQGurqUln/HgdsvWrTAyNEK/fv2kUC/tMhHp+sKFCwg/fwH2TZugXbt2kq9I3cy/bMQzChWDtRfbeBRC9P7M15nCMHRM/qNTMDLkJENOL/JPMFSrqUq+b9PmfwquTTDSeVMgL/evXXLn3nnbIfToMWEm/zV+5cX+P7tW+DozE5F37ggtKU7oFeKCdKK46EMPp0GoHNk0Vlcv++IOHYRRy3nZySnP9UFGAMEgcIq+poL22GoryQEIEiOQdWveuyuLFG/5x1AKUN6DyLmKX1wqt8WVPMi1SZ9kITIEu0DlHWVeqSjvRJXPfRwLVAL4cexeYatWAlhhpvw4E1UC+HHsXmGrVgJYYab8OBNVAvhx7F5hq1YCWGGm/DgTVQL4cexeYatWAlhhpvw4E/0/KZc20mZswYEAAAAASUVORK5CYII=")
	
	if check_img("1667_dba4s4.png",1,0.70) --检查图片 默认检查第一张图片，默认阈值为0.90
	then
	  click_img("1667_dba4s4.png",1,0.70) --点击图片 默认检查第一张图片，默认阈值为0.90
	  click_physical_buttons("menu",0)
	  click_physical_buttons("menu",0)
	end
	slip('down',3,100)
	print("已经回到首页")`)

	if err != nil {
		panic(err)
	}
	return 0
}

// LogInfo 可用
func (a *Apollo) LogInfo(L *lua.LState) int {
	return LogInfo(L)
}

// Print 可用
func (a *Apollo) Print(L *lua.LState) int {
	return LogInfo(L)
}

func (a *Apollo) ClickPhysicalButton(L *lua.LState) int {
	// click_physical_buttons("按键名","持续时间")
	buttonName := L.ToString(1)
	L.Remove(1)

	click := func(name, command string) func(L *lua.LState) int {
		return func(L *lua.LState) int {
			ldelay := L.ToNumber(1)
			log.Println("点击{" + name + "}")
			res, err := adbUtil.ClickPhysicsButtonExec(device.SN.Data, command, int(ldelay*1000))
			if err != nil {
				panic("  <font size=5 color=red >点击失败{" + name + "},res: " + res + " err: " + err.Error() + "</font>")
				return 1
			}
			log.Println("  点击成功{" + name + "}")
			L.Push(lua.LBool(true))
			return 1
		}
	}
	//apolloClickMenu := func(L *lua.LState) int {
	//	ldelay := L.ToNumber(1)
	//	const BTNNAME = "菜单键"
	//	log.Println("点击{" + BTNNAME + "}")
	//	res, err := adbUtil.ClickPhysicsButtonExec(device.SN.Data, "menu", int(ldelay*1000))
	//	if err != nil {
	//		log.Panicln("  <font size=5 color=red >点击失败{"+BTNNAME+"},res: ", res, " err: ", err, "</font>")
	//		return 1
	//	}
	//	log.Println("  点击成功{" + BTNNAME + "}")
	//	L.Push(lua.LBool(true))
	//	return 1
	//}

	switch buttonName {
	case "power":
		return click("电源键", "power")(L)
	case "menu":
		return click("菜单键", "menu")(L)
	case "volume_up":
		return click("音量上键", "sound_up")(L)
	case "volume_down":
		return click("音量下键", "sound_down")(L)
	case "pause":
		return click("播放/暂停键", "play")(L)
	case "back":
		return click("回退键", "back")(L)
	case "forward":
		return click("前进键", "forward")(L)
	}
	return unimplemented()
}

func (a *Apollo) PlayMp3(L *lua.LState) int {
	return playMp3(L)
}

func (a *Apollo) ScreenShot(L *lua.LState) int {
	return ScreenShot(L)
}
