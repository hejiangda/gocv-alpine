package main

import (
	"archive/tar"
	"compress/gzip"
	"encoding/base64"
	"encoding/json"
	"flag"
	"fmt"
	lua "github.com/yuin/gopher-lua"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/aladdin"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/locationUtil"
	pb "gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/pb"
	"gocv.io/x/gocv"
	"google.golang.org/grpc"
	"image/gif"
	"io"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

var device locationUtil.Device
var rpcServer *grpc.Server
var waitGroup sync.WaitGroup

type deviceSN struct {
	Cnt int
	Sns []string
}

func DownloaddictpenUiAutomaticTestFile() error {
	url := `https://hwp-static.inner.youdao.com/files/dictpenUiAutomaticTest.zip`
	home, _ := os.UserHomeDir()
	err := DownloadFile(url, home+"/dictpenUiAutomaticTest.zip")
	return err
}
func DownloadFile(url string, filepath string) error {
	// Create the file
	out, err := os.Create(filepath)
	if err != nil {
		return err
	}
	defer out.Close()

	// Get the data
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	// Write the body to file
	_, err = io.Copy(out, resp.Body)
	if err != nil {
		return err
	}

	return nil
}
func downloadTestFiles() (err error) {
	log.Println("清除原有文件")
	adbUtil.RemovedictpenUiAutomaticTestFolder()
	log.Println("下载测试数据")
	err = DownloaddictpenUiAutomaticTestFile()
	if err != nil {
		panic("Download ocr nmt test file failed! err:" + err.Error())
	}
	log.Println("解压测试数据")
	err = adbUtil.UnzipTestFile()
	if err != nil {
		panic("Unzip test file failed! err:" + err.Error())
	}
	log.Println("解压完成")
	return
}

var (
	port = flag.Int("port", 40071, "The server port")
	// 用例文件名
	caseFileName string
	// 日志文件名
	logFileName string
	// 日志图片本地文件夹
	logImgFolder string
	// 用例执行到了第几步
	testStep int
	// 要不要保存执行时的截图
	logImgOpenFlag bool
	// minio上的存放路径
	minioLocation string
	tempDir       string
	outputFolder  string
	mergeImg      bool
)

func init() {
	globalVariable.CurrentOS = runtime.GOOS
	globalVariable.CurrentArch = runtime.GOARCH
	globalVariable.IsInDevice = false
	if globalVariable.CurrentOS == "linux" {
		switch globalVariable.CurrentArch {
		case "arm":
			globalVariable.IsInDevice = true
			globalVariable.Sn = os.Getenv("SN")
		case "arm64":
			globalVariable.IsInDevice = true
			globalVariable.Sn = os.Getenv("SN")
		}
	}
	//fmt.Println("GOOS:", globalVariable.CurrentOS)
	//fmt.Println("GOARCH:", globalVariable.CurrentArch)
	//fmt.Println("IsInDevice:", globalVariable.IsInDevice)
}

// 如果日志要上传到minio上
// 日志存放路径为：uiautomation/1641324312/17.md
// 图片存放路径为：uiautomation/1641324312/17/1.jpg
//
// 	// 日志文件名
//	logFileName string
//	// 日志图片本地文件夹
//	logImgFolder string
//	// 用例执行到了第几步
//	testStep int
//	// 要不要保存执行时的截图
//	logImgOpenFlag bool
//	// minio上的存放路径  是一个时间戳
//	minioLocation string 非空则上传到minio上

func main() {
	var sn string
	var cmd string
	var cmd1 string
	var cmd2 string
	var openCloseLightVal int
	var caseManageId int
	var batchTestId int
	var tester string

	var imgOutputFolder string
	var audioFileList string

	flag.IntVar(&openCloseLightVal, "OpenCloseLight", 0, "open and close light")
	flag.StringVar(&cmd, "cmd", "start", `要执行的命令：start、download(下载最新测试数据)、
	version(查看版本号)
	devices(查看当前存在的设备)、
	enableScreenShot(开启截图)、
	attachAndConnect(一键连接)、
	batchTest(执行测试用例集)、
	batchTestDownload(下载执行测试用例集)、
	rpc(启动rpc服务)
	soundHelper(ai评测语音助手专项测试)`)
	flag.StringVar(&cmd1, "cmd1", "", `附加命令，当cmd为aladdin时
	FetchDeviceInfo、
	`)
	flag.StringVar(&cmd2, "cmd2", "", "附加命令，当前只用于Aladdin的path")
	flag.StringVar(&sn, "sn", "", "设备的sn")
	flag.StringVar(&caseFileName, "case", "", "用例文件的文件名/在批量测试时是执行集tar.gz文件的名字")
	flag.StringVar(&logFileName, "logFileName", "", "日志文件的文件名")
	flag.StringVar(&logImgFolder, "logImgFolder", "", "日志截图存放的文件夹(要带上末尾的斜杠)")
	flag.BoolVar(&logImgOpenFlag, "logImgOpenFlag", false, "日志是否记录截图")
	flag.StringVar(&minioLocation, "minioLocation", "", "存放在minio上的位置")
	flag.IntVar(&caseManageId, "caseManageId", -1, "测试用例管理Id，若输入该Id则程序会下载用例并执行")
	flag.IntVar(&batchTestId, "batchTestId", -1, "用例执行集id")
	flag.StringVar(&tester, "tester", "", "测试者")
	flag.StringVar(&imgOutputFolder, "imgOutputFolder", "", "图片导出目录(仅用于ai评测)")
	flag.StringVar(&audioFileList, "audioFileList", "", "音频文件列表(仅用于ai评测)")
	flag.BoolVar(&mergeImg, "mergeImg", false, "单个用例保存出的图片合成为一张")
	flag.StringVar(&outputFolder, "outputFolder", "", "导出执行集的输出文件夹")
	flag.Parse()

	if sn != "" {
		globalVariable.Sn = sn
	}

	// 日志要被记录下来
	if logFileName != "" {
		// 日志记录在本地
		if minioLocation == "" {
			newFile, err := os.Create(logFileName)
			if err != nil {
				panic(err)
			}
			wrt := io.MultiWriter(os.Stdout, newFile)
			log.SetOutput(wrt)

			f, _ := os.Create(logFileName + ".gif")
			defer func() {
				gif.EncodeAll(f, &animGif)
				log.Println("  全过程gif" + "\n![alt full steps gif](" + logFileName + ".gif" + ")")
				f.Close()
				newFile.Close()
			}()
		} else {
			// 日志保存在云端
			var err error
			tempDir, err = ioutil.TempDir("", "dictpenLog")
			if err != nil {
				panic(err)
			}
			newFile, err := os.Create(tempDir + string(os.PathSeparator) + logFileName)
			if err != nil {
				panic(err)
			}
			wrt := io.MultiWriter(os.Stdout, newFile)
			log.SetOutput(wrt)
			err = InitMinioClient()
			if err != nil {
				panic(err)
			}
			imgGifFilePath := tempDir + string(os.PathSeparator) + logFileName + ".gif"
			gifFile, _ := os.Create(imgGifFilePath)
			defer gifFile.Close()

			defer func() {
				// 将文件2与文件1追加合并
				appendFile := func(file1, file2 *os.File) error {
					_, err := file2.Seek(0, io.SeekStart)
					content, err := ioutil.ReadAll(file2)
					if err != nil {
						return err
					}
					_, err = fmt.Fprintf(file1, "%s", string(content))
					return err
				}
				newFile1, err := os.Create(tempDir + string(os.PathSeparator) + "1" + logFileName)
				wrt1 := io.MultiWriter(os.Stdout, newFile1)
				log.SetOutput(wrt1)
				gif.EncodeAll(gifFile, &animGif)
				url, err := uploadGifImgFile(minioLocation, logFileName+".gif", imgGifFilePath)
				log.SetPrefix("")
				log.SetFlags(0)
				if err == nil {
					log.Println("  全过程gif" + "\n![alt " + imgGifFilePath + "](" + url + ")")
				}
				if err := recover(); err != nil {
					log.Println("用例执行失败，原因:", err)
					err := appendFile(newFile1, newFile)
					if err != nil {
						fmt.Println(err)
					}
					newFile.Close()
					newFile1.Close()
					uploadMarkdownFile(minioLocation, logFileName, tempDir+string(os.PathSeparator)+"1"+logFileName)
					//uploadMarkdownFile(minioLocation, logFileName, tempDir+string(os.PathSeparator)+logFileName)
					os.Exit(1)
				} else {
					log.Println("用例执行成功！")
					err := appendFile(newFile1, newFile)
					if err != nil {
						fmt.Println(err)
					}
					newFile.Close()
					newFile1.Close()
					uploadMarkdownFile(minioLocation, logFileName, tempDir+string(os.PathSeparator)+"1"+logFileName)

					//uploadMarkdownFile(minioLocation, logFileName, tempDir+string(os.PathSeparator)+logFileName)
				}
			}()
		}
	}
	// 如果要把所有保存的图片合成为一张，则通过defer在程序结束时保存
	if mergeImg {
		defer func() {
			if !UnionImg.Empty() {
				imgbuf, err := gocv.IMEncode(".jpg", UnionImg)
				f, err := os.Create(UnionImgSavePath)
				_, err = f.Write(imgbuf.GetBytes())
				if err != nil {
					panic("图片保存出错")
				}
			}
		}()
	}
	// 当程序在设备上运行时
	if globalVariable.IsInDevice {

	} else {
		// 当程序在pc上运行时
		if !adbUtil.CheckIfdictpenUiAutomaticTestFolderExists() || !adbUtil.CheckTestFilePackageVersion() {
			err := downloadTestFiles()
			if err != nil {
				panic(err)
			}
		}
		adbUtil.SetAdbExecutable()
	}

	switch cmd {
	case "version":
		fmt.Println(globalVariable.VERSION)
	case "start":
		startCase(caseManageId)
	case "download":
		err := downloadTestFiles()
		if err != nil {
			panic(err)
		}
	case "devices":
		devices()
	case "enableScreenShot":
		enableScreenshot(sn)
	case "attachAndConnect":
		attachAndConnect()
	case "rpc":
		runRpcServer()
	case "aladdin":
		err := aladdinTools(cmd1, openCloseLightVal, cmd2)
		if err != nil {
			panic(err)
		}
	case "batchTest":
		batchTest(batchTestId, tester, cmd1)
	case "batchTestDownload":
		if batchTestId == -1 {
			panic("请输入用例执行集id")
		}
		// 1、通过 batchTestId 获取到要执行的所有用例的编号
		// 2、挨个下载
		err := batchDownloadCases(batchTestId)
		if err != nil {
			panic(err)
		}
	case "soundHelper":
		soundHelperSpecific(audioFileList, imgOutputFolder)
	}
}

func startCase(caseManageId int) {
	adbUtil.UpdateInDeviceTools(globalVariable.Sn)
	if caseFileName == "" && caseManageId == -1 {
		panic("please input the case file name!")
	}

	if globalVariable.IsInDevice {
		// 先这样，sn必须给出
		initDevice(globalVariable.Sn, [][]string{})
	} else {
		sns, err := adbUtil.GetDevices()
		if err != nil {
			panic("adb 没有检测到设备！err:" + err.Error())
		}
		initDevice(globalVariable.Sn, sns)
	}

	L := lua.NewState()
	defer L.Close()

	var product Product

	prodStr, err := device.GetProductSerial()
	if err != nil {
		panic(err)
	}
	fmt.Println("Current device:", prodStr)
	if globalVariable.IsInDevice {
		// 先这样，之后再改
		switch prodStr {
		case "coco":
			product = new(InDeviceCoco)
		case "dictpen":
			product = new(InDeviceDictpen)
		case "apollo":
			product = new(InDeviceApollo)
		}
		if product == nil {
			product = new(InDeviceDictpen)
		}
	} else {
		switch prodStr {
		case "coco":
			product = new(Coco)
		case "dictpen":
			product = new(Dictpen)
		case "apollo":
			product = new(Apollo)
		}
	}
	registerLuaFunctions(L, product)
	execLuaCode(L, caseManageId)
}

func devices() {
	sns, err := adbUtil.GetDevices()
	if err != nil {
		panic("adb 没有检测到设备！err:" + err.Error())
	}
	var ret deviceSN
	ret.Cnt = len(sns)
	for _, snArr := range sns {
		sn := snArr[0]
		ret.Sns = append(ret.Sns, sn)
	}

	b, err := json.Marshal(ret)
	if err != nil {
		panic("json err:" + err.Error())
	}
	fmt.Println(string(b))
}

func enableScreenshot(sn string) {
	_, err := adbUtil.GetDevices()
	if err != nil {
		panic("adb 没有检测到设备！err:" + err.Error())
	}

	if globalVariable.Sn == "" {
		panic("请输入要开启截图的设备的SN")
	} else {
		// 之后要重构，暂时先这样
		var prodStr string
		var tmpSn globalVariable.SN
		tmpSn.Data = globalVariable.Sn
		prodStr, _ = tmpSn.GetProductSerial()

		var ok bool
		switch prodStr {
		case "dictpen":
			ok = adbUtil.Auth(globalVariable.Sn)
		case "apollo":
			ok = adbUtil.Auth(globalVariable.Sn)
		case "coco":
			ok = adbUtil.AuthCoco(globalVariable.Sn)
		}

		if !ok {
			panic("adb shell auth failed")
		}
		//authStatus := adbUtil.Auth(sn)
		authStatus := ok
		if !authStatus {
			panic(`Auth device failed! sn:` + sn)
		}
		_, err := adbUtil.PushScripts(globalVariable.Sn)
		if err != nil {
			panic(`Transfer files failed! err: ` + err.Error())
		}
		_, err = adbUtil.EnableWestonDebug(globalVariable.Sn)
		if err != nil {
			panic(`Can not enable weston debug!` + err.Error())
		}
	}
}

func attachAndConnect() {
	_, err := adbUtil.GetDevices()
	if err != nil {
		panic("adb 没有检测到设备！err:" + err.Error())
	}

	if globalVariable.Sn == "" {
		panic("请输入要连接的设备的SN")
	} else {
		// 之后要重构，暂时先这样
		var prodStr string
		var tmpSn globalVariable.SN
		tmpSn.Data = globalVariable.Sn
		prodStr, _ = tmpSn.GetProductSerial()

		var ok bool
		switch prodStr {
		case "dictpen":
			ok = adbUtil.Auth(globalVariable.Sn)
		case "apollo":
			ok = adbUtil.Auth(globalVariable.Sn)
		case "coco":
			ok = adbUtil.AuthCoco(globalVariable.Sn)
		}

		if !ok {
			panic("adb shell auth failed")
		}
		_, err := adbUtil.AttachAndConnect(globalVariable.Sn)
		if err != nil {
			panic(`Attach and connect failed! err: ` + err.Error())
		}
	}
}

func runRpcServer() {
	lis, err := net.Listen("tcp", fmt.Sprintf("localhost:%d", *port))
	if err != nil {
		panic("failed to listen: " + err.Error())
	}
	rpcServer = grpc.NewServer()
	pb.RegisterUiAutomationServer(rpcServer, &server{})
	aladdin.RegisterAladdinServer(rpcServer, &server{})

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	//wg := sync.WaitGroup{}
	waitGroup.Add(1)
	go func() {
		select {
		case sig := <-sigCh:
			log.Println("got signal ", sig, ", attempting graceful shutdown")
		}
		rpcServer.GracefulStop()
		waitGroup.Done()
	}()
	log.Printf("server listening at %v", lis.Addr())
	if err := rpcServer.Serve(lis); err != nil {
		panic("failed to serve: " + err.Error())
	}
	waitGroup.Wait()
}

func aladdinTools(cmd1 string, openCloseLightVal int, cmd2 string) (err error) {
	switch cmd1 {
	case "FetchDeviceInfo":
		err = FetchDeviceInfo(globalVariable.Sn)
	case "FetchWifiInfo":
		err = FetchWifiInfo(globalVariable.Sn)
	case "OpenCloseLight":
		err = OpenCloseLight(globalVariable.Sn, openCloseLightVal)
	case "SetLogcatCacheSize":
		_, err = adbUtil.SetLogcatCacheSize(globalVariable.Sn)
	case "ClearCache":
		_, err = adbUtil.ClearCache(globalVariable.Sn)
	case "ExportBugReport":
		_, err = adbUtil.ExportBugReport(globalVariable.Sn, cmd2)
	}
	return err
}

func batchTest(batchTestId int, tester, cmd1 string) {
	if batchTestId == -1 && caseFileName == "" {
		panic("请输入用例执行集id 或 执行集tar.gz 压缩包")
	}
	// 1、通过 batchTestId 获取到要执行的所有用例的编号
	// 2、挨个调用
	// 3、每执行一个用patch更新一条数据
	if globalVariable.IsInDevice {

	} else {
		sns, err := adbUtil.GetDevices()
		if err != nil {
			panic("adb 没有检测到设备！err:" + err.Error())
		}
		if globalVariable.Sn == "" {
			globalVariable.Sn = sns[0][0]
		}
		fmt.Println(globalVariable.Sn)
	}

	if batchTestId != -1 {
		// 通过执行集id批量执行用例的功能 目前在设备内不能运行
		BatchExecute(batchTestId, globalVariable.Sn, tester)
	} else {
		// 通过用例包执行测试，要满足设备内设备外都能跑
		LocalBatchExecute(caseFileName, globalVariable.Sn, tester, cmd1)
	}
}

func soundHelperSpecific(audioFileList string, imgOutputFolder string) {
	// ai评测语音助手专项测试
	// 1、读入音频文件列表
	if audioFileList == "" {
		panic("音频文件列表为空")
	}
	if imgOutputFolder == "" {
		panic("截图输出目录为空")
	}
	if caseFileName == "" {
		panic("用例名为空")
	}

	sns, err := adbUtil.GetDevices()
	if err != nil {
		panic("adb 没有检测到设备！err:" + err.Error())
	}

	// 打开音频列表文件
	file, err := os.OpenFile(audioFileList, os.O_RDONLY, os.ModePerm)
	if err != nil {
		panic(err)
	}
	defer file.Close()
	// 将文件内容存放在内存中
	content, err := ioutil.ReadAll(file)
	contentStr := string(content)
	//fmt.Println(contentStr)
	// 音频文件列表
	var audioList []string
	if globalVariable.CurrentOS == "windows" {
		audioList = strings.Split(contentStr, "\r\n")

	} else {

		audioList = strings.Split(contentStr, "\n")
	}
	//fmt.Println(audioList)
	// 2、读入模板
	luaFile, err := os.OpenFile(caseFileName, os.O_RDONLY, os.ModePerm)
	luaContent, err := ioutil.ReadAll(luaFile)
	luaContentStr := string(luaContent)
	var luaCodeList []string
	if globalVariable.CurrentOS == "windows" {
		luaCodeList = strings.Split(luaContentStr, "\r\n")

	} else {
		luaCodeList = strings.Split(luaContentStr, "\n")

	}
	for i := range luaCodeList {
		luaCodeList[i] = strings.TrimSpace(luaCodeList[i])
	}
	var profitReport TestExecutionReport
	profitReport.StartTime = time.Now()
	profitReport.Tester = `词典笔语音助手全链路评测`
	profitReport.Sn = sns[0][0]
	profitReport.CaseGroupName = "词典笔语音助手全链路评测"

	//fmt.Println(luaCodeList)
	// lua代码前三行用来定义【音频文件全路径】、【音频文件名】、【导出截图的文件夹】
	if luaCodeList[0] != "_audio_file_path=\"\"" {
		panic("_audio_file_path不为空请按普通用例执行")
	}
	if luaCodeList[1] != "_audio_file_name=\"\"" {
		panic("_audio_file_name不为空请按普通用例执行")
	}
	if luaCodeList[2] != "_screenshot_output_folder_path=\"\"" {
		panic("_screenshot_output_folder_path不为空请按普通用例执行")
	}
	for i, audio := range audioList {
		if audio == "" {
			continue
		}
		finalAudio := audio
		finalImgOutputFolder := imgOutputFolder
		fmt.Println("正在测试第 " + strconv.Itoa(i) + " 条音频")

		if globalVariable.CurrentOS == "windows" {
			audioPaths := strings.Split(audio, "\\")
			var build strings.Builder
			for j := 0; j < len(audioPaths)-1; j++ {
				build.WriteString(audioPaths[j])
				build.WriteString("\\\\")
			}
			build.WriteString(audioPaths[len(audioPaths)-1])
			finalAudio = build.String()

			imgOutputFolderPaths := strings.Split(imgOutputFolder, "\\")
			var build1 strings.Builder
			for j := 0; j < len(imgOutputFolderPaths)-1; j++ {
				build1.WriteString(imgOutputFolderPaths[j])
				build1.WriteString("\\\\")
			}
			build1.WriteString(imgOutputFolderPaths[len(imgOutputFolderPaths)-1])
			finalImgOutputFolder = build1.String()
		}

		luaCodeList[0] = "_audio_file_path=\"" + finalAudio + "\""
		_, fileName := filepath.Split(audio)
		fileName = strings.TrimSuffix(fileName, filepath.Ext(fileName))
		luaCodeList[1] = "_audio_file_name=\"" + fileName + "\""
		luaCodeList[2] = "_screenshot_output_folder_path=\"" + finalImgOutputFolder + "\""
		// 将新的lua代码输出到一个文件中，执行测试
		execPath, err := os.Executable()
		if err != nil {
			panic("获取执行路径出现错误," + err.Error())
		}
		finalLuaCaseFile, err := os.CreateTemp(path.Dir(execPath), "*.lua")
		if err != nil {
			panic("无法创建临时文件," + err.Error())
		}
		//fmt.Println(finalLuaCaseFile.Name())
		var finalLuaCase string
		for _, s := range luaCodeList {
			if globalVariable.CurrentOS == "windows" {
				finalLuaCase = finalLuaCase + s + "\r\n"

			} else {
				finalLuaCase = finalLuaCase + s + "\n"

			}
		}
		_, err = io.WriteString(finalLuaCaseFile, finalLuaCase)
		if err != nil {
			panic(err)
		}

		args := []string{"-cmd", "start", "-case", finalLuaCaseFile.Name(), "-mergeImg", strconv.FormatBool(mergeImg)}
		cmd := exec.Command(execPath, args...)
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr
		_ = cmd.Run()
		_ = finalLuaCaseFile.Close()
		_ = os.RemoveAll(finalLuaCaseFile.Name())
	}
	profitReport.FinishTime = time.Now()
	_ = PostProfitReport(profitReport)
}

func initDevice(sn string, sns [][]string) {
	var err error
	if sn == "" {
		sn0 := sns[0][0]
		device, err = locationUtil.InitDevice(sn0)
		if err != nil {
			panic(err)
		}
	} else {
		device, err = locationUtil.InitDevice(sn)
		if err != nil {
			panic(err)
		}
	}
}

func execLuaCode(L *lua.LState, caseManageId int) {
	if caseFileName != "" {
		if err := L.DoFile(caseFileName); err != nil {
			panic(err)
		}
	} else if caseManageId != -1 {
		luaScript, err := DownloadTestCaseLuaScript(caseManageId)
		if err != nil {
			panic(err)
		}
		if err := L.DoString(luaScript); err != nil {
			panic(err)
		}
	}
}

func registerLuaFunctions(L *lua.LState, product Product) {
	// 点击ocr识别到的文字
	L.SetGlobal("click", L.NewFunction(product.Click))
	// 点击屏幕原始坐标
	L.SetGlobal("click_xy", L.NewFunction(product.ClickCoordinate))
	// 点击屏幕画面截图上的坐标
	L.SetGlobal("click_screen_xy", L.NewFunction(product.ClickScreenCoordinate))
	// 点击模板匹配的图片
	L.SetGlobal("click_img", L.NewFunction(product.ClickImg))
	// 点击电源按钮
	L.SetGlobal("click_power", L.NewFunction(product.ClickPowerBtn))
	// 点击语音助手按钮
	L.SetGlobal("click_soundhelper", L.NewFunction(product.ClickSoundHelperBtn))

	// 滑动半个屏幕
	L.SetGlobal("slip", L.NewFunction(product.SlipHalfScreen))
	// 按屏幕原始坐标滑动
	L.SetGlobal("slip_xy", L.NewFunction(product.SlipFromToCoordinate))
	// 按屏幕画面截图坐标滑动
	L.SetGlobal("slip_screen_xy", L.NewFunction(product.SlipFromToScreenCoordinate))
	L.SetGlobal("slip_dropdownmenu", L.NewFunction(product.SlipDropDownMenu))

	L.SetGlobal("wait", L.NewFunction(product.SleepForSecond))
	L.SetGlobal("check", L.NewFunction(product.CheckContain))
	L.SetGlobal("check_img", L.NewFunction(product.CheckImg))

	L.SetGlobal("gohome", L.NewFunction(product.GoHome))

	L.SetGlobal("log", L.NewFunction(product.LogInfo))
	L.SetGlobal("print", L.NewFunction(product.Print))

	L.SetGlobal("click_physical_buttons", L.NewFunction(product.ClickPhysicalButton))
	L.SetGlobal("play_mp3", L.NewFunction(product.PlayMp3))
	L.SetGlobal("screen_shot", L.NewFunction(product.ScreenShot))
	L.SetGlobal("is_screen_changed", L.NewFunction(IsScreenChanged))
	L.SetGlobal("set_last_screen_shot", L.NewFunction(SetLastScreenShot))
	L.SetGlobal("save_base64_img", L.NewFunction(saveBase64Img))
}
func saveBase64Img(L *lua.LState) int {
	name := L.CheckString(1)
	b, err := base64.StdEncoding.DecodeString(L.CheckString(2))
	if err != nil {
		panic(err)
	}
	err = ioutil.WriteFile(name, b, 0644)
	if err != nil {
		panic(err)
	}
	return 0
}
func batchDownloadCases(testGroupId int) error {
	type testCaseGroupStruct struct {
		ID                      int         `json:"id"`
		Name                    string      `json:"name"`
		ExecuteCaseManagementID string      `json:"execute_caseManagementId"`
		ExecuteTime             interface{} `json:"execute_time"`
		ExecuteHistory          string      `json:"execute_history"`
		CurrentExecuteOrder     int         `json:"current_execute_order"`
	}
	testCaseGroupUrl := `https://hwp-backend.inner.youdao.com/api/uiautomation/test_execute_group/` + strconv.Itoa(testGroupId) + `/`
	getTestCaseGroupClient := http.Client{Timeout: time.Second * 2}
	testCaseGroupReq, err := http.NewRequest(http.MethodGet, testCaseGroupUrl, nil)
	if err != nil {
		panic(err)
	}
	testCaseGroupRes, err := getTestCaseGroupClient.Do(testCaseGroupReq)
	if err != nil {
		panic(err)
	}
	defer testCaseGroupRes.Body.Close()
	if err != nil {
		panic(err)
	}
	caseDetailBody, err := ioutil.ReadAll(testCaseGroupRes.Body)
	if err != nil {
		panic(err)
	}
	var testCaseGroupJSON testCaseGroupStruct
	err = json.Unmarshal(caseDetailBody, &testCaseGroupJSON)
	if err != nil {
		panic(err)
	}
	fmt.Println(testCaseGroupJSON)

	ids := testCaseGroupJSON.ExecuteCaseManagementID

	// 已经获取到了所有的case id
	var cases []int
	err = json.Unmarshal([]byte(ids), &cases)
	if err != nil {
		panic(err)
	}

	tempDir, err := os.MkdirTemp("", "uiAutoTestCasesGroup")
	defer os.RemoveAll(tempDir)
	if err != nil {
		return err
	}
	err = os.WriteFile(tempDir+string(os.PathSeparator)+"caseRank.json", []byte(ids), 0777)
	if err != nil {
		return err
	}
	for _, caseId := range cases {
		err = singleDownloadCase(caseId, tempDir)
		if err != nil {
			fmt.Println("用例 " + strconv.Itoa(caseId) + "下载失败")
		}
	}

	// 保存到tar.gz压缩文件中
	tarCompress := func(src, dst string) (err error) {
		// 创建文件
		fw, err := os.Create(dst)
		if err != nil {
			return
		}
		defer fw.Close()

		// 将 tar 包使用 gzip 压缩，其实添加压缩功能很简单，
		// 只需要在 fw 和 tw 之前加上一层压缩就行了，和 Linux 的管道的感觉类似
		gw := gzip.NewWriter(fw)
		defer gw.Close()

		// 创建 Tar.Writer 结构
		tw := tar.NewWriter(gw)
		// 如果需要启用 gzip 将上面代码注释，换成下面的

		defer tw.Close()

		// 下面就该开始处理数据了，这里的思路就是递归处理目录及目录下的所有文件和目录
		// 这里可以自己写个递归来处理，不过 Golang 提供了 filepath.Walk 函数，可以很方便的做这个事情
		// 直接将这个函数的处理结果返回就行，需要传给它一个源文件或目录，它就可以自己去处理
		// 我们就只需要去实现我们自己的 打包逻辑即可，不需要再去路径相关的事情
		return filepath.Walk(src, func(fileName string, fi os.FileInfo, err error) error {
			// 因为这个闭包会返回个 error ，所以先要处理一下这个
			if err != nil {
				return err
			}

			// 这里就不需要我们自己再 os.Stat 了，它已经做好了，我们直接使用 fi 即可
			hdr, err := tar.FileInfoHeader(fi, "")
			if err != nil {
				return err
			}
			// 这里需要处理下 hdr 中的 Name，因为默认文件的名字是不带路径的，
			// 打包之后所有文件就会堆在一起，这样就破坏了原本的目录结果
			// 例如： 将原本 hdr.Name 的 syslog 替换程 log/syslog
			// 这个其实也很简单，回调函数的 fileName 字段给我们返回来的就是完整路径的 log/syslog
			// strings.TrimPrefix 将 fileName 的最左侧的 / 去掉，
			// 熟悉 Linux 的都知道为什么要去掉这个
			//hdr.Name = strings.TrimPrefix(fileName, string(filepath.Separator))

			// 判断下文件是否是标准文件，如果不是就不处理了，
			// 如： 目录，这里就只记录了文件信息，不会执行下面的 copy
			if !fi.Mode().IsRegular() {
				return nil
			}
			// 写入文件信息
			if err := tw.WriteHeader(hdr); err != nil {
				return err
			}

			// 打开文件
			fr, err := os.Open(fileName)
			defer fr.Close()
			if err != nil {
				return err
			}

			// copy 文件数据到 tw
			_, err = io.Copy(tw, fr)
			if err != nil {
				return err
			}

			// 记录下过程，这个可以不记录，这个看需要，这样可以看到打包的过程
			//log.Printf("成功打包 %s ，共写入了 %d 字节的数据\n", fileName, n)

			return nil
		})
	}
	var dst = fmt.Sprintf("%s.tar.gz", outputFolder+string(os.PathSeparator)+testCaseGroupJSON.Name)

	// 将步骤写入了一个函数中，这样处理错误方便一些
	err = tarCompress(tempDir, dst)
	return err
}

func singleDownloadCase(caseId int, tempDir string) error {
	log.Println("正在下载用例：" + strconv.Itoa(caseId))
	// 下载用例
	src, err := DownloadTestCaseLuaScript(caseId)
	if err != nil {
		return err
	}
	// 把用例写入文件
	err = os.WriteFile(tempDir+string(os.PathSeparator)+strconv.Itoa(caseId)+".lua", []byte(src), 0777)
	if err != nil {
		return err
	}
	// 下载用例中的所有图片
	// ".*\.png"
	// 1.从用例中获取所有的图片的名字
	// 2.下载这些图片
	reg, err := regexp.Compile("\".*\\.png\"")
	if err != nil {
		return err
	}
	imgs := reg.FindAllString(src, -1)
	log.Println("正在下载用例图片：")
	for _, img := range imgs {
		imgStr := img[1 : len(img)-1]
		teplDownloadUrl := `https://hwp-static.inner.youdao.com/hwp/uiautomatic_template_img/` + imgStr
		fmt.Printf("%s ", imgStr)
		// 下载图片
		func() { // Get the Data
			resp, err := http.Get(teplDownloadUrl)
			if err != nil {
				panic(err)
			}
			defer resp.Body.Close()

			// 创建一个文件用于保存
			out, err := os.Create(tempDir + string(os.PathSeparator) + imgStr)
			if err != nil {
				panic(err)
			}
			defer out.Close()

			// 然后将响应流和文件流对接起来
			_, err = io.Copy(out, resp.Body)
			if err != nil {
				panic(err)
			}
		}()
	}
	log.Println("\n用例 " + strconv.Itoa(caseId) + " 下载完成！")
	return nil
}
