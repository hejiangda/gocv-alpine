package main

import (
	"flag"
	"fmt"
	"log"
	"math"
	"os/exec"
	"runtime"
	"strconv"
)

const VERSION = "v1.0.0"

func main() {
	var x1 int
	var y1 int
	var x2 int
	var y2 int
	var interval int
	var arch string
	flag.IntVar(&x1, "x1", 0, "第一个点的x坐标")
	flag.IntVar(&y1, "y1", 0, "第一个点的y坐标")
	flag.IntVar(&x2, "x2", 0, "第二个点的x坐标")
	flag.IntVar(&y2, "y2", 0, "第二个点的y坐标")
	flag.IntVar(&interval, "interval", 3, "滑动间隔")
	flag.StringVar(&arch, "arch", "arm64", "设备构架 3566为arm64 coco为arm32")
	flag.Parse()
	log.Print("x1:", x1, "y1:", y1, "x2:", x2, "y2:", y2)
	remainCmd := flag.Arg(0)
	if remainCmd == "version" {
		fmt.Println(VERSION)
		return
	}
	var sendEventCmd string
	arch1 := runtime.GOARCH
	if arch1 == "arm" {
		arch = "arm32"
	}
	switch arch {
	case "arm64":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64"
	case "arm32":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32"
		interval -= 2
		if interval < 1 {
			interval = 1
		}
	}

	cmd := exec.Command(sendEventCmd, "-obj", "touch", "-action", "press", "-x", strconv.Itoa(x1), "-y", strconv.Itoa(y1))
	_, err := cmd.Output()
	if err != nil {
		panic(err)
	}
	nx := int(math.Abs(float64(x2-x1)) / float64(interval))
	ny := int(math.Abs(float64(y2-y1)) / float64(interval))
	i := 0
	for i = 0; i < nx && i < ny; i++ {
		cmd = exec.Command(sendEventCmd, "-obj", "touch", "-action", "slip", "-x", strconv.Itoa(((x2-x1)/nx)*i+x1), "-y", strconv.Itoa(((y2-y1)/ny)*i+y1))
		_, err = cmd.Output()
		if err != nil {
			panic(err)
		}
	}
	for ; i < nx; i++ {
		cmd = exec.Command(sendEventCmd, "-obj", "touch", "-action", "slip", "-x", strconv.Itoa(((x2-x1)/nx)*i+x1), "-y", strconv.Itoa(y2))
		_, err = cmd.Output()
		if err != nil {
			panic(err)
		}
	}
	for ; i < ny; i++ {
		cmd = exec.Command(sendEventCmd, "-obj", "touch", "-action", "slip", "-x", strconv.Itoa(x2), "-y", strconv.Itoa(((y2-y1)/ny)*i+y1))
		_, err = cmd.Output()
		if err != nil {
			panic(err)
		}
	}
	cmd = exec.Command(sendEventCmd, "-obj", "touch", "-action", "slip", "-x", strconv.Itoa(x2), "-y", strconv.Itoa(y2))
	_, err = cmd.Output()
	if err != nil {
		panic(err)
	}
	cmd = exec.Command(sendEventCmd, "-obj", "touch", "-action", "onlyRelease")
	_, err = cmd.Output()
	if err != nil {
		panic(err)
	}
	return
}
