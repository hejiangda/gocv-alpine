//go:build linux || darwin
// +build linux darwin

package main

//
//func (s *server) MinusClientCnt(context.Context, *emptypb.Empty) (*emptypb.Empty, error) {
//	clientCnt--
//	log.Println("minus client,cnt:", clientCnt)
//
//	if clientCnt <= 0 {
//		_ = unix.Kill(os.Getpid(), unix.SIGTERM)
//		//for err != nil {
//		//	err = unix.Kill(os.Getpid(), unix.SIGTERM)
//		//}
//	}
//
//	return &emptypb.Empty{}, nil
//}
