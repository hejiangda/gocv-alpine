package main

/*
#include "new_send_event_c.h"
*/
import "C"
import (
	"flag"
	"fmt"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"math/rand"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"strings"
	"time"
)

const VERSION = "v1.0.0"

/*
听力宝各按键位置：

|按键名|输入事件|事件类型|事件code|
|-|-|-|-|
|音量下|/dev/input/event4:	gpio-keys |type 1 (EV_KEY)|code 114 (KEY_VOLUMEDOWN)|
|音量上|/dev/input/event4:	gpio-keys|type 1 (EV_KEY)|code 207 (KEY_PLAY)|
|前进|/dev/input/event3:	adc-keys|type 1 (EV_KEY)|code 159 (KEY_FORWARD)|
|后退|/dev/input/event3:	adc-keys|type 1 (EV_KEY)|code 158 (KEY_BACK)|
|播放/停止|/dev/input/event3:	adc-keys|type 1 (EV_KEY)|code 115 (KEY_VOLUMEUP)|
|主菜单|/dev/input/event3:	adc-keys|type 1 (EV_KEY)|code 139 (KEY_MENU)|
|屏幕亮灭|/dev/input/event5:	fake-keys|type 1 (EV_KEY)| code 152 (KEY_SCREENLOCK)|
|电源按键|/dev/input/event1:  rk8xx_pwrkey|type 1 (EV_KEY)| code 116 (KEY_POWER)|

词典笔3566、3326各按键

|按键名|输入事件|事件类型|事件code|
|-|-|-|-|
|主菜单|/dev/input/event2:	adc-keys|type 1 (EV_KEY)|code 115 (KEY_VOLUMEUP)|
|扫描灯|/dev/input/event3:	led_control|type 1 (EV_KEY)|code 134 (KEY_OPEN)|
|屏幕亮灭|/dev/input/event4:	fake-keys|type 1 (EV_KEY)|code 152 (KEY_SCREENLOCK)|
|电源按键|/dev/input/event1:  rk8xx_pwrkey|type 1 (EV_KEY)| code 116 (KEY_POWER)|


词典笔coco各按键

|按键名|输入事件|事件类型|事件code|
|-|-|-|-|
|电源按键|/dev/input/event1:	axp2101-pek|type 1 (EV_KEY)|code 116 (KEY_POWER)|
|主菜单|/dev/input/event2:	gpio-keys|type 1 (EV_KEY)|code 139 (KEY_MENU)|
|扫描灯|/dev/input/event3:	led_control|type 1 (EV_KEY)| code 134 (KEY_OPEN)|
*/

/*
go版send_event设计思路：
1. 通过SN号来区分不同的设备
2. 封装各种操作的按键
3.
*/
var obj, action string
var x, y int

const (
	KEY_VOLUMEDOWN = 114
	KEY_PLAY       = 207
	KEY_FORWARD    = 159
	KEY_BACK       = 158
	KEY_VOLUMEUP   = 115
	KEY_MENU       = 139
	KEY_SCREENLOCK = 152
	KEY_POWER      = 116
	KEY_OPEN       = 134

	PRESS   = 1
	RELEASE = 0

	EV_KEY = 1
	EV_ABS = 3

	ABS_MT_POSITION_X  = 53
	ABS_MT_POSITION_Y  = 54
	ABS_MT_TRACKING_ID = 57

	BTN_TOUCH = 330
)

func main() {
	flag.StringVar(&obj, "obj", "", `执行的命令的对象:
	coco:power,menu,led,touch
	dictpen/dictpen2:power,menu,led,screen,touch
	apollo:power,menu,sound_up,sound_down,forward,back,play,screen,touch`)
	flag.IntVar(&x, "x", 0, "x坐标")
	flag.IntVar(&y, "y", 0, "y坐标")
	flag.StringVar(&action, "action", "", `要执行的操作:
	press,release,slip`)
	flag.Parse()

	remainCmd := flag.Arg(0)
	if remainCmd == "version" {
		fmt.Println(VERSION)
		return
	}

	var deviceSn globalVariable.SN
	deviceSn.Data = os.Getenv("SN")
	prodStr, _ := deviceSn.GetProductSerial()
	arch := runtime.GOARCH
	if arch == "arm" {
		prodStr = "coco"
	}

	rand.Seed(time.Now().Unix())

	//ready := os.Getenv("ui_automation_event_ready")
	mp := make(map[string]string)

	// 1. 获取输入设备信息
	inputEvent := exec.Command("cat", "/proc/bus/input/devices")
	msg, _ := inputEvent.Output()

	ret := strings.Split(string(msg), "\n")

	// 2. 解析获取到的输入设备数据，然后存入map中
	nameReg := regexp.MustCompile(`".*"`)
	handlerReg := regexp.MustCompile(`event[0-9]*`)
	lastName := ""
	for _, s := range ret {
		if len(s) > 0 {
			if s[0] == 'N' {
				tmp := nameReg.FindString(s)
				tmpName := tmp[1 : len(tmp)-1]
				if lastName == "" {
					lastName = tmpName
				}
			}
			if s[0] == 'H' {
				handler := handlerReg.FindString(s)
				if lastName != "" {
					mp[lastName] = handler
					lastName = ""
				}
			}
		}
	}

	switch prodStr {
	case "coco":
		switch obj {
		case "power":
			event := "/dev/input/" + mp["axp2101-pek"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_POWER, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_POWER, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "menu":
			event := "/dev/input/" + mp["gpio-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_MENU, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_MENU, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "led":
			event := "/dev/input/" + mp["led_control"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_OPEN, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_OPEN, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "touch":
			event := "/dev/input/" + mp["SITRONIX"]
			SendTouchEvents(event)
		default:
			panic("不支持的对象:" + obj)
		}
	case "dictpen2":
		// 二代笔暂时不支持
		fallthrough
	case "dictpen":
		switch obj {
		case "power":
			event := "/dev/input/" + mp["rk8xx_pwrkey"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_POWER, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_POWER, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "menu":
			event := "/dev/input/" + mp["adc-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_VOLUMEUP, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_VOLUMEUP, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "led":
			event := "/dev/input/" + mp["led_control"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_OPEN, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_OPEN, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "screen":
			event := "/dev/input/" + mp["fake-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_SCREENLOCK, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_SCREENLOCK, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "touch":
			_, ok := mp["chipone-ts"]
			var event string
			if ok {
				event = "/dev/input/" + mp["chipone-ts"]
			} else {
				event = "/dev/input/" + mp["SITRONIX"]
			}
			SendTouchEvents(event)
			break
		default:
			panic("不支持的对象:" + obj)
		}
	case "apollo":
		switch obj {
		case "power":
			event := "/dev/input/" + mp["rk8xx_pwrkey"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_POWER, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_POWER, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "menu":
			event := "/dev/input/" + mp["adc-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_MENU, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_MENU, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "sound_up":
			event := "/dev/input/" + mp["gpio-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_PLAY, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_PLAY, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "sound_down":
			event := "/dev/input/" + mp["gpio-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_VOLUMEDOWN, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_VOLUMEDOWN, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "forward":
			event := "/dev/input/" + mp["adc-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_FORWARD, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_FORWARD, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "back":
			event := "/dev/input/" + mp["adc-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_BACK, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_BACK, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "play":
			event := "/dev/input/" + mp["adc-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_VOLUMEUP, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_VOLUMEUP, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "screen":
			event := "/dev/input/" + mp["fake-keys"]
			switch action {
			case "press":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_SCREENLOCK, PRESS)
			case "release":
				C.SendOriginEvent(C.CString(event), EV_KEY, KEY_SCREENLOCK, RELEASE)
			default:
				panic("不支持的操作:" + action)
			}
		case "touch":
			event := "/dev/input/" + mp["sec_touchscreen"]
			SendTouchEvents(event)
		default:
			panic("不支持的对象:" + obj)
		}
	}
}

func SendTouchEvents(event string) {
	switch action {
	case "press":
		evTypes := []C.int{EV_ABS, EV_ABS, EV_ABS, EV_KEY}
		evCodes := []C.int{ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_TRACKING_ID, BTN_TOUCH}
		evValues := []C.int{C.int(x), C.int(y), 1, PRESS}
		//evTypes := []C.int{EV_ABS, EV_ABS, EV_KEY}
		//evCodes := []C.int{ABS_MT_POSITION_X, ABS_MT_POSITION_Y, BTN_TOUCH}
		//evValues := []C.int{C.int(x), C.int(y), PRESS}
		C.SendMultiEvent(C.CString(event), &evTypes[0], &evCodes[0], &evValues[0], C.int(len(evTypes)))
	case "release":
		evTypes := []C.int{EV_ABS, EV_ABS, EV_ABS, EV_KEY}
		evCodes := []C.int{ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_TRACKING_ID, BTN_TOUCH}
		evValues := []C.int{C.int(x), C.int(y), -1, RELEASE}
		//evTypes := []C.int{EV_ABS, EV_KEY}
		//evCodes := []C.int{ABS_MT_TRACKING_ID, BTN_TOUCH}
		//evValues := []C.int{-1, RELEASE}
		C.SendMultiEvent(C.CString(event), &evTypes[0], &evCodes[0], &evValues[0], C.int(len(evTypes)))
	case "slip":
		evTypes := []C.int{EV_ABS, EV_ABS}
		evCodes := []C.int{ABS_MT_POSITION_X, ABS_MT_POSITION_Y}
		evValues := []C.int{C.int(x), C.int(y)}
		C.SendMultiEvent(C.CString(event), &evTypes[0], &evCodes[0], &evValues[0], C.int(len(evTypes)))
	case "onlyRelease":
		evTypes := []C.int{EV_ABS, EV_KEY}
		evCodes := []C.int{ABS_MT_TRACKING_ID, BTN_TOUCH}
		evValues := []C.int{-1, RELEASE}
		C.SendMultiEvent(C.CString(event), &evTypes[0], &evCodes[0], &evValues[0], C.int(len(evTypes)))
	default:
		panic("不支持的操作:" + action)
	}
}
