#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <linux/input.h>

// 单个简单输入事件
int SendOriginEvent(char* inputEvent,int type , int code, int value){
    // 创建一个输入事件的结构体
	struct input_event event;
	// 清零
    memset(&event, 0, sizeof(struct input_event));
	// 事件类型
	event.type = type;
	// 事件码
	event.code = code;
	// 事件值
	event.value = value;
	// 打开输入事件设备
	int fd = open(inputEvent, O_RDWR | O_NDELAY);
	if (fd != -1)
	{
	    // 向输入设备发送事件，要写两次
        if (write(fd, &event, sizeof(struct input_event)) < 0)
        {
            printf("send_event error\n");
            close(fd);
            return -1;
        }
		event.type = EV_SYN;
		event.code = SYN_REPORT;
		event.value = 0;
		if (write(fd, &event, sizeof(struct input_event)) < 0)
		{
			printf("send_event error\n");
			close(fd);
			return -1;
		}
		close(fd);
	} else
    {
        printf("input dev %s open failed[%s]\n", inputEvent, strerror(errno));
        return -1;
    }
}
// 多个事件
int SendMultiEvent(char* inputEvent,int type[] , int code[], int value[],int len){
    // 创建一个输入事件的结构体
	struct input_event event;
	// 清零
    memset(&event, 0, sizeof(struct input_event));
	// 打开输入事件设备
	int fd = open(inputEvent, O_RDWR | O_NDELAY);
	if (fd != -1)
	{
	    // 向输入设备发送事件，要写两次
	    int i=0;
	    for(i=0;i<len;i++){
            // 清零
            memset(&event, 0, sizeof(struct input_event));
            // 事件类型
            event.type = type[i];
            // 事件码
            event.code = code[i];
            // 事件值
            event.value = value[i];
            if (write(fd, &event, sizeof(struct input_event)) < 0)
            {
                printf("send_event error\n");
                close(fd);
                return -1;
            }
        }
        // 同步
		event.type = EV_SYN;
		event.code = SYN_REPORT;
		event.value = 0;
		if (write(fd, &event, sizeof(struct input_event)) < 0)
		{
			printf("send_event error\n");
			close(fd);
			return -1;
		}
		close(fd);
	} else
    {
        printf("input dev %s open failed[%s]\n", inputEvent, strerror(errno));
        return -1;
    }
}
