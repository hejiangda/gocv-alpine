#define _GNU_SOURCE /* for asprintf */
#include <stdio.h>
#include <stdint.h>

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <linux/input.h>

#include <dirent.h>

//#define BITS_PER_LONG (sizeof(long) * 8)
//#define NBITS(x) ((((x)-1) / BITS_PER_LONG) + 1)
//#define OFF(x) ((x) % BITS_PER_LONG)
//#define BIT(x) (1UL << OFF(x))
//#define LONG(x) ((x) / BITS_PER_LONG)
//#define test_bit(bit, array) ((array[LONG(bit)] >> OFF(bit)) & 1)

//#define DEV_INPUT_EVENT "/dev/input"
//#define EVENT_DEV_NAME "event"


// deviceType: 1. 3566 2.coco 3. apollo
int SendEvent(int argc, char **argv,int deviceType,char *eventIdStr)
{
	int rc;
	int i;
	char event_dev[32];
	struct input_event event[4];
	int position_x = 0, position_y = 0;
	int event_cnt = 0;
	memset(&event, 0, sizeof(struct input_event) * 4);

	if (argc != 3 && argc != 5 )
	{
		printf("used : %s button_name action [x] [y]\n", argv[0]);
		printf("\t button_name : camera/asr/menu/touch/screen_off/rk8xx_pwrkey/power\n");
		printf("\t action : press/release/slip\n");
		printf("\t x y :point x,y \n");

		return -1;
	}

	for (i = 0; i < 4; i++)
	{
		gettimeofday(&event[i].time, NULL);
	}

	if (strcmp(argv[1], "camera") == 0)
	{
		sprintf(event_dev, "/dev/input/%s", eventIdStr);
		event[0].type = EV_KEY;
		event[0].code = 134;
		event_cnt = 1;
	}
	else if (strcmp(argv[1], "asr") == 0)
	{
	    if(deviceType!=2){
            sprintf(event_dev, "/dev/input/%s", eventIdStr);
            event[0].type = EV_KEY;
            event[0].code = 115;
            event_cnt = 1;
	    }else{
            sprintf(event_dev, "/dev/input/%s", eventIdStr);
            event[0].type = EV_KEY;
            event[0].code = 139;
            event_cnt = 1;
	    }
	}
	else if (strcmp(argv[1], "menu") == 0)
	{
	    if(deviceType!=2){
            sprintf(event_dev, "/dev/input/%s", eventIdStr);
            event[0].type = EV_KEY;
            event[0].code = 115;
            event_cnt = 1;
	    }else{
            sprintf(event_dev, "/dev/input/%s", eventIdStr);
            event[0].type = EV_KEY;
            event[0].code = 139;
            event_cnt = 1;
	    }
	}
	else if (strcmp(argv[1], "touch") == 0)
	{
		sprintf(event_dev, "/dev/input/%s", eventIdStr);
		event[0].type = EV_ABS;
		event[0].code = 53;
		event[1].type = EV_ABS;
		event[1].code = 54;
		event[2].type = EV_ABS;
		event[2].code = 57;
		event[3].type = EV_KEY;
		event[3].code = 330;
		event_cnt = 4;
	}
	else if (strcmp(argv[1], "screen_off") == 0)
	{
		sprintf(event_dev, "/dev/input/%s", eventIdStr);
		event[0].type = EV_KEY;
		event[0].code = 152;
		event_cnt = 1;
	}
	else if (strcmp(argv[1], "bt_connect") == 0)
	{
		sprintf(event_dev, "/dev/input/%s", eventIdStr);
		event[0].type = EV_KEY;
		event[0].code = 199;
		event_cnt = 1;
	}
	else if (strcmp(argv[1], "power") == 0)
	{
		sprintf(event_dev, "/dev/input/%s", eventIdStr);
		event[0].type = EV_KEY;
		event[0].code = 116;
		event_cnt = 1;
	}
	else
	{
		printf("unkown button %s\n", argv[1]);
		return -1;
	}

	if (argc == 5)
	{
		position_x = atoi(argv[3]);
		position_y = atoi(argv[4]);
	}

	if (strcmp(argv[2], "press") == 0)
	{
		if (strcmp(argv[1], "touch") == 0)
		{
			event[0].value = position_x;
			event[1].value = position_y;
			event[2].value = 0;
			event[3].value = 1;
		}
		else
		{
			event[0].value = 1;
		}
	}
	else if (strcmp(argv[2], "release") == 0)
	{
		if (strcmp(argv[1], "touch") == 0)
		{
			event[0].value = position_x;
			event[1].value = position_y;
			event[2].value = -1;
			event[3].value = 0;
		}
		else
		{
			event[event_cnt - 1].value = 0;
		}
	}
	else if (strcmp(argv[2], "slip") == 0)
	{
		if (strcmp(argv[1], "touch") == 0)
		{
			event[0].value = position_x;
			event[1].value = position_y;
			event_cnt = 2;
		}
	}
	else
	{
		printf("unkown action = %s\n", argv[2]);
		return -1;
	}

	int fd = open(event_dev, O_RDWR | O_NDELAY);
	if (fd != -1)
	{
		for (i = 0; i < event_cnt; i++)
		{
			if (write(fd, &event[i], sizeof(struct input_event)) < 0)
			{
				printf("send_event error\n");
				close(fd);
				return -1;
			}
		}
		event[0].type = EV_SYN;
		event[0].code = SYN_REPORT;
		event[0].value = 0;
		if (write(fd, &event[0], sizeof(struct input_event)) < 0)
		{
			printf("send_event error\n");
			close(fd);
			return -1;
		}
		close(fd);
	}
	else
	{
		printf("input dev %s open failed[%s]\n", event_dev, strerror(errno));
		return -1;
	}

	return 0;
}
