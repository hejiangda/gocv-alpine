#include <stdio.h>

void PrintTest(char **str){
    int i=0;
    for (i=0;i<2;i++){
        printf("%s\n",str[i]);
    }
}
