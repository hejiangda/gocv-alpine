#!/bin/sh
/usr/bin/vendor_storage -r VENDOR_CUSTOM_ID_0E -t string | tr -s ' ' | cut -d ' ' -f 2 | tr -d '\r\n'
