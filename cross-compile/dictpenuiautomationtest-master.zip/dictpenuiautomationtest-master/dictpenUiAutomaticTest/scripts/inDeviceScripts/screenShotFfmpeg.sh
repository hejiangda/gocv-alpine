#!/bin/sh
ffmpeg -loglevel quiet -f kmsgrab -i - -vf 'hwdownload,format=bgr0' -framerate 60 -frames:v 1 -c:v png -f image2pipe - | base64
