#!/bin/sh
cat /Version | tail -n 1  |tr -s ' ' |cut -d ' ' -f 2 | tr -d '\\r\\n'
