#!/bin/sh
ps|grep input-event |grep -v grep |head -n 1 |awk '{printf $1}' |xargs -t kill -USR2
