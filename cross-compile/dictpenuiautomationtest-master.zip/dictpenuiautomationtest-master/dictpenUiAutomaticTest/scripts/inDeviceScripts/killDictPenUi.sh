#!/bin/sh
ps|grep 'YoudaoDictPen -platform wayland' |grep -v grep |head -n 1 |awk '{printf $1}' |xargs -t kill -9
