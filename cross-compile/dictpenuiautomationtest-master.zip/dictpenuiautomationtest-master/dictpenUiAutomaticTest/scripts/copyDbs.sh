#!/bin/sh
# auth: 何江达

# 开启可执行权限
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/32bit/clickPhysicsButtonExecutableArm32
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/32bit/ffmpeg
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/32bit/slipExecutableArm32
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/slipExecutableArm64
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/clickPhysicsButtonExecutableArm64

# 复制数据库到词典笔
cp /userdisk/dictpenUiAutomaticTest/scripts/databases/wordbook.db /userdisk/database/wordbook.db
cp /userdisk/dictpenUiAutomaticTest/scripts/databases/history.db /userdisk/database/history.db
cp /userdisk/dictpenUiAutomaticTest/scripts/databases/calculateFavorite.db  /userdisk/math/calculateFav/calculateFavorite.db

# 复制写作指导的历史数据
cp -r /userdisk/dictpenUiAutomaticTest/scripts/articles/ /userdisk/
