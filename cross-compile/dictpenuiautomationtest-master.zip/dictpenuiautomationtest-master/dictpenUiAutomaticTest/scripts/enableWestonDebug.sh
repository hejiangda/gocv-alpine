#!/bin/sh
mount -o remount r,w /
chmod +x /userdisk/dictpenUiAutomaticTest/scripts/S99adb-start-cherry
cp /userdisk/dictpenUiAutomaticTest/scripts/S99adb-start-cherry /etc/init.d/
#sed -i 's/weston --tty=2 -B=drm-backend.so --idle-time=0&/weston --tty=2 -B=drm-backend.so --idle-time=0 --debug \&/' /etc/init.d/S50launcher
#reboot
