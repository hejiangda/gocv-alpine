#!/bin/sh
# author: 何江达
# 实现硬件设备上的各种触摸操作包括：
# 点击、滑动、亮屏

# 从坐标1滑到坐标2
# $1 $2 坐标1 x,y
# $3 $4 坐标2 x,y

#arch=$(uname -m)
#echo "$arch"

slip_from_to(){
  wake_screen
	$sendEvent -obj touch -action press -x "$1"  -y "$2"
	$sendEvent -obj touch -action slip -x "$3" - y"$4"
	$sendEvent -obj touch -action release -x "$3" - y"$4"
}

# 点击坐标
# $1 $2 坐标 x,y
click(){
  wake_screen
  $sendEvent -obj touch -action press -x 0 -y 0
  $sendEvent -obj touch -action onlyRelease
  $sendEvent -obj touch -action press -x "$1" -y "$2"
  $sendEvent -obj touch -action onlyRelease
}

# 点亮屏幕
do_screen_on()
{
  screen_switch on
  $sendEvent -obj screen -action release
  sleep 1
}

# 只有在屏幕不亮的时候才点亮
wake_screen(){
  if [ -f /tmp/brightness ]
  then
    brightness="$(cat /tmp/brightness)"
    echo "${brightness}"  > /sys/class/backlight/backlight/brightness
  fi
  if [ -f /tmp/screen_status ]
  then
    #change flag
    if [ "switch_off" = "$(cat /tmp/screen_status)" ]
    then
      echo off > /tmp/screen_status
    fi
    if [ "off" = "$(cat /tmp/screen_status)" ]
    then
      do_screen_on
      rm /tmp/screen_status -f
    fi
  fi
}

case "$1" in
"arm32")
sendEvent="/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32"
;;
"arm64")
sendEvent="/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64"
;;
*)
esac

case "$2" in
"slip")
  slip_from_to "$3" "$4" "$5" "$6"
;;
"click")
  click "$3" "$4" > /dev/null 2>&1
;;
"wake")
  wake_screen > /dev/null 2>&1
;;
*)
  echo "please use click x y or slip x1 y1 x2 y2 to use this script"
esac
