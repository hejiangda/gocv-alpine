#!/bin/sh
# auth: 何江达
# mp3文件到词典笔

cp -r /userdisk/dictpenUiAutomaticTest/scripts/Music/* /userdisk/Music/
