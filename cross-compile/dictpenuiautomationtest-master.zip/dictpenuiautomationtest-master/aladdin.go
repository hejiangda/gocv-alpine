package main

import (
	"encoding/json"
	"fmt"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/aladdin"
	"log"
)

func FetchDeviceInfo(sn string) (err error) {

	apkVersion, err := adbUtil.GetAPKVersion(sn)
	if err != nil {
		return err
	}
	mcuVersion, err := adbUtil.GetMCUVersion(sn)
	if err != nil {
		return err
	}
	wifiStatus, wifiSsid, wifiInternsity := adbUtil.GetWifiInfo(sn)
	info := aladdin.DeviceInfo{
		ApkVersion:    apkVersion,
		McuVersion:    mcuVersion,
		WifiStatus:    wifiStatus,
		WifiSsid:      wifiSsid,
		WifiIntensity: wifiInternsity,
	}
	b, err := json.Marshal(&info)
	if err != nil {
		log.Println("json err:", err)
		panic("json err")
	}
	fmt.Println(string(b))
	return
}
func FetchWifiInfo(sn string) (err error) {
	wifiStatus, wifiSsid, wifiInternsity := adbUtil.GetWifiInfo(sn)
	info := aladdin.DeviceInfo{
		WifiStatus:    wifiStatus,
		WifiSsid:      wifiSsid,
		WifiIntensity: wifiInternsity,
	}
	b, err := json.Marshal(&info)
	if err != nil {
		log.Println("json err:", err)
		panic("json err")
	}
	fmt.Println(string(b))
	return
}
func OpenCloseLight(sn string, lightSwitchVal int) (err error) {
	_, err = adbUtil.OpenCloseLight(sn, lightSwitchVal)
	return err
}
