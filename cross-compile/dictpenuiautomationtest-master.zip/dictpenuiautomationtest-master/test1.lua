screen_shot('hjdtest','testImg')
