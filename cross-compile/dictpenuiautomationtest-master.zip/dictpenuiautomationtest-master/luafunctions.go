package main

import (
	"fmt"
	lua "github.com/yuin/gopher-lua"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/inDevice"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/locationUtil"
	"gocv.io/x/gocv"
	"image"
	"image/color"
	"image/color/palette"
	"image/draw"
	"image/gif"
	"log"
	"math"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
)

var (
	imgSerialCnt      int
	animGif           gif.GIF
	saveScreenShotCnt int
	lastImg           gocv.Mat // 保存上一次执行时的截图
	UnionImg          gocv.Mat
	UnionImgSavePath  string
)

func init() {
	lastImg = gocv.NewMat()
	UnionImg = gocv.NewMat()
}

const animDelay = 50

type Product interface {
	// Click 点击ocr识别到的文字
	Click(L *lua.LState) int
	// ClickCoordinate 点击屏幕原始坐标，只作调试用，不作截图记录
	ClickCoordinate(L *lua.LState) int
	// ClickScreenCoordinate 点击屏幕截图的坐标
	ClickScreenCoordinate(L *lua.LState) int
	// ClickImg 点击识别到的模板图片
	ClickImg(L *lua.LState) int
	// ClickPowerBtn 点击电源按钮
	ClickPowerBtn(L *lua.LState) int
	// ClickSoundHelperBtn 点击语音助手按钮
	ClickSoundHelperBtn(L *lua.LState) int
	// SlipHalfScreen 滑动半个屏幕
	SlipHalfScreen(L *lua.LState) int
	// SlipFromToCoordinate 按设备屏幕原始坐标滑动，只作调试用，不作截图记录
	SlipFromToCoordinate(L *lua.LState) int
	// SlipFromToScreenCoordinate 按屏幕截图上的坐标滑动
	SlipFromToScreenCoordinate(L *lua.LState) int
	// SlipDropDownMenu 下拉菜单
	SlipDropDownMenu(L *lua.LState) int
	// SleepForSecond 睡几秒
	SleepForSecond(L *lua.LState) int
	// CheckContain 检查文字是否存在
	CheckContain(L *lua.LState) int
	// CheckImg 点击识别到的模板图片
	CheckImg(L *lua.LState) int
	// GoHome 回首页
	GoHome(L *lua.LState) int
	// LogInfo 输出带时间戳的文字
	LogInfo(L *lua.LState) int
	// Print 输出带时间戳的文字
	Print(L *lua.LState) int
	ClickPhysicalButton(L *lua.LState) int
	PlayMp3(L *lua.LState) int
	ScreenShot(L *lua.LState) int
}

// unimplemented 还没实现
func unimplemented() int {
	panic("暂时不支持该操作")
}

// incTestStep 执行次数自增，并设置日志输出的前缀
func incTestStep() {
	testStep++
	log.SetPrefix("[" + strconv.Itoa(testStep) + "]")
}

// saveScreenShot 保存截图
func saveScreenShot(img gocv.Mat, message string) (err error) {
	tmpGoImg, err := img.ToImage()
	if err != nil {
		return
	}

	paletted := image.NewPaletted(tmpGoImg.Bounds(), palette.Plan9)
	draw.FloydSteinberg.Draw(paletted, tmpGoImg.Bounds(), tmpGoImg, image.Point{})
	animGif.Delay = append(animGif.Delay, animDelay)
	animGif.Image = append(animGif.Image, paletted)

	if logImgOpenFlag == true {
		// 保存在本地
		if logImgFolder != "" {
			sysType := runtime.GOOS
			imgFilePath := logImgFolder + strconv.Itoa(imgSerialCnt) + ".jpg"
			gocv.IMWriteWithParams(imgFilePath, img, []int{gocv.IMWriteJpegQuality, 50})
			imgSerialCnt++
			if sysType == "windows" {
				imgFilePath = strings.ReplaceAll(imgFilePath, "\\", "/")
				log.Println("  " + message + "\n![alt " + strconv.Itoa(testStep) + "]( file:///" + imgFilePath + " )")
			} else {
				log.Println("  " + message + "\n![alt " + strconv.Itoa(testStep) + "]( file://" + imgFilePath + " )")
			}
		} else {
			// 保存在服务器上
			// 1. 存在本地临时文件夹中
			// 2. 上传到服务器
			// 3. 写到markdown文件中

			// 图片文件在本地的真实路径
			imgFilePath := tempDir + string(os.PathSeparator) + strconv.Itoa(imgSerialCnt) + ".jpg"
			gocv.IMWriteWithParams(imgFilePath, img, []int{gocv.IMWriteJpegQuality, 50})

			// 获取log文件名
			filenameall := path.Base(logFileName)
			filesuffix := path.Ext(logFileName)
			fileprefix := filenameall[0 : len(filenameall)-len(filesuffix)]

			// 以log文件名作为图片的文件夹名
			imgUrl, err := uploadImgFile(minioLocation+"/"+fileprefix, strconv.Itoa(imgSerialCnt)+".jpg", imgFilePath)
			if err != nil {
				log.Println(err)
				return err
			}
			imgSerialCnt++

			log.Println("  " + message + "\n![alt " + strconv.Itoa(testStep) + "](" + imgUrl + ")")
		}
	}
	return
}

// saveScreenShotToFolder 把图片保存到lua脚本中指定的文件夹
func saveScreenShotToFolder(img gocv.Mat, folder, filename string) {
	err := os.MkdirAll(folder, os.ModePerm)
	if err != nil {
		fmt.Println("创建文件夹出错")
		return
	}
	if !mergeImg {
		imgFilePath := folder + string(os.PathSeparator) + filename + "-" + strconv.Itoa(saveScreenShotCnt) + ".jpg"

		imgbuf, err := gocv.IMEncode(".jpg", img)
		f, err := os.Create(imgFilePath)
		_, err = f.Write(imgbuf.GetBytes())
		if err != nil {
			panic("图片保存出错")
		}
		saveScreenShotCnt++
	} else {
		UnionImgSavePath = folder + string(os.PathSeparator) + filename + ".jpg"

		if UnionImg.Empty() {
			UnionImg = img
		} else {
			gocv.Vconcat(UnionImg, img, &UnionImg)
		}
	}

}

// Click 点击ocr识别到的文字
func Click(L *lua.LState) int {
	ltext := L.ToString(1)
	log.Println("开始点击{" + ltext + "}")

	page, err := device.LocateAllElementsByOcr()
	if err != nil {
		panic("  <font size=5 color=red >定位失败{" + ltext + "},err:" + err.Error() + "</font>")
		return 1
	}
	clickPoint, region, err := page.Click(ltext)
	// 点击前的截图记录
	logImgBeforeClick := page.ScreenShot.Clone()
	page.DrawCircle(logImgBeforeClick, clickPoint, color.RGBA{255, 0, 0, 255})
	page.DrawRectangle(logImgBeforeClick, region.GetImageRect(), color.RGBA{R: 255})
	saveScreenShot(logImgBeforeClick, "点击前截图")
	if err != nil {
		panic("  <font size=5 color=red >点击失败{" + ltext + "},err:" + err.Error() + "</font>")
		return 1
	}
	log.Println("  点击成功{" + ltext + "}")
	page, err = device.FetchScreenShot()
	saveScreenShot(page.ScreenShot, "点击后截图")
	L.Push(lua.LBool(true))
	return 1
}

// CheckContain 检查文字是否存在
func CheckContain(L *lua.LState) int {
	ltext := L.ToString(1)
	log.Println("开始检查{" + ltext + "}")
	page, err := device.LocateAllElementsByOcr()
	if err != nil {
		log.Println("  检查失败{"+ltext+"},err:", err)
		L.Push(lua.LBool(false))
		return 1
	}
	strs := strings.Split(ltext, " ")
	rects, err := page.CheckContain(strs)
	// 检查结果的截图
	logImgBeforeCheck := page.ScreenShot.Clone()
	for _, rect := range rects {
		page.DrawRectangle(logImgBeforeCheck, rect.GetImageRect(), color.RGBA{R: 255})
	}
	saveScreenShot(logImgBeforeCheck, "检查结果")
	if err != nil {
		log.Println("  检查失败{"+ltext+"},err", err)
		L.Push(lua.LBool(false))
		return 1
	}
	log.Println("  检查成功{" + ltext + "}")
	L.Push(lua.LBool(true))
	return 1
}

// ClickCoordinate 点击屏幕原始坐标，只作调试用，不作截图记录
func ClickCoordinate(L *lua.LState) int {
	lx := L.ToInt(1)
	ly := L.ToInt(2)
	log.Println("开始点击{" + "(" + strconv.Itoa(lx) + "," + strconv.Itoa(ly) + ")" + "}")
	var err error
	if globalVariable.IsInDevice {
		_, _ = inDevice.WakeScreen()
		_, err = inDevice.Click(lx, ly)
	} else {
		_, _ = adbUtil.WakeScreen(device.SN.Data)
		_, err = adbUtil.Click(device.SN.Data, lx, ly)
	}

	if err != nil {
		panic("  <font size=5 color=red >点击失败{" + "(" + strconv.Itoa(lx) + "," + strconv.Itoa(ly) + ")" + "},err:" + err.Error() + "</font>")
		return 1
	}
	log.Println("  点击成功{" + "(" + strconv.Itoa(lx) + "," + strconv.Itoa(ly) + ")" + "}")
	L.Push(lua.LBool(true))
	return 1
}

// ClickScreenCoordinate 点击屏幕截图的坐标
func ClickScreenCoordinate(L *lua.LState) int {
	lx := L.ToInt(1)
	ly := L.ToInt(2)
	page, err := device.FetchScreenShot()
	if err != nil {
		panic("  <font size=5 color=red >获取 page 失败,err:" + err.Error() + "</font>")
	}
	log.Println("开始点击屏幕画面坐标{" + "(" + strconv.Itoa(lx) + "," + strconv.Itoa(ly) + ")" + "}")
	err = page.Click_ShownScreen(lx, ly)
	imgBeforeClick := page.ScreenShot.Clone()
	page.DrawCircle(imgBeforeClick, image.Point{lx, ly}, color.RGBA{R: 255})
	saveScreenShot(imgBeforeClick, "执行前截图")
	if err != nil {
		panic("  <font size=5 color=red >点击失败{" + "(" + strconv.Itoa(lx) + "," + strconv.Itoa(ly) + ")" + "},err:" + err.Error() + "</font>")
		return 1
	}
	log.Println("  点击成功{" + "(" + strconv.Itoa(lx) + "," + strconv.Itoa(ly) + ")" + "}")
	page, err = device.FetchScreenShot()
	saveScreenShot(page.ScreenShot, "点击后截图")
	L.Push(lua.LBool(true))
	return 1
}

// SleepForSecond 睡几秒
func SleepForSecond(L *lua.LState) int {
	lsec := L.ToNumber(1)
	log.Println("开始等待{" + fmt.Sprint(lsec) + " sec}")
	time.Sleep(time.Second * time.Duration(lsec))
	log.Println("  结束等待{" + fmt.Sprint(lsec) + " sec}")
	return 0
}

// SlipFromToCoordinate 按设备屏幕原始坐标滑动，只作调试用，不作截图记录
func SlipFromToCoordinate(L *lua.LState) int {
	lx1 := L.ToInt(1)
	ly1 := L.ToInt(2)
	lx2 := L.ToInt(3)
	ly2 := L.ToInt(4)
	interval := L.ToInt(5)
	if interval == 0 {
		interval = 3
	}
	if math.Abs(float64(lx1-lx2)) > math.Abs(float64(ly1-ly2)) {
		ly1 = ly2
	} else {
		lx1 = lx2
	}
	log.Println("开始滑动{" + fmt.Sprintf("(%v,%v)->(%v,%v)", lx1, ly1, lx2, ly2) + "}")
	var err error
	if globalVariable.IsInDevice {
		_, err = inDevice.Slip(lx1, ly1, lx2, ly2, interval)
	} else {
		_, err = adbUtil.Slip(device.SN.Data, lx1, ly1, lx2, ly2, interval)
	}
	if err != nil {
		panic("  <font size=5 color=red >滑动失败{" + fmt.Sprintf("(%v,%v)->(%v,%v)", lx1, ly1, lx2, ly2) + "},err:" + err.Error() + "</font>")
		return 1
	}
	log.Println("  滑动成功{" + fmt.Sprintf("(%v,%v)->(%v,%v)", lx1, ly1, lx2, ly2) + "}")
	L.Push(lua.LBool(true))
	return 1
}

// SlipFromToScreenCoordinate 按屏幕截图上的坐标滑动
func SlipFromToScreenCoordinate(L *lua.LState) int {
	lx1 := L.ToInt(1)
	ly1 := L.ToInt(2)
	lx2 := L.ToInt(3)
	ly2 := L.ToInt(4)
	interval := L.ToInt(5)
	if interval == 0 {
		interval = 3
	}
	if math.Abs(float64(lx1-lx2)) > math.Abs(float64(ly1-ly2)) {
		ly1 = ly2
	} else {
		lx1 = lx2
	}
	log.Println("开始按屏幕截图坐标滑动{" + fmt.Sprintf("(%v,%v)->(%v,%v)", lx1, ly1, lx2, ly2) + "}")
	page, err := device.FetchScreenShot()
	a := image.Point{
		X: lx1,
		Y: ly1,
	}
	b := image.Point{
		X: lx2,
		Y: ly2,
	}
	if err != nil {
		panic("  <font size=5 color=red >获取 page 失败,err:" + err.Error() + "</font>")
		return 1
	}
	err = page.Slip_ShownScreen(a, b, interval)

	logImgBeforeSlip := page.ScreenShot.Clone()
	page.DrawCircle(logImgBeforeSlip, a, color.RGBA{R: 255})
	page.DrawCircle(logImgBeforeSlip, b, color.RGBA{B: 255})
	saveScreenShot(logImgBeforeSlip, "滑动起始点截图")
	if err != nil {
		panic("  <font size=5 color=red >滑动失败{" + fmt.Sprintf("(%v,%v)->(%v,%v)", lx1, ly1, lx2, ly2) + "},err:" + err.Error() + "</font>")
		//L.Push(lua.LBool(false))
		return 1
	}
	log.Println("  滑动成功{" + fmt.Sprintf("(%v,%v)->(%v,%v)", lx1, ly1, lx2, ly2) + "}")
	page, err = device.FetchScreenShot()
	saveScreenShot(page.ScreenShot, "滑动后截图")
	L.Push(lua.LBool(true))
	return 1
}
func LogInfo(L *lua.LState) int {
	basePrint := func(L *lua.LState) int {
		top := L.GetTop()
		var build strings.Builder

		for i := 1; i <= top; i++ {
			build.WriteString(L.ToStringMeta(L.Get(i)).String())
			if i != top {
				build.WriteString("\t")
			}
		}
		s := build.String()
		log.Println(s)
		return 0
	}
	return basePrint(L)
}

// ClickImg 点击识别到的模板图片
func ClickImg(L *lua.LState) int {
	ltext := L.ToString(1)
	mdClickImgPath := "![alt " + ltext + "](https://hwp-static.inner.youdao.com/hwp/uiautomatic_template_img/" + ltext + ")"
	var limgOrder int
	limgOrder = L.ToInt(2)
	var lthreshold float32
	lthreshold = float32(L.ToNumber(3))
	if limgOrder <= 0 {
		limgOrder = 1
	}
	limgOrder--
	if lthreshold <= 0.0 {
		lthreshold = 0.95
	}
	log.Println("开始点击第 " + strconv.Itoa(limgOrder+1) + " 张图片{" + mdClickImgPath + "}")

	tempDirPath := filepath.Dir(caseFileName)
	teplFinalPath := tempDirPath + string(os.PathSeparator) + ltext

	page, err := device.LocateElementByTemplateMatch(teplFinalPath, limgOrder, lthreshold)
	if err != nil {
		log.Println("  定位失败{"+mdClickImgPath+"},err:", err)
		L.Push(lua.LBool(false))
		return 1
	}
	var clickPoint image.Point
	var region locationUtil.Rect

	clickPoint, region, err = page.Click("teplMatch_img" + strconv.Itoa(limgOrder))
	logImgBeforeClick := page.ScreenShot.Clone()
	page.DrawCircle(logImgBeforeClick, clickPoint, color.RGBA{R: 255})
	page.DrawRectangle(logImgBeforeClick, region.GetImageRect(), color.RGBA{R: 255})
	saveScreenShot(logImgBeforeClick, "点击前截图")

	if err != nil {
		panic("  <font size=5 color=red >点击失败{" + mdClickImgPath + "},err:" + err.Error() + "</font>")
		return 1
	}
	log.Println("  点击成功{" + mdClickImgPath + "}")
	page, err = device.FetchScreenShot()
	saveScreenShot(page.ScreenShot, "点击后截图")
	//time.Sleep(time.Second * time.Duration(1))
	L.Push(lua.LBool(true))
	return 1
}

// CheckImg 检查识别到的模板图片
func CheckImg(L *lua.LState) int {
	ltext := L.ToString(1)
	mdClickImgPath := "![alt " + "](https://hwp-static.inner.youdao.com/hwp/uiautomatic_template_img/" + ltext + ")"
	log.Println("开始检查图片{" + mdClickImgPath + "}")

	var limgOrder int
	limgOrder = L.ToInt(2)
	var lthreshold float32
	lthreshold = float32(L.ToNumber(3))
	if limgOrder <= 0 {
		limgOrder = 1
	}
	limgOrder--
	if lthreshold <= 0.0 {
		lthreshold = 0.95
	}

	tempDirPath := filepath.Dir(caseFileName)
	teplFinalPath := tempDirPath + string(os.PathSeparator) + ltext
	page, err := device.LocateElementByTemplateMatch(teplFinalPath, limgOrder, lthreshold)
	if err != nil {
		log.Println("  定位失败{"+mdClickImgPath+"},err:", err)
		L.Push(lua.LBool(false))
		return 1
	}
	var rect locationUtil.Rect

	rect, err = page.CheckContainImg("teplMatch_img" + strconv.Itoa(limgOrder))

	logImgBeforeCheck := page.ScreenShot.Clone()
	page.DrawRectangle(logImgBeforeCheck, rect.GetImageRect(), color.RGBA{R: 255})

	saveScreenShot(logImgBeforeCheck, "检查结果")
	if err != nil {
		log.Println("  检查失败{"+mdClickImgPath+"},err:", err)
		L.Push(lua.LBool(false))
		return 1
	}
	log.Println("  检查图片成功{" + mdClickImgPath + "}")
	//time.Sleep(time.Second * time.Duration(1))
	L.Push(lua.LBool(true))
	L.Push(lua.LNumber(rect.Center.X))
	L.Push(lua.LNumber(rect.Center.Y))
	return 3
}

// SlipHalfScreen 滑动半个屏幕
func SlipHalfScreen(L *lua.LState) int {
	// 参数1是命令
	ltext := L.ToString(1)
	var lcount int
	// 参数2是滑动次数
	lcount = L.ToInt(2)
	if lcount < 1 {
		lcount = 1
	}
	// 参数3是滑动速度
	interval := L.ToInt(3)
	if interval <= 0 {
		interval = 3
	}
	log.Println("开始向{" + ltext + "}滑动 " + strconv.Itoa(lcount) + " 次")
	page, err := device.FetchScreenShot()
	if err != nil {
		panic("  <font size=5 color=red >获取page失败</font>")
		return 1
	}
	//logImgBeforeSlip := page.ScreenShot.Clone()
	//saveScreenShot(logImgBeforeSlip, "滑动前截图")
	for i := 0; i < lcount; i++ {
		err = page.Slip_HalfShownScreen(ltext, interval)
		if err != nil {
			panic("  <font size=5 color=red >滑动失败{" + ltext + "},err: %v" + err.Error() + "</font>")
			return 1
		}
	}
	page, err = device.FetchScreenShot()
	if err != nil {
		panic("  <font size=5 color=red >获取page失败</font>")
		return 1
	}
	logImgAfterSlip := page.ScreenShot.Clone()
	saveScreenShot(logImgAfterSlip, "滑动后截图")
	log.Println("  滑动成功{" + ltext + "}")
	L.Push(lua.LBool(true))
	return 1
}

// ClickPowerBtn 点击电源按钮
func ClickPowerBtn(L *lua.LState) int {
	ldelay := L.ToNumber(1)

	log.Println("点击{电源键}")
	var res string
	var err error
	if globalVariable.IsInDevice {
		res, err = inDevice.ClickPower(float64(ldelay))
	} else {
		res, err = adbUtil.ClickPower(device.SN.Data, float64(ldelay))
	}
	if err != nil {
		panic("  <font size=5 color=red >点击失败{电源键},res: " + res + " err: " + err.Error() + "</font>")
		return 1
	}
	log.Println("  点击成功{电源键}")
	L.Push(lua.LBool(true))
	return 1
}

// OpenCloseLed cherry
func OpenCloseLed(L *lua.LState) int {
	lMode := L.ToString(1) //press release click
	lDelay := L.ToNumber(2)
	log.Println("亮/熄{扫描灯}")
	var res string
	var err error
	if globalVariable.IsInDevice {
		switch lMode {
		case "click":
			res, err = inDevice.ClickLed(float64(lDelay))
		case "press":
			res, err = inDevice.SendEvent64([]string{"-obj", "led", "-action", "press"})
		case "release":
			res, err = inDevice.SendEvent64([]string{"-obj", "led", "-action", "release"})
		default:
			res, err = inDevice.ClickLed(float64(lDelay))
		}
	} else {
		switch lMode {
		case "click":
			res, err = adbUtil.ClickLed(device.SN.Data, float64(lDelay))
		case "press":
			res, err = inDevice.SendEvent64([]string{"-obj", "led", "-action", "press"})
		case "release":
			res, err = inDevice.SendEvent64([]string{"-obj", "led", "-action", "release"})
		default:
			res, err = adbUtil.ClickLed(device.SN.Data, float64(lDelay))
		}
	}
	if err != nil {
		panic("  <font size=5 color=red >亮/熄{扫描灯}失败,res: " + res + " err: " + err.Error())
		return 1
	}
	log.Println("  亮/熄{扫描灯}成功")
	L.Push(lua.LBool(true))
	return 1
}
func OpenCloseLedCOCO(L *lua.LState) int {
	lMode := L.ToString(1) //press release click
	lDelay := L.ToNumber(2)
	log.Println("亮/熄{扫描灯}")
	var res string
	var err error
	if globalVariable.IsInDevice {
		switch lMode {
		case "click":
			res, err = inDevice.ClickLedCOCO(float64(lDelay))
		case "press":
			res, err = inDevice.SendEvent32([]string{"-obj", "led", "-action", "press"})
		case "release":
			res, err = inDevice.SendEvent32([]string{"-obj", "led", "-action", "release"})
		default:
			res, err = inDevice.ClickLedCOCO(float64(lDelay))
		}
	} else {
		switch lMode {
		case "click":
			res, err = adbUtil.ClickLedCOCO(device.SN.Data, float64(lDelay))
		case "press":
			res, err = inDevice.SendEvent32([]string{"-obj", "led", "-action", "press"})
		case "release":
			res, err = inDevice.SendEvent32([]string{"-obj", "led", "-action", "release"})
		default:
			res, err = adbUtil.ClickLedCOCO(device.SN.Data, float64(lDelay))
		}
	}
	if err != nil {
		panic("  <font size=5 color=red >亮/熄{扫描灯}失败,res: " + res + " err: " + err.Error())
		return 1
	}
	log.Println("  亮/熄{扫描灯}成功")
	L.Push(lua.LBool(true))
	return 1
}

// ClickSoundHelperBtn 点击语音助手按钮
func ClickSoundHelperBtn(L *lua.LState) int {
	lMode := L.ToString(1) // press release click
	ldelay := L.ToNumber(2)
	log.Println("点击{语音助手键}")
	var res string
	var err error
	if globalVariable.IsInDevice {
		switch lMode {
		case "click":
			res, err = inDevice.ClickSoundHelper(float64(ldelay))
		case "press":
			res, err = inDevice.SendEvent64([]string{"-obj", "menu", "-action", "press"})
		case "release":
			res, err = inDevice.SendEvent64([]string{"-obj", "menu", "-action", "release"})
		default:
			res, err = inDevice.ClickSoundHelper(float64(ldelay))
		}
	} else {
		switch lMode {
		case "click":
			res, err = adbUtil.ClickSoundHelper(device.SN.Data, float64(ldelay))
		case "press":
			res, err = adbUtil.SendEvent64(device.SN.Data, []string{"-obj", "menu", "-action", "press"})
		case "release":
			res, err = adbUtil.SendEvent64(device.SN.Data, []string{"-obj", "menu", "-action", "release"})
		default:
			res, err = adbUtil.ClickSoundHelper(device.SN.Data, float64(ldelay))
		}
	}
	if err != nil {
		panic("  <font size=5 color=red >点击失败{语音助手键},res: " + res + " err: " + err.Error())
		return 1
	}
	log.Println("  点击成功{语音助手键}")
	L.Push(lua.LBool(true))
	return 1
}

// SlipDropDownMenu 下拉菜单
func SlipDropDownMenu(L *lua.LState) int {
	log.Println("滑动{下拉菜单}")
	interval := L.ToInt(1)
	if interval == 0 {
		interval = 5
	}
	page, err := device.FetchScreenShot()
	a := image.Point{
		X: 401,
		Y: 128,
	}
	b := image.Point{
		X: 377,
		Y: 423,
	}
	if err != nil {
		panic("  <font size=5 color=red >获取 page 失败,err:" + err.Error() + "</font>")
		return 1
	}
	saveScreenShot(page.ScreenShot, "下拉菜单前")
	err = page.Slip_ShownScreen(a, b, interval)
	page, err = device.FetchScreenShot()
	saveScreenShot(page.ScreenShot, "下拉菜单后")
	if err != nil {
		panic("  <font size=5 color=red >滑动失败{下拉菜单},err:" + err.Error() + "</font>")
		return 1
	}
	log.Println("  滑动成功{下拉菜单}")
	L.Push(lua.LBool(true))
	return 1
}

// GoHome 回首页
func GoHome(L *lua.LState) int {
	log.Println("回到首页")
	//page, err := device.FetchScreenShot()
	//saveScreenShot(page.ScreenShot, "回到首页前")
	var res string
	var err error
	if globalVariable.IsInDevice {
		res, err = inDevice.KillDictPenUi()
		time.Sleep(time.Second * 10)
	} else {
		res, err = adbUtil.Reboot(device.SN.Data)
	}
	if err != nil {
		log.Printf("  重启ui失败,res: %v err: %v\n", res, err)
		L.Push(lua.LBool(false))
		return 1
	}

	page, err := device.FetchScreenShot()
	saveScreenShot(page.ScreenShot, "回到首页后")
	L.Push(lua.LBool(true))
	return 1
}

func ScreenShot(L *lua.LState) int {
	lSaveFolder := L.ToString(1)
	lFileName := L.ToString(2)
	log.Println("获取截图")
	page, err := device.FetchScreenShot()
	if err != nil {
		log.Println("  获取截图失败！err:", err)
		return 0
	}
	if lSaveFolder == "" {
		err = saveScreenShot(page.ScreenShot, "此刻截图")
	} else {
		saveScreenShotToFolder(page.ScreenShot, lSaveFolder, lFileName)
	}
	if err != nil {
		log.Println("  保存截图失败！err:", err)
		return 0
	}
	return 0
}

// 修复点击不了的bug
func fixClickFailedBug() {
	var err error
	if globalVariable.IsInDevice {
		_, err = inDevice.FixClickFailedBugForCardMode()
	} else {
		_, err = adbUtil.FixClickFailedBugForCardMode(device.SN.Data)
	}
	if err != nil {
		log.Println("修复点击不了的bug失败，可能会点击失败，err:", err)
	}
}

// playMp3 通过ffplay播放
func playMp3(L *lua.LState) int {
	SetPlaySoundExecutable()
	lAudioFilePath := L.ToString(1)
	log.Println("播放音频文件：", lAudioFilePath)

	args := []string{`-nodisp`, `-autoexit`, `-loglevel`, `quiet`, lAudioFilePath}
	cmd := exec.Command(playSoundExec, args...)
	err := cmd.Run()
	if err != nil {
		panic(err)
	}
	defer func() { cmd.Process.Kill() }()
	return 0
}

var sysType string
var playSoundExec string

func SetPlaySoundExecutable() {
	sysType = runtime.GOOS
	home, _ := os.UserHomeDir()
	switch sysType {
	case "darwin":
		playSoundExec = "ffplay"
		//playSoundExec = home + "/dictpenUiAutomaticTest/bin/mac/playSound"
	case "linux":
		playSoundExec = "ffplay"
		//playSoundExec = home + "/dictpenUiAutomaticTest/bin/linux/playSound"
	case "windows":
		playSoundExec = home + "\\dictpenUiAutomaticTest\\bin\\win\\ffplay.exe"
	}
}

func SetLastScreenShot(L *lua.LState) int {
	page, _ := device.FetchScreenShot()
	lastImg = page.ScreenShot
	return 0
}

// IsScreenChanged 通过截图判断屏幕是否变化
func IsScreenChanged(L *lua.LState) int {
	lThre := L.ToNumber(1)
	if lThre < 0.1 {
		lThre = 0.99
	}

	if lastImg.Empty() {
		//fmt.Println("lastImg empty")
		L.Push(lua.LBool(true))
		return 1
	}
	page, err := device.FetchScreenShot()
	if err != nil {
		fmt.Println(err)
		// 默认变化了
		L.Push(lua.LBool(true))
		return 1
	}
	//saveScreenShot(lastImg, "上次截图")
	//saveScreenShot(page.ScreenShot, "本次截图")
	point, _ := locationUtil.TemplateMatch(lastImg, page.ScreenShot, gocv.TmCcoeffNormed, float32(lThre))
	if len(point) > 0 {
		//fmt.Println(score)
		// 模板匹配到了说明屏幕没变
		L.Push(lua.LBool(false))
		return 1
	}

	// 默认变化了
	L.Push(lua.LBool(true))
	return 1
}

func ClickSoundHelperBtnCOCO(L *lua.LState) int {
	lMode := L.ToString(1) // press release click
	ldelay := L.ToNumber(2)
	log.Println("点击{语音助手键}")
	var res string
	var err error
	if globalVariable.IsInDevice {
		switch lMode {
		case "click":
			res, err = inDevice.ClickPhysicsButtonExec32("menu", int(ldelay*1000))
		case "press":
			res, err = inDevice.SendEvent32([]string{"-obj", "menu", "-action", "press"})
		case "release":
			res, err = inDevice.SendEvent32([]string{"-obj", "menu", "-action", "release"})
		default:
			res, err = inDevice.ClickPhysicsButtonExec32("menu", int(ldelay*1000))
		}
	} else {
		switch lMode {
		case "click":
			res, err = adbUtil.ClickPhysicsButtonExec32(device.SN.Data, "menu", int(ldelay*1000))
		case "press":
			res, err = adbUtil.SendEvent32(device.SN.Data, []string{"-obj", "menu", "-action", "press"})
		case "release":
			res, err = adbUtil.SendEvent32(device.SN.Data, []string{"-obj", "menu", "-action", "release"})
		default:
			res, err = adbUtil.ClickPhysicsButtonExec32(device.SN.Data, "menu", int(ldelay*1000))
		}
	}
	if err != nil {
		panic("  <font size=5 color=red >点击失败{语音助手键},res: " + res + " err: " + err.Error())
		return 1
	}
	log.Println("  点击成功{语音助手键}")
	L.Push(lua.LBool(true))
	return 1
}
