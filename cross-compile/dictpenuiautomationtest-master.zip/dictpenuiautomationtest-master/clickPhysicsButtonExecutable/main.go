package main

import (
	"flag"
	"fmt"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"os"
	"os/exec"
	"runtime"
	"time"
)

const VERSION = "v1.0.0"

func main() {
	var command string
	var elapseTime int
	var arch string

	var deviceSN globalVariable.SN
	deviceSN.Data = os.Getenv("SN")
	flag.StringVar(&command, "cmd", "menu", "power,menu,sound_up,sound_down,forward,back,play,screen,led")
	flag.IntVar(&elapseTime, "elapse", 0, "输入等待的毫秒数")
	flag.StringVar(&arch, "arch", "arm64", "设备架构，3566为arm64，coco为arm32")
	flag.Parse()
	remainCmd := flag.Arg(0)
	if remainCmd == "version" {
		fmt.Println(VERSION)
		return
	}
	var sendEventCmd string

	//sendEventCmd = "send_event"
	//
	switch arch {
	case "arm64":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64"
	case "arm32":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32"
	}

	prodStr, err := deviceSN.GetProductSerial()
	arch1 := runtime.GOARCH
	fmt.Println(arch1)
	if arch1 == "arm" {
		prodStr = "coco"
	}

	switch prodStr {
	case "coco":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/32bit/sendEventArm32"
	case "dictpen2":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64"
	case "dictpen":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64"
	case "apollo":
		sendEventCmd = "/userdisk/dictpenUiAutomaticTest/scripts/sendEventArm64"
	}

	cmd := exec.Command(sendEventCmd, "-obj", command, "-action", "press")
	_, err = cmd.Output()
	if err != nil {
		panic(err)
	}
	time.Sleep(time.Duration(elapseTime) * time.Millisecond)
	cmd = exec.Command(sendEventCmd, "-obj", command, "-action", "release")
	_, err = cmd.Output()
	if err != nil {
		panic(err)
	}
	return
}
