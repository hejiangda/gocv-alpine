package main

import "testing"

func TestDownloadTestCaseLuaScript(t *testing.T) {
	DownloadTestCaseLuaScript(301)

}
