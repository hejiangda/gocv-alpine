package main

import (
	"fmt"
	lua "github.com/yuin/gopher-lua"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"log"
	"time"
)

type Dictpen struct {
}

// Click 点击ocr识别到的文字
func (d *Dictpen) Click(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	ret := Click(L)
	return ret
}

// CheckContain 检查文字是否存在
func (d *Dictpen) CheckContain(L *lua.LState) int {
	incTestStep()
	return CheckContain(L)
}

// ClickCoordinate 点击屏幕原始坐标，只作调试用，不作截图记录
func (d *Dictpen) ClickCoordinate(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	return ClickCoordinate(L)
}

// ClickScreenCoordinate 点击屏幕截图的坐标
func (d *Dictpen) ClickScreenCoordinate(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	ret := ClickScreenCoordinate(L)
	return ret
}

// SleepForSecond 睡几秒
func (d *Dictpen) SleepForSecond(L *lua.LState) int {
	incTestStep()
	sleepForSecond := func(L *lua.LState) int {
		lsec := L.ToNumber(1)
		log.Println("开始等待{" + fmt.Sprint(lsec) + " sec}")
		var i int
		for i = 0; i < int(lsec); i++ {
			time.Sleep(time.Second)
			adbUtil.FixClickFailedBugForCardMode(device.SN.Data)
			adbUtil.WakeScreen(device.SN.Data)
		}
		log.Println("  结束等待{" + fmt.Sprint(lsec) + " sec}")
		return 0
	}
	return sleepForSecond(L)
}

// SlipFromToCoordinate 按设备屏幕原始坐标滑动，只作调试用，不作截图记录
func (d *Dictpen) SlipFromToCoordinate(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	return SlipFromToCoordinate(L)
}

// SlipFromToScreenCoordinate 按屏幕截图上的坐标滑动
func (d *Dictpen) SlipFromToScreenCoordinate(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	ret := SlipFromToScreenCoordinate(L)
	return ret
}

// LogInfo 输出带时间戳的文字
func (d *Dictpen) LogInfo(L *lua.LState) int {
	return LogInfo(L)
}

// ClickImg 点击识别到的模板图片
func (d *Dictpen) ClickImg(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	ret := ClickImg(L)
	return ret
}

// CheckImg 检查识别到的模板图片
func (d *Dictpen) CheckImg(L *lua.LState) int {
	incTestStep()
	return CheckImg(L)
}

// SlipHalfScreen 滑动半个屏幕
func (d *Dictpen) SlipHalfScreen(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	ret := SlipHalfScreen(L)
	return ret
}

// ClickPowerBtn 点击电源按钮
func (d *Dictpen) ClickPowerBtn(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	return ClickPowerBtn(L)
}

// ClickSoundHelperBtn 点击语音助手按钮
func (d *Dictpen) ClickSoundHelperBtn(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	return ClickSoundHelperBtn(L)
}

// SlipDropDownMenu 下拉菜单
func (d *Dictpen) SlipDropDownMenu(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()
	return SlipDropDownMenu(L)
}

// GoHome 回首页
func (d *Dictpen) GoHome(L *lua.LState) int {
	incTestStep()
	err := L.DoString(`
	print("开始回到首页")
	click_xy(0,0) 
	click_soundhelper()
	slip("right",3,100)
	print("已经回到首页")`)
	if err != nil {
		panic(err)
	}
	return 0
}

func (d *Dictpen) Print(L *lua.LState) int {
	return LogInfo(L)
}

func (d *Dictpen) ClickPhysicalButton(L *lua.LState) int {
	incTestStep()
	fixClickFailedBug()

	// click_physical_buttons("按键名","模式","持续时间")
	buttonName := L.ToString(1)

	L.Remove(1)
	switch buttonName {
	case "power":
		return ClickPowerBtn(L)
	case "sound_helper":
		return ClickSoundHelperBtn(L)
	case "menu":
		return ClickSoundHelperBtn(L)
	case "led":
		return OpenCloseLed(L)
	}
	return unimplemented()
}
func (d *Dictpen) PlayMp3(L *lua.LState) int {
	return playMp3(L)
}
func (d *Dictpen) ScreenShot(L *lua.LState) int {
	return ScreenShot(L)
}
