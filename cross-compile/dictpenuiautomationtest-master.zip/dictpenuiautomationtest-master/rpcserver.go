package main

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/adbUtil"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/aladdin"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/globalVariable"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/locationUtil"
	pb "gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/pb"
	"gitlab.corp.youdao.com/hejd/dictpenuiautomationtest/ydocr"
	"gocv.io/x/gocv"
	"google.golang.org/protobuf/types/known/emptypb"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
)

var clientCnt = 0

type server struct {
	pb.UnimplementedUiAutomationServer
	aladdin.UnimplementedAladdinServer
}

func (s *server) FetchSNs(ctx context.Context, in *emptypb.Empty) (*pb.DeviceSN, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	log.Println("Fetch device SNs.")

	sns, err := adbUtil.GetDevices()
	if err != nil {
		//log.Panicln("adb 没有检测到设备！err:", err)
		return &pb.DeviceSN{Cnt: 0, Sns: nil}, err
	}
	var ret deviceSN
	ret.Cnt = len(sns)
	for _, snArr := range sns {
		sn := snArr[0]
		ret.Sns = append(ret.Sns, sn)
	}
	return &pb.DeviceSN{Cnt: int32(ret.Cnt), Sns: ret.Sns}, nil
}
func (s *server) FetchScreenShot(ctx context.Context, in *pb.Sn) (*pb.ScreenShot, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	localDevice, err := locationUtil.InitDevice(in.GetSn())
	if err != nil {
		return &pb.ScreenShot{ImageBase64: ""}, err
	}
	page, err := localDevice.FetchScreenShot()
	if err != nil {
		return &pb.ScreenShot{ImageBase64: ""}, err
	}
	imgByte, err := gocv.IMEncode(".png", page.ScreenShot)
	if err != nil {
		return &pb.ScreenShot{ImageBase64: ""}, err
	}
	buff := new(bytes.Buffer)
	err = ydocr.Base64Encode(imgByte.GetBytes(), buff)
	if err != nil {
		return nil, err
	}
	imgEncode := buff.String()
	return &pb.ScreenShot{ImageBase64: imgEncode}, nil
}
func (s *server) GetDeviceInfo(ctx context.Context, in *pb.Sn) (*pb.DeviceInfo, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	sn := in.GetSn()
	var tmpSn globalVariable.SN
	tmpSn.Data = sn
	prodStr, _ := tmpSn.GetProductSerial()
	switch prodStr {
	case "coco":
		if !adbUtil.AuthCoco(sn) {
			return nil, errors.New("can not auth device")
		}
	case "dictpen":
		if !adbUtil.Auth(sn) {
			return nil, errors.New("can not auth device")
		}
	case "apollo":
		if !adbUtil.Auth(sn) {
			return nil, errors.New("can not auth device")
		}
	}
	sku, err := adbUtil.GetPenSKU(sn)
	if err != nil {
		return nil, err
	}

	firmwareVersion, err := adbUtil.GetPenFirmware(sn)
	if err != nil {
		return nil, err
	}

	pcba, err := adbUtil.GetPenPCBA(sn)
	if err != nil {
		return nil, err
	}

	return &pb.DeviceInfo{
		Sn:              sn,
		Sku:             sku,
		FirmwareVersion: firmwareVersion,
		Pcba:            pcba,
	}, nil

}
func (s *server) FetchDeviceInfo(ctx context.Context, in *aladdin.Sn) (*aladdin.DeviceInfo, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	sn := in.GetSn()
	apkVersion, err := adbUtil.GetAPKVersion(sn)
	if err != nil {
		return nil, err
	}
	mcuVersion, err := adbUtil.GetMCUVersion(sn)
	if err != nil {
		return nil, err
	}
	wifiStatus, wifiSsid, wifiInternsity := adbUtil.GetWifiInfo(sn)
	return &aladdin.DeviceInfo{
		ApkVersion:    apkVersion,
		McuVersion:    mcuVersion,
		WifiStatus:    wifiStatus,
		WifiSsid:      wifiSsid,
		WifiIntensity: wifiInternsity,
	}, nil
}
func (s *server) InstallSoloPi(ctx context.Context, in *aladdin.InstallAppArgs) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	sn := in.GetSn()
	appPath := in.GetAppPath()
	_, err := adbUtil.InstallSoloPi(sn, appPath)
	if err != nil {
		return nil, err
	}
	return &emptypb.Empty{}, nil
}
func (s *server) RunSoloPi(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	sn := in.GetSn()
	_, err := adbUtil.StartSoloPi(sn)
	if err != nil {
		return nil, err
	}
	return &emptypb.Empty{}, nil
}
func (s *server) UnInstallSoloPi(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	sn := in.GetSn()
	_, err := adbUtil.UninstallSoloPi(sn)
	if err != nil {
		return nil, err
	}
	return &emptypb.Empty{}, nil
}

var ota adbUtil.OTAStatus
var va adbUtil.VoiceAssistant

// ota
func (s *server) OtaStatus(ctx context.Context, in *aladdin.Sn) (*aladdin.OTAStatus, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	return &aladdin.OTAStatus{
		OtaStatus: int32(ota.OtaStatus),
		Progress:  float32(ota.Progress),
		Success:   ota.Success,
	}, nil
}
func (s *server) StartOtaStatus(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	_, err := (&ota).FilterOTAStatus(in.GetSn())
	if err != nil {
		return &emptypb.Empty{}, err
	}
	return &emptypb.Empty{}, nil
}

// 5min log
func (s *server) GetLogCat5Min(ctx context.Context, in *aladdin.Sn) (*aladdin.LogCatMessage, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	log5min, err := adbUtil.ExportLogCat5Min(in.GetSn())
	if err != nil {
		return &aladdin.LogCatMessage{}, err
	}
	return &aladdin.LogCatMessage{Log: log5min}, nil
}

//  voiceAssistant
func (s *server) GetVoiceAssistantVal(ctx context.Context, in *aladdin.Sn) (*aladdin.VoiceAssistantWakeUpTime, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	val := (&va).GetWakeUpTime()
	status, err := adbUtil.GetVoiceAssistantStatus(in.GetSn())
	status = strings.TrimRight(status, "\\\r\n")
	if err != nil {
		return &aladdin.VoiceAssistantWakeUpTime{}, err
	}

	okInt, err := strconv.ParseInt(status, 10, 32)
	if err != nil {
		okInt = -1
	}

	return &aladdin.VoiceAssistantWakeUpTime{WakeUpTime: int32(val), Status: int32(okInt)}, nil
}
func (s *server) StartFilterVoiceAssistantWakeUpTime(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	_, err := (&va).FilterVoiceAssistantWakeUpTime(in.GetSn())
	if err != nil {
		return &emptypb.Empty{}, err
	}
	return &emptypb.Empty{}, nil
}
func (s *server) ResetVoiceAssistantVal(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	(&va).Reset()
	return &emptypb.Empty{}, nil
}

// clickFeedback
func (s *server) OpenClickFeedback(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	_, err := adbUtil.OpenClickFeedback(in.GetSn())
	if err != nil {
		return &emptypb.Empty{}, err
	}
	return &emptypb.Empty{}, nil
}
func (s *server) CloseClickFeedback(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	_, err := adbUtil.CloseClickFeedback(in.GetSn())
	if err != nil {
		return &emptypb.Empty{}, err
	}
	return &emptypb.Empty{}, nil
}
func (s *server) OpenVoiceAssistant(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	_, err := adbUtil.OpenVoiceAssistant(in.GetSn())
	if err != nil {
		return &emptypb.Empty{}, err
	}
	return &emptypb.Empty{}, nil
}
func (s *server) GetLightSwitchStatus(ctx context.Context, in *aladdin.Sn) (*aladdin.LightStatus, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	res, err := adbUtil.GetLightSwitchStatus(in.GetSn())
	if err != nil {
		return &aladdin.LightStatus{LightMode: -1}, err
	}

	val, err := strconv.ParseInt(res, 10, 32)
	if err != nil {
		return &aladdin.LightStatus{LightMode: -1}, err
	}
	return &aladdin.LightStatus{LightMode: int32(val)}, nil
}
func (s *server) GetLightMode(ctx context.Context, in *aladdin.Sn) (*aladdin.LightStatus, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	res, err := adbUtil.GetLightMode(in.GetSn())
	if err != nil {
		return &aladdin.LightStatus{LightMode: -1}, err
	}
	val, err := strconv.ParseInt(res, 10, 32)
	if err != nil {
		return &aladdin.LightStatus{LightMode: -1}, err
	}
	return &aladdin.LightStatus{LightMode: int32(val)}, nil
}
func (s *server) OpenCloseLight(ctx context.Context, in *aladdin.LightSwitch) (*aladdin.AdbExecuteResult, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	res, err := adbUtil.OpenCloseLight(in.GetSn(), int(in.GetVal()))

	if err != nil {
		return &aladdin.AdbExecuteResult{}, err
	}
	return &aladdin.AdbExecuteResult{Result: res}, nil
}
func (s *server) CloseVoiceAssistant(ctx context.Context, in *aladdin.Sn) (*emptypb.Empty, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	_, err := adbUtil.CloseVoiceAssistant(in.GetSn())
	if err != nil {
		return &emptypb.Empty{}, err
	}
	return &emptypb.Empty{}, nil
}

func (s *server) ExecTestCase(in *pb.TestCaseRequest, stream pb.UiAutomation_ExecTestCaseServer) error {
	defer func() {
		if err := recover(); err != nil {
			log.Println(err)
		}
	}()
	sn := in.GetSn()
	logname := in.GetLogName()
	fmt.Println(logname)
	caseManageId := in.GetCaseManageId()
	minioLocation := in.GetMinioLocation()
	luaCode := in.GetLuaCode()
	tempDir, err := ioutil.TempDir("", "dictpenCase")
	if err != nil {
		return err
	}
	exePath, err := func() (string, error) {
		file, err := exec.LookPath(os.Args[0])
		if err != nil {
			return "", err
		}
		path, err := filepath.Abs(file)
		if err != nil {
			return "", err
		}
		return path, err
	}()
	if err != nil {
		return err
	}
	var args []string
	if luaCode == "" {
		args = []string{"-cmd", "start", "-caseManageId", strconv.Itoa(int(caseManageId)), "-sn", sn, "-logFileName", logname + `.md`, "-minioLocation", minioLocation, "-logImgOpenFlag", "true"}
	} else {
		luaScriptName := tempDir + string(os.PathSeparator) + strconv.Itoa(int(caseManageId)) + ".lua"
		tmpFile, err := os.Create(luaScriptName)
		if err != nil {
			return err
		}
		_, err = fmt.Fprintln(tmpFile, luaCode)
		if err != nil {
			return err
		}
		tmpFile.Close()
		args = []string{"-cmd", "start", "-case", luaScriptName, "-sn", sn, "-logFileName", logname + `.md`, "-minioLocation", minioLocation, "-logImgOpenFlag", "true"}
	}
	cmd := exec.Command(exePath, args...)
	cmd.Dir = tempDir
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	err = cmd.Start()
	if err != nil {
		return err
	}

	scannerStdout := bufio.NewScanner(stdout)
	scannerStdout.Split(bufio.ScanLines)

	for scannerStdout.Scan() {
		m := scannerStdout.Text() + "\n"
		log.Printf("%s", m)
		stream.Send(&pb.TestCaseResponse{TestLog: m})
	}
	err = cmd.Wait()
	defer func() { cmd.Process.Kill() }()
	return err
}

func (s *server) AddClientCnt(context.Context, *emptypb.Empty) (*emptypb.Empty, error) {
	clientCnt++
	log.Println("add client,cnt:", clientCnt)
	return &emptypb.Empty{}, nil
}
func (s *server) MinusClientCnt(context.Context, *emptypb.Empty) (*emptypb.Empty, error) {
	clientCnt--
	log.Println("minus client,cnt:", clientCnt)

	if clientCnt <= 0 {
		go func() {
			rpcServer.GracefulStop()
			waitGroup.Done()
		}()
	}

	return &emptypb.Empty{}, nil
}
func (s *server) HealthZ(context.Context, *emptypb.Empty) (*pb.HealthStatus, error) {
	return &pb.HealthStatus{Ok: true}, nil
}
